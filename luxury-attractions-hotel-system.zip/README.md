# Luxury Attractions — B2B Hotel Contracts & Booking System

Internal system for managing negotiated (net) hotel rates, searching and comparing them across
all contracted hotels, building client quotations with markup, and assembling full trip packages
(hotel stay + tours, tickets and transfers) that export to PDF.

Built for **hotels.luxuryattractions.com**.

---

## 1. Tech stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16 (App Router, React 19, TypeScript) |
| Database | PostgreSQL |
| ORM / migrations | Drizzle ORM + drizzle-kit |
| Styling | Tailwind CSS v4 |
| Icons | lucide-react |

> **Note:** This is a Next.js + PostgreSQL application (not Laravel + MySQL). It requires a host
> that can run **Node.js** and **PostgreSQL** — standard PHP/MySQL shared hosting will not run it.

---

## 2. Requirements

- Node.js 20+
- PostgreSQL 14+

---

## 3. Local setup

```bash
# 1. Install dependencies
npm install

# 2. Configure the database connection
cp .env.example .env
#    then edit .env and set DATABASE_URL

# 3. Create all tables from the Drizzle schema
npx drizzle-kit push

# 4. Run in development
npm run dev
#    → http://localhost:3000
```

On first page load the app seeds demo data (hotels, rooms, rates, contacts, markets,
locations, amenities, services, tours, a sample quotation and a sample trip package)
so every screen is immediately usable. **Replace the demo records with your real
contracts before going live.**

### Production

```bash
npm run build
npm run start
```

### Environment variables

`.env`:

```
DATABASE_URL=postgresql://user:password@host:5432/database
```

`drizzle.config.json` also contains a connection string used by `drizzle-kit push` —
update it to match your database before running migrations.

---

## 4. Database schema

`schema.sql` in this archive is a plain SQL dump of the full structure if you prefer to
create the tables manually instead of using `npx drizzle-kit push`.

Main tables:

| Table | Purpose |
|-------|---------|
| `hotels` | Contracted properties: supplier code, star rating, city, location, group, website, contracts & media Drive links, check-in/out times, tourism tax + basis |
| `hotel_groups` | Umbrella companies (e.g. Al Khoory Hotels) — one sales team covering many hotels |
| `locations` | Districts inside a city/emirate (Dubai → Deira, Al Barsha …) |
| `hotel_contacts` | Sales contacts: name, position, email, phone, business card link, WhatsApp / Telegram / Viber flags, other |
| `hotel_contact_assignments` | Links contacts to hotels (a contact can serve several hotels; removing one assignment does not affect the others) |
| `amenities`, `hotel_amenities` | Amenity catalogue (pool, beach, gym, metro …) and per-hotel assignment; used as search filters |
| `room_categories` | Search categories used to compare like-for-like rooms (Deluxe King, Triple, Suite …) |
| `room_types` | Rooms per hotel: category, occupancy limits, base sleeps, contracted allocation, media link |
| `occupancy_rules` | Permitted guest combinations per room (e.g. 2 adults, or 1 adult + 2 children) |
| `room_bedding` | Extra bed / sofa bed / baby cot: how many allowed, free or paid, per night or per stay |
| `rate_periods` | Seasonal net rates: board type, stay period, **booking window**, market + market exclusions, promo code, base rate, meal supplements, extra adult/child/bed, minimum nights |
| `markets` | Markets & nationalities (editable; used for "not applicable" rate exclusions) |
| `blackout_dates` | Stop-sale / fully booked dates sent by hotels (hotel-wide or per room type) |
| `quotations`, `quotation_items` | Saved client proposals, including multi-hotel itineraries, tax inclusion and markup settings |
| `bookings`, `booking_items` | Confirmed reservations with a stored cost breakdown per stay segment |
| `services` | Transfers: shared (per person) or private (per vehicle, e.g. 7 Seater 500 AED), one-way and return prices |
| `tours` | Tours & tickets with three per-person tiers: ticket only / shared transfer / private transfer |
| `trip_packages`, `trip_package_items` | Hotel stay + tours/tickets/transfers itinerary with dates, times, pick-up and drop-off |

---

## 5. Feature guide

### Search & compare
Enter dates, guests, rooms, extra bedding, room category and client market. Every contracted
hotel is checked and priced:

- Each night is priced with the rate valid on that date (a shorter period such as a festive
  peak or flash sale overrides the season it falls inside).
- Booking windows are checked against today's date; market exclusions are applied.
- Occupancy rules, blackout dates and remaining allocation are enforced.
- Results sort cheapest first (or highest first), with filters for nightly rate range,
  board type, city, **location**, star rating, amenities and hotel name.
- Unavailable hotels are listed separately with the reason.

### Quotations
Add any search result to the quotation draft (tray at the bottom of the screen), including
stays at **different hotels** to build a multi-hotel itinerary. When saving you choose:

- whether the **tourism tax** is included in the client price or shown as a separate daily fee, and
- your **markup** as a percentage or a flat AED amount.

From the Quotations screen you can filter, combine several quotations into one, copy a
WhatsApp/email proposal, export a PDF, and convert a quotation into a confirmed booking.

### Trip packages
Create a package, optionally linking a saved hotel quotation, then add lines from the
service and tour catalogues with proposed **date, time, pick-up and drop-off**:

- **Services** — shared transfers charged per person (one-way or return) and private
  vehicles charged per vehicle (7 Seater, 12 Seater …).
- **Tours / tickets** — per-person pricing for ticket only, shared transfer or private transfer.

The PDF prints in two parts: **Part 1 — Hotels stay**, then **Part 2 — Tours & tickets itinerary**.

### PDFs
Open a quotation or trip package and choose **Print / Save PDF**, then select
"Save as PDF" as the destination. Client-facing documents show the quoted selling price only —
your internal net hotel cost and markup are never printed.

---

## 6. API routes

| Route | Methods | Purpose |
|-------|---------|---------|
| `/api/search` | GET, POST | Availability and pricing across all hotels |
| `/api/hotels` | POST | Create a hotel (with group, location, amenities, contacts) |
| `/api/hotel-groups` | POST | Umbrella companies |
| `/api/locations` | POST, DELETE | Districts under a city/emirate |
| `/api/contacts` | POST, PATCH, DELETE | Contacts, group sharing, per-hotel assignment |
| `/api/hotel-amenities` | POST | Replace a hotel's amenity set |
| `/api/amenities` | POST | Amenity catalogue |
| `/api/room-categories` | POST | Search categories |
| `/api/rooms` | POST, PATCH | Room types, duplicate a room, edit inventory |
| `/api/occupancy` | POST, DELETE | Occupancy combinations |
| `/api/rates` | POST | Rate lines with booking window, market and promo code |
| `/api/blackouts` | POST | Stop-sale dates |
| `/api/bookings` | POST | Single, multi-stay, or converted-from-quotation bookings |
| `/api/quotations` | GET, POST, PATCH, DELETE | Quotations, combining, tax/markup repricing |
| `/api/services` | GET, POST, DELETE | Transfer/service catalogue |
| `/api/tours` | GET, POST, DELETE | Tour & ticket catalogue |
| `/api/trip-packages` | GET, POST, PATCH, DELETE | Trip packages |
| `/api/trip-package-items` | POST, DELETE | Itinerary lines |
| `/api/health` | GET | Health check (used by the deployment platform) |

---

## 7. Pricing logic

All calculation lives in `src/lib/search-engine.ts` (availability and nightly pricing) and
`src/lib/quotation-pricing.ts` (tax inclusion and markup), so the browser, the APIs and the
seed script always produce identical numbers.

```
hotel cost  = base room + meal supplements + occupancy supplements + extra bedding
markup      = percentage of hotel cost, or a flat amount
quoted total= hotel cost + markup + (tourism tax when included)
daily rate  = (hotel cost + markup) ÷ nights ÷ rooms
```

Bookings are always re-priced on the server against the live contract before being saved.

---

## 8. Deployment

1. Provision PostgreSQL and set `DATABASE_URL`.
2. `npm ci && npx drizzle-kit push && npm run build`
3. Start with `npm run start` behind a reverse proxy, and point
   `hotels.luxuryattractions.com` at it.
