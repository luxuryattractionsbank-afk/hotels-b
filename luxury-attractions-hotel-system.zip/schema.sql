--
-- PostgreSQL database dump
--

\restrict 4jVWJ7yQvtRkMCvlBy5WE2VmWA2ke7xkj1joXXM0mGcNaa1j89mK2Rvl8SEYinf

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amenities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.amenities (
    id integer NOT NULL,
    slug text NOT NULL,
    label text NOT NULL,
    icon text DEFAULT 'check'::text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: amenities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.amenities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: amenities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.amenities_id_seq OWNED BY public.amenities.id;


--
-- Name: blackout_dates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blackout_dates (
    id integer NOT NULL,
    hotel_id integer NOT NULL,
    room_type_id integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    reason text DEFAULT 'Sold out by hotel'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: blackout_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blackout_dates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blackout_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blackout_dates_id_seq OWNED BY public.blackout_dates.id;


--
-- Name: booking_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_items (
    id integer NOT NULL,
    booking_id integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    hotel_id integer NOT NULL,
    room_type_id integer NOT NULL,
    rate_period_id integer,
    board_type text DEFAULT 'breakfast'::text NOT NULL,
    check_in date NOT NULL,
    check_out date NOT NULL,
    nights integer DEFAULT 1 NOT NULL,
    adults integer DEFAULT 2 NOT NULL,
    children integer DEFAULT 0 NOT NULL,
    infants integer DEFAULT 0 NOT NULL,
    rooms integer DEFAULT 1 NOT NULL,
    extra_beds integer DEFAULT 0 NOT NULL,
    sofa_beds integer DEFAULT 0 NOT NULL,
    baby_cots integer DEFAULT 0 NOT NULL,
    base_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    board_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    occupancy_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    extra_bed_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tourism_tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    rate_names text DEFAULT ''::text NOT NULL,
    promo_codes text DEFAULT ''::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL
);


--
-- Name: booking_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.booking_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: booking_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.booking_items_id_seq OWNED BY public.booking_items.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    reference text NOT NULL,
    hotel_id integer NOT NULL,
    room_type_id integer NOT NULL,
    rate_period_id integer,
    guest_name text NOT NULL,
    guest_email text NOT NULL,
    guest_phone text DEFAULT ''::text NOT NULL,
    check_in date NOT NULL,
    check_out date NOT NULL,
    adults integer NOT NULL,
    children integer DEFAULT 0 NOT NULL,
    infants integer DEFAULT 0 NOT NULL,
    rooms integer DEFAULT 1 NOT NULL,
    extra_beds integer DEFAULT 0 NOT NULL,
    nights integer NOT NULL,
    base_amount numeric(12,2) NOT NULL,
    board_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    occupancy_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    extra_bed_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tourism_tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    status text DEFAULT 'confirmed'::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    board_type text DEFAULT 'breakfast'::text NOT NULL,
    sofa_beds integer DEFAULT 0 NOT NULL,
    baby_cots integer DEFAULT 0 NOT NULL,
    quotation_id integer
);


--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: hotel_amenities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotel_amenities (
    id integer NOT NULL,
    hotel_id integer NOT NULL,
    amenity_id integer NOT NULL
);


--
-- Name: hotel_amenities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hotel_amenities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hotel_amenities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hotel_amenities_id_seq OWNED BY public.hotel_amenities.id;


--
-- Name: hotel_contact_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotel_contact_assignments (
    id integer NOT NULL,
    hotel_id integer NOT NULL,
    contact_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hotel_contact_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hotel_contact_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hotel_contact_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hotel_contact_assignments_id_seq OWNED BY public.hotel_contact_assignments.id;


--
-- Name: hotel_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotel_contacts (
    id integer NOT NULL,
    hotel_id integer,
    name text NOT NULL,
    "position" text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    business_card_link text DEFAULT ''::text NOT NULL,
    whatsapp boolean DEFAULT false NOT NULL,
    telegram boolean DEFAULT false NOT NULL,
    viber boolean DEFAULT false NOT NULL,
    other_contact text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    group_id integer
);


--
-- Name: hotel_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hotel_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hotel_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hotel_contacts_id_seq OWNED BY public.hotel_contacts.id;


--
-- Name: hotel_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotel_groups (
    id integer NOT NULL,
    name text NOT NULL,
    website text DEFAULT ''::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: hotel_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hotel_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hotel_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hotel_groups_id_seq OWNED BY public.hotel_groups.id;


--
-- Name: hotels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotels (
    id integer NOT NULL,
    name text NOT NULL,
    city text NOT NULL,
    country text DEFAULT 'United Arab Emirates'::text NOT NULL,
    address text DEFAULT ''::text NOT NULL,
    star_rating integer DEFAULT 5 NOT NULL,
    supplier_code text NOT NULL,
    contact_email text DEFAULT ''::text NOT NULL,
    contact_phone text DEFAULT ''::text NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    check_in_time text DEFAULT '15:00'::text NOT NULL,
    check_out_time text DEFAULT '12:00'::text NOT NULL,
    tourism_tax numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    tourism_tax_basis text DEFAULT 'room_night'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    group_id integer,
    business_type text DEFAULT 'Hotel'::text NOT NULL,
    website text DEFAULT ''::text NOT NULL,
    contracts_folder_link text DEFAULT ''::text NOT NULL,
    media_link text DEFAULT ''::text NOT NULL,
    location_id integer
);


--
-- Name: hotels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hotels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hotels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hotels_id_seq OWNED BY public.hotels.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    city text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: markets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.markets (
    id integer NOT NULL,
    slug text NOT NULL,
    label text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: markets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.markets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: markets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.markets_id_seq OWNED BY public.markets.id;


--
-- Name: occupancy_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.occupancy_rules (
    id integer NOT NULL,
    room_type_id integer NOT NULL,
    adults integer NOT NULL,
    children integer DEFAULT 0 NOT NULL,
    infants integer DEFAULT 0 NOT NULL,
    extra_beds integer DEFAULT 0 NOT NULL,
    label text DEFAULT ''::text NOT NULL
);


--
-- Name: occupancy_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.occupancy_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: occupancy_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.occupancy_rules_id_seq OWNED BY public.occupancy_rules.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotation_items (
    id integer NOT NULL,
    quotation_id integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    hotel_id integer NOT NULL,
    room_type_id integer NOT NULL,
    rate_period_id integer,
    board_type text DEFAULT 'breakfast'::text NOT NULL,
    check_in date NOT NULL,
    check_out date NOT NULL,
    nights integer DEFAULT 1 NOT NULL,
    adults integer DEFAULT 2 NOT NULL,
    children integer DEFAULT 0 NOT NULL,
    infants integer DEFAULT 0 NOT NULL,
    rooms integer DEFAULT 1 NOT NULL,
    extra_beds integer DEFAULT 0 NOT NULL,
    sofa_beds integer DEFAULT 0 NOT NULL,
    baby_cots integer DEFAULT 0 NOT NULL,
    base_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    board_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    occupancy_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    extra_bed_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tourism_tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    rate_names text DEFAULT ''::text NOT NULL,
    promo_codes text DEFAULT ''::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL
);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    reference text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    client_name text NOT NULL,
    client_email text DEFAULT ''::text NOT NULL,
    client_phone text DEFAULT ''::text NOT NULL,
    client_company text DEFAULT ''::text NOT NULL,
    market text DEFAULT 'all'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    valid_until date,
    total_nights integer DEFAULT 0 NOT NULL,
    total_guests text DEFAULT ''::text NOT NULL,
    base_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    board_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    occupancy_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    extra_bed_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tourism_tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    converted_booking_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    include_tax boolean DEFAULT true NOT NULL,
    markup_mode text DEFAULT 'percent'::text NOT NULL,
    markup_value numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    hotel_cost_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    markup_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    quoted_total numeric(12,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: rate_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_periods (
    id integer NOT NULL,
    hotel_id integer NOT NULL,
    room_type_id integer NOT NULL,
    name text NOT NULL,
    board_type text DEFAULT 'breakfast'::text NOT NULL,
    valid_from date NOT NULL,
    valid_to date NOT NULL,
    base_rate numeric(12,2) NOT NULL,
    rate_basis text DEFAULT 'room_night'::text NOT NULL,
    board_adult_supplement numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    board_child_supplement numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    board_supplement_basis text DEFAULT 'person_night'::text NOT NULL,
    extra_adult_rate numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    extra_child_rate numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    extra_bed_rate numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    extra_bed_basis text DEFAULT 'bed_night'::text NOT NULL,
    minimum_nights integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    booking_window_start date,
    booking_window_end date,
    market text DEFAULT 'all'::text NOT NULL,
    market_exclusions text DEFAULT ''::text NOT NULL,
    promo_code text DEFAULT ''::text NOT NULL
);


--
-- Name: rate_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rate_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rate_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rate_periods_id_seq OWNED BY public.rate_periods.id;


--
-- Name: room_bedding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_bedding (
    id integer NOT NULL,
    room_type_id integer NOT NULL,
    kind text NOT NULL,
    label text NOT NULL,
    max_per_room integer DEFAULT 1 NOT NULL,
    free boolean DEFAULT false NOT NULL,
    rate_per_night numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    per_stay boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL
);


--
-- Name: room_bedding_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.room_bedding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: room_bedding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.room_bedding_id_seq OWNED BY public.room_bedding.id;


--
-- Name: room_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_categories (
    id integer NOT NULL,
    slug text NOT NULL,
    label text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: room_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.room_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: room_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.room_categories_id_seq OWNED BY public.room_categories.id;


--
-- Name: room_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_types (
    id integer NOT NULL,
    hotel_id integer NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    max_adults integer DEFAULT 2 NOT NULL,
    max_children integer DEFAULT 0 NOT NULL,
    max_infants integer DEFAULT 0 NOT NULL,
    included_adults integer DEFAULT 2 NOT NULL,
    default_inventory integer DEFAULT 1 NOT NULL,
    extra_bed_allowed boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    category text DEFAULT 'deluxe_king'::text NOT NULL,
    base_sleeps integer DEFAULT 2 NOT NULL,
    media_link text DEFAULT ''::text NOT NULL
);


--
-- Name: room_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.room_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: room_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.room_types_id_seq OWNED BY public.room_types.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'shared_transfer'::text NOT NULL,
    vehicle_type text DEFAULT ''::text NOT NULL,
    price_mode text DEFAULT 'per_person'::text NOT NULL,
    one_way_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    two_way_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    details text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: tours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tours (
    id integer NOT NULL,
    name text NOT NULL,
    category text DEFAULT 'tour'::text NOT NULL,
    ticket_only_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    shared_transfer_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    private_transfer_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    details text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tours_id_seq OWNED BY public.tours.id;


--
-- Name: trip_package_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trip_package_items (
    id integer NOT NULL,
    package_id integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    kind text DEFAULT 'service'::text NOT NULL,
    service_id integer,
    tour_id integer,
    name text NOT NULL,
    price_type text DEFAULT 'per_person'::text NOT NULL,
    service_date date,
    service_time text DEFAULT ''::text NOT NULL,
    pickup text DEFAULT ''::text NOT NULL,
    dropoff text DEFAULT ''::text NOT NULL,
    persons integer DEFAULT 1 NOT NULL,
    vehicles integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    details text DEFAULT ''::text NOT NULL
);


--
-- Name: trip_package_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trip_package_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trip_package_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trip_package_items_id_seq OWNED BY public.trip_package_items.id;


--
-- Name: trip_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trip_packages (
    id integer NOT NULL,
    reference text NOT NULL,
    quotation_id integer,
    title text NOT NULL,
    client_name text NOT NULL,
    client_email text DEFAULT ''::text NOT NULL,
    client_phone text DEFAULT ''::text NOT NULL,
    client_company text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    start_date date,
    end_date date,
    includes_hotels boolean DEFAULT true NOT NULL,
    include_tax boolean DEFAULT true NOT NULL,
    markup_mode text DEFAULT 'percent'::text NOT NULL,
    markup_value numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    hotel_cost_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    extras_cost_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tourism_tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    markup_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    quoted_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: trip_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trip_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trip_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trip_packages_id_seq OWNED BY public.trip_packages.id;


--
-- Name: amenities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities ALTER COLUMN id SET DEFAULT nextval('public.amenities_id_seq'::regclass);


--
-- Name: blackout_dates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blackout_dates ALTER COLUMN id SET DEFAULT nextval('public.blackout_dates_id_seq'::regclass);


--
-- Name: booking_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_items ALTER COLUMN id SET DEFAULT nextval('public.booking_items_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: hotel_amenities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_amenities ALTER COLUMN id SET DEFAULT nextval('public.hotel_amenities_id_seq'::regclass);


--
-- Name: hotel_contact_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contact_assignments ALTER COLUMN id SET DEFAULT nextval('public.hotel_contact_assignments_id_seq'::regclass);


--
-- Name: hotel_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contacts ALTER COLUMN id SET DEFAULT nextval('public.hotel_contacts_id_seq'::regclass);


--
-- Name: hotel_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_groups ALTER COLUMN id SET DEFAULT nextval('public.hotel_groups_id_seq'::regclass);


--
-- Name: hotels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotels ALTER COLUMN id SET DEFAULT nextval('public.hotels_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: markets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.markets ALTER COLUMN id SET DEFAULT nextval('public.markets_id_seq'::regclass);


--
-- Name: occupancy_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.occupancy_rules ALTER COLUMN id SET DEFAULT nextval('public.occupancy_rules_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: rate_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_periods ALTER COLUMN id SET DEFAULT nextval('public.rate_periods_id_seq'::regclass);


--
-- Name: room_bedding id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_bedding ALTER COLUMN id SET DEFAULT nextval('public.room_bedding_id_seq'::regclass);


--
-- Name: room_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_categories ALTER COLUMN id SET DEFAULT nextval('public.room_categories_id_seq'::regclass);


--
-- Name: room_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_types ALTER COLUMN id SET DEFAULT nextval('public.room_types_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: tours id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours ALTER COLUMN id SET DEFAULT nextval('public.tours_id_seq'::regclass);


--
-- Name: trip_package_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_package_items ALTER COLUMN id SET DEFAULT nextval('public.trip_package_items_id_seq'::regclass);


--
-- Name: trip_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_packages ALTER COLUMN id SET DEFAULT nextval('public.trip_packages_id_seq'::regclass);


--
-- Name: amenities amenities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_pkey PRIMARY KEY (id);


--
-- Name: blackout_dates blackout_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blackout_dates
    ADD CONSTRAINT blackout_dates_pkey PRIMARY KEY (id);


--
-- Name: booking_items booking_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_items
    ADD CONSTRAINT booking_items_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: hotel_amenities hotel_amenities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_amenities
    ADD CONSTRAINT hotel_amenities_pkey PRIMARY KEY (id);


--
-- Name: hotel_contact_assignments hotel_contact_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contact_assignments
    ADD CONSTRAINT hotel_contact_assignments_pkey PRIMARY KEY (id);


--
-- Name: hotel_contacts hotel_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contacts
    ADD CONSTRAINT hotel_contacts_pkey PRIMARY KEY (id);


--
-- Name: hotel_groups hotel_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_groups
    ADD CONSTRAINT hotel_groups_pkey PRIMARY KEY (id);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (id);


--
-- Name: occupancy_rules occupancy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.occupancy_rules
    ADD CONSTRAINT occupancy_rules_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: rate_periods rate_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_periods
    ADD CONSTRAINT rate_periods_pkey PRIMARY KEY (id);


--
-- Name: room_bedding room_bedding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_bedding
    ADD CONSTRAINT room_bedding_pkey PRIMARY KEY (id);


--
-- Name: room_categories room_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_categories
    ADD CONSTRAINT room_categories_pkey PRIMARY KEY (id);


--
-- Name: room_types room_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_types
    ADD CONSTRAINT room_types_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: tours tours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_pkey PRIMARY KEY (id);


--
-- Name: trip_package_items trip_package_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_package_items
    ADD CONSTRAINT trip_package_items_pkey PRIMARY KEY (id);


--
-- Name: trip_packages trip_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_packages
    ADD CONSTRAINT trip_packages_pkey PRIMARY KEY (id);


--
-- Name: amenities_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX amenities_slug_idx ON public.amenities USING btree (slug);


--
-- Name: blackout_dates_hotel_dates_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX blackout_dates_hotel_dates_idx ON public.blackout_dates USING btree (hotel_id, start_date, end_date);


--
-- Name: booking_items_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_items_booking_idx ON public.booking_items USING btree (booking_id);


--
-- Name: bookings_dates_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_dates_idx ON public.bookings USING btree (check_in, check_out);


--
-- Name: bookings_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bookings_reference_idx ON public.bookings USING btree (reference);


--
-- Name: hotel_amenities_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hotel_amenities_unique_idx ON public.hotel_amenities USING btree (hotel_id, amenity_id);


--
-- Name: hotel_contact_assignments_contact_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hotel_contact_assignments_contact_idx ON public.hotel_contact_assignments USING btree (contact_id);


--
-- Name: hotel_contact_assignments_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hotel_contact_assignments_unique_idx ON public.hotel_contact_assignments USING btree (hotel_id, contact_id);


--
-- Name: hotel_contacts_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hotel_contacts_group_idx ON public.hotel_contacts USING btree (group_id);


--
-- Name: hotel_contacts_hotel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hotel_contacts_hotel_idx ON public.hotel_contacts USING btree (hotel_id);


--
-- Name: hotel_groups_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hotel_groups_name_idx ON public.hotel_groups USING btree (name);


--
-- Name: hotels_supplier_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hotels_supplier_code_idx ON public.hotels USING btree (supplier_code);


--
-- Name: locations_city_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX locations_city_name_idx ON public.locations USING btree (city, name);


--
-- Name: markets_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX markets_slug_idx ON public.markets USING btree (slug);


--
-- Name: occupancy_rules_room_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX occupancy_rules_room_idx ON public.occupancy_rules USING btree (room_type_id);


--
-- Name: quotation_items_quote_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_quote_idx ON public.quotation_items USING btree (quotation_id);


--
-- Name: quotations_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotations_client_idx ON public.quotations USING btree (client_name, client_email);


--
-- Name: quotations_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX quotations_reference_idx ON public.quotations USING btree (reference);


--
-- Name: rate_periods_hotel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rate_periods_hotel_idx ON public.rate_periods USING btree (hotel_id);


--
-- Name: rate_periods_room_dates_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rate_periods_room_dates_idx ON public.rate_periods USING btree (room_type_id, valid_from, valid_to);


--
-- Name: room_bedding_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX room_bedding_unique_idx ON public.room_bedding USING btree (room_type_id, kind);


--
-- Name: room_categories_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX room_categories_slug_idx ON public.room_categories USING btree (slug);


--
-- Name: room_types_hotel_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX room_types_hotel_code_idx ON public.room_types USING btree (hotel_id, code);


--
-- Name: room_types_hotel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX room_types_hotel_idx ON public.room_types USING btree (hotel_id);


--
-- Name: services_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_kind_idx ON public.services USING btree (kind);


--
-- Name: tours_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tours_category_idx ON public.tours USING btree (category);


--
-- Name: trip_package_items_pkg_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trip_package_items_pkg_idx ON public.trip_package_items USING btree (package_id);


--
-- Name: trip_packages_quote_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trip_packages_quote_idx ON public.trip_packages USING btree (quotation_id);


--
-- Name: trip_packages_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX trip_packages_reference_idx ON public.trip_packages USING btree (reference);


--
-- Name: blackout_dates blackout_dates_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blackout_dates
    ADD CONSTRAINT blackout_dates_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id) ON DELETE CASCADE;


--
-- Name: blackout_dates blackout_dates_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blackout_dates
    ADD CONSTRAINT blackout_dates_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id) ON DELETE CASCADE;


--
-- Name: booking_items booking_items_booking_id_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_items
    ADD CONSTRAINT booking_items_booking_id_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: booking_items booking_items_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_items
    ADD CONSTRAINT booking_items_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id);


--
-- Name: booking_items booking_items_rate_period_id_rate_periods_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_items
    ADD CONSTRAINT booking_items_rate_period_id_rate_periods_id_fk FOREIGN KEY (rate_period_id) REFERENCES public.rate_periods(id);


--
-- Name: booking_items booking_items_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_items
    ADD CONSTRAINT booking_items_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id);


--
-- Name: bookings bookings_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id);


--
-- Name: bookings bookings_quotation_id_quotations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_quotation_id_quotations_id_fk FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_rate_period_id_rate_periods_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_rate_period_id_rate_periods_id_fk FOREIGN KEY (rate_period_id) REFERENCES public.rate_periods(id);


--
-- Name: bookings bookings_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id);


--
-- Name: hotel_amenities hotel_amenities_amenity_id_amenities_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_amenities
    ADD CONSTRAINT hotel_amenities_amenity_id_amenities_id_fk FOREIGN KEY (amenity_id) REFERENCES public.amenities(id) ON DELETE CASCADE;


--
-- Name: hotel_amenities hotel_amenities_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_amenities
    ADD CONSTRAINT hotel_amenities_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id) ON DELETE CASCADE;


--
-- Name: hotel_contact_assignments hotel_contact_assignments_contact_id_hotel_contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contact_assignments
    ADD CONSTRAINT hotel_contact_assignments_contact_id_hotel_contacts_id_fk FOREIGN KEY (contact_id) REFERENCES public.hotel_contacts(id) ON DELETE CASCADE;


--
-- Name: hotel_contact_assignments hotel_contact_assignments_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contact_assignments
    ADD CONSTRAINT hotel_contact_assignments_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id) ON DELETE CASCADE;


--
-- Name: hotel_contacts hotel_contacts_group_id_hotel_groups_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contacts
    ADD CONSTRAINT hotel_contacts_group_id_hotel_groups_id_fk FOREIGN KEY (group_id) REFERENCES public.hotel_groups(id) ON DELETE SET NULL;


--
-- Name: hotel_contacts hotel_contacts_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_contacts
    ADD CONSTRAINT hotel_contacts_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id) ON DELETE SET NULL;


--
-- Name: hotels hotels_group_id_hotel_groups_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT hotels_group_id_hotel_groups_id_fk FOREIGN KEY (group_id) REFERENCES public.hotel_groups(id) ON DELETE SET NULL;


--
-- Name: hotels hotels_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT hotels_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: occupancy_rules occupancy_rules_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.occupancy_rules
    ADD CONSTRAINT occupancy_rules_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id) ON DELETE CASCADE;


--
-- Name: quotation_items quotation_items_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id);


--
-- Name: quotation_items quotation_items_quotation_id_quotations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_quotation_id_quotations_id_fk FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE CASCADE;


--
-- Name: quotation_items quotation_items_rate_period_id_rate_periods_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_rate_period_id_rate_periods_id_fk FOREIGN KEY (rate_period_id) REFERENCES public.rate_periods(id);


--
-- Name: quotation_items quotation_items_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id);


--
-- Name: rate_periods rate_periods_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_periods
    ADD CONSTRAINT rate_periods_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id) ON DELETE CASCADE;


--
-- Name: rate_periods rate_periods_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_periods
    ADD CONSTRAINT rate_periods_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id) ON DELETE CASCADE;


--
-- Name: room_bedding room_bedding_room_type_id_room_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_bedding
    ADD CONSTRAINT room_bedding_room_type_id_room_types_id_fk FOREIGN KEY (room_type_id) REFERENCES public.room_types(id) ON DELETE CASCADE;


--
-- Name: room_types room_types_hotel_id_hotels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_types
    ADD CONSTRAINT room_types_hotel_id_hotels_id_fk FOREIGN KEY (hotel_id) REFERENCES public.hotels(id) ON DELETE CASCADE;


--
-- Name: trip_package_items trip_package_items_package_id_trip_packages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_package_items
    ADD CONSTRAINT trip_package_items_package_id_trip_packages_id_fk FOREIGN KEY (package_id) REFERENCES public.trip_packages(id) ON DELETE CASCADE;


--
-- Name: trip_package_items trip_package_items_service_id_services_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_package_items
    ADD CONSTRAINT trip_package_items_service_id_services_id_fk FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: trip_package_items trip_package_items_tour_id_tours_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_package_items
    ADD CONSTRAINT trip_package_items_tour_id_tours_id_fk FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE SET NULL;


--
-- Name: trip_packages trip_packages_quotation_id_quotations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_packages
    ADD CONSTRAINT trip_packages_quotation_id_quotations_id_fk FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 4jVWJ7yQvtRkMCvlBy5WE2VmWA2ke7xkj1joXXM0mGcNaa1j89mK2Rvl8SEYinf

