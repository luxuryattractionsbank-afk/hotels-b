import DashboardClient, { DashboardData } from "./dashboard-client";
import { getHotelDashboardData } from "@/lib/hotel-data";
import { searchAllHotels } from "@/lib/search-data";
import { addDays, CoreCriteria, DEFAULT_CRITERIA } from "@/lib/search-engine";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const data = await getHotelDashboardData();
  const today = new Date().toISOString().slice(0, 10);
  const criteria: CoreCriteria = {
    ...DEFAULT_CRITERIA,
    checkIn: addDays(today, 14),
    checkOut: addDays(today, 17),
    bookingDate: today,
  };
  const { outsidePriceRange: _ignored, ...response } = await searchAllHotels(criteria);
  void _ignored;

  return (
    <DashboardClient
      data={JSON.parse(JSON.stringify(data)) as DashboardData}
      initialSearch={{ criteria, response }}
      today={today}
    />
  );
}
