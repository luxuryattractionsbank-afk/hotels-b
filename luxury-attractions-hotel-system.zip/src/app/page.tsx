import { redirect } from "next/navigation";
import DashboardClient, { DashboardData } from "./dashboard-client";
import { getHotelDashboardData } from "@/lib/hotel-data";
import { searchAllHotels } from "@/lib/search-data";
import { addDays, CoreCriteria, DEFAULT_CRITERIA } from "@/lib/search-engine";
import { ensureSeedAdmin, getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { smtpSettings, users } from "@/db/schema";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeedAdmin();
  const sessionUser = await getSessionUser();
  if (!sessionUser) redirect("/login");

  const data = await getHotelDashboardData();
  const today = new Date().toISOString().slice(0, 10);
  const criteria: CoreCriteria = {
    ...DEFAULT_CRITERIA,
    checkIn: addDays(today, 14),
    checkOut: addDays(today, 17),
    bookingDate: today,
  };
  const { outsidePriceRange: _ignored, ...response } = await searchAllHotels(criteria);
  void _ignored;

  const isAdmin = sessionUser.role === "admin" || sessionUser.permissions.includes("users");
  const userList = isAdmin
    ? await db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
          permissions: users.permissions,
          phone: users.phone,
          active: users.active,
          lastLoginAt: users.lastLoginAt,
        })
        .from(users)
        .orderBy(asc(users.name))
    : [];

  const [smtp] = sessionUser.role === "admin" || sessionUser.permissions.includes("settings")
    ? await db.select().from(smtpSettings).limit(1)
    : [];

  return (
    <DashboardClient
      data={JSON.parse(JSON.stringify(data)) as DashboardData}
      initialSearch={{ criteria, response }}
      today={today}
      currentUser={sessionUser}
      users={JSON.parse(JSON.stringify(userList))}
      smtp={smtp ? { ...smtp, password: smtp.password ? "********" : "" } : null}
    />
  );
}
