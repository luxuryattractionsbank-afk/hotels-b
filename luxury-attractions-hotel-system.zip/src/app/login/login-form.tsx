"use client";

import { AlertTriangle, Hotel, Loader2, Lock, LogIn, Mail } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";

export default function LoginForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", email: form.get("email"), password: form.get("password") }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Sign in failed.");
      router.replace("/");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
      setLoading(false);
    }
  };

  return (
    <main className="grid min-h-screen place-items-center bg-[#0f2d2a] p-4">
      <div className="w-full max-w-[420px]">
        <div className="mb-6 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[#174e48] text-white shadow-xl ring-1 ring-white/10">
            <Hotel size={26} strokeWidth={2.2} />
          </div>
          <h1 className="mt-4 text-xl font-extrabold tracking-tight text-white">Luxury Attractions</h1>
          <p className="mt-1 text-[11px] font-bold uppercase tracking-[0.18em] text-[#d4a271]">Hotel contracts portal</p>
        </div>

        <form onSubmit={submit} className="rounded-3xl bg-white p-7 shadow-2xl">
          <h2 className="text-lg font-extrabold text-slate-900">Sign in</h2>
          <p className="mt-1 text-xs text-slate-500">Use your work account to access contracts, quotations and bookings.</p>

          {error && (
            <div role="alert" className="mt-4 flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs font-semibold text-rose-700">
              <AlertTriangle size={15} className="mt-px shrink-0" /> {error}
            </div>
          )}

          <label className="mt-5 block">
            <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Email address</span>
            <div className="relative">
              <Mail size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                autoFocus
                placeholder="you@luxuryattractions.com"
                className="h-12 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-3.5 text-sm text-slate-800 outline-none transition focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10"
              />
            </div>
          </label>

          <label className="mt-4 block">
            <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Password</span>
            <div className="relative">
              <Lock size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                name="password"
                type="password"
                required
                autoComplete="current-password"
                placeholder="••••••••"
                className="h-12 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-3.5 text-sm text-slate-800 outline-none transition focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10"
              />
            </div>
          </label>

          <button
            disabled={loading}
            className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#174e48] text-sm font-bold text-white shadow-lg shadow-teal-900/20 transition hover:bg-[#103f3a] disabled:opacity-60"
          >
            {loading ? <Loader2 size={17} className="animate-spin" /> : <LogIn size={17} />}
            {loading ? "Signing in…" : "Sign in"}
          </button>

          <div className="mt-6 rounded-xl bg-slate-50 p-3.5 text-[11px] leading-5 text-slate-500">
            <b className="text-slate-700">First time?</b> The system creates an administrator on first run:
            <br />
            <code className="text-[10px] text-slate-700">admin@luxuryattractions.com</code> / <code className="text-[10px] text-slate-700">Admin@12345</code>
            <br />
            You will be asked to change this password after signing in.
          </div>
        </form>
      </div>
    </main>
  );
}
