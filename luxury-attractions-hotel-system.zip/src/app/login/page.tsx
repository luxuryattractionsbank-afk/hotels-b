import { redirect } from "next/navigation";
import { ensureSeedAdmin, getSessionUser } from "@/lib/auth";
import LoginForm from "./login-form";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  await ensureSeedAdmin();
  const user = await getSessionUser();
  if (user) redirect("/");
  return <LoginForm />;
}
