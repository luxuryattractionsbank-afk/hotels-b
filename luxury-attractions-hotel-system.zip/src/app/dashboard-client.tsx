"use client";

import {
  AlertTriangle,
  ArrowUpRight,
  BadgeDollarSign,
  BedDouble,
  BookOpenCheck,
  Building2,
  CalendarDays,
  CalendarX2,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  CircleDot,
  Clock3,
  Copy,
  ExternalLink,
  Eye,
  FileSpreadsheet,
  FileText,
  Filter,
  Hotel,
  Images,
  Layers,
  LayoutDashboard,
  Loader2,
  MapPin,
  Menu,
  MoonStar,
  Plus,
  Printer,
  Download,
  KeyRound,
  LogOut,
  Mail,
  PackagePlus,
  Receipt,
  Send as SendIcon,
  Settings,
  Share2 as ShareIcon,
  ShieldCheck,
  UserPlus,
  Route,
  Search,
  SearchCheck,
  Send,
  Share2,
  Sparkles,
  Star,
  TicketPercent,
  Trash2,
  UsersRound,
  UtensilsCrossed,
  WalletCards,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, ReactNode, useMemo, useState } from "react";
import { BEDDING_KINDS, boardLabel, marketLabel, messagingLink, parseMarketList } from "@/lib/search-engine";
import SearchPanel, { AmenityIcon, InitialSearch } from "./search-panel";
import { PrintShell, QuotationPrint, setPrintHotelLocations, TripPackagePrint } from "./print-views";
import { buildQuotationPdf, buildTripPackagePdf, pdfFileName, type PdfStay, type PdfTripItem } from "@/lib/pdf-generator";
import { canShareFiles, downloadPdf, openMessenger, sharePdfFile } from "@/lib/share-pdf";
import { can, PERMISSIONS, ROLE_PRESETS, type PermissionKey, type SessionUser } from "@/lib/permissions";
import ContactManager from "./contact-manager";
import { groupContactCandidates } from "@/lib/contact-sharing";
import { computeQuotationPricing, MarkupMode } from "@/lib/quotation-pricing";

type HotelRow = {
  id: number;
  name: string;
  city: string;
  country: string;
  locationId: number | null;
  address: string;
  starRating: number;
  supplierCode: string;
  groupId: number | null;
  businessType: string;
  website: string;
  contractsFolderLink: string;
  mediaLink: string;
  contactEmail: string;
  contactPhone: string;
  currency: string;
  checkInTime: string;
  checkOutTime: string;
  tourismTax: string;
  tourismTaxBasis: string;
  active: boolean;
};

type RoomCategoryRow = { id: number; slug: string; label: string; sortOrder: number; active: boolean };

type BeddingRow = {
  id: number;
  roomTypeId: number;
  kind: string;
  label: string;
  maxPerRoom: number;
  free: boolean;
  ratePerNight: string;
  perStay: boolean;
  sortOrder: number;
};

type RoomRow = {
  id: number;
  hotelId: number;
  name: string;
  code: string;
  category: string;
  description: string;
  maxAdults: number;
  maxChildren: number;
  maxInfants: number;
  includedAdults: number;
  baseSleeps: number;
  defaultInventory: number;
  extraBedAllowed: boolean;
  mediaLink: string;
  active: boolean;
};

type AmenityRow = { id: number; slug: string; label: string; icon: string; sortOrder: number; active: boolean };
type HotelAmenityRow = { id: number; hotelId: number; amenityId: number };
type LocationRow = { id: number; city: string; name: string; active: boolean };
type MarketRow = { id: number; slug: string; label: string; sortOrder: number; active: boolean };
type HotelGroupRow = { id: number; name: string; website: string; notes: string; active: boolean };

type ContactRow = {
  id: number;
  hotelId: number | null;
  groupId: number | null;
  name: string;
  position: string;
  email: string;
  phone: string;
  businessCardLink: string;
  whatsapp: boolean;
  telegram: boolean;
  viber: boolean;
  otherContact: string;
  active: boolean;
};

type OccupancyRow = { id: number; roomTypeId: number; adults: number; children: number; infants: number; extraBeds: number; label: string };

type RateRow = {
  id: number;
  hotelId: number;
  roomTypeId: number;
  name: string;
  boardType: string;
  validFrom: string;
  validTo: string;
  bookingWindowStart: string | null;
  bookingWindowEnd: string | null;
  market: string;
  marketExclusions: string;
  promoCode: string;
  baseRate: string;
  rateBasis: string;
  boardAdultSupplement: string;
  boardChildSupplement: string;
  boardSupplementBasis: string;
  extraAdultRate: string;
  extraChildRate: string;
  extraBedRate: string;
  extraBedBasis: string;
  minimumNights: number;
  active: boolean;
};

type BlackoutRow = { id: number; hotelId: number; roomTypeId: number | null; startDate: string; endDate: string; reason: string };

type BookingRow = {
  id: number;
  reference: string;
  hotelId: number;
  roomTypeId: number;
  ratePeriodId: number | null;
  boardType: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  nights: number;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  totalAmount: string;
  currency: string;
  status: string;
  notes: string;
  quotationId: number | null;
  createdAt: string;
};

type BookingItemRow = {
  id: number;
  bookingId: number;
  sortOrder: number;
  hotelId: number;
  roomTypeId: number;
  ratePeriodId: number | null;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  totalAmount: string;
  rateNames: string;
  promoCodes: string;
  notes: string;
};

type QuotationRow = {
  id: number;
  reference: string;
  title: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientCompany: string;
  market: string;
  status: string; // draft, sent, accepted, converted, expired
  validUntil: string | null;
  totalNights: number;
  totalGuests: string;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  includeTax: boolean;
  markupMode: string;
  markupValue: string;
  hotelCostTotal: string;
  markupAmount: string;
  quotedTotal: string;
  totalAmount: string;
  currency: string;
  notes: string;
  convertedBookingId: number | null;
  createdAt: string;
  updatedAt: string;
};

type QuotationItemRow = {
  id: number;
  quotationId: number;
  sortOrder: number;
  hotelId: number;
  roomTypeId: number;
  ratePeriodId: number | null;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  totalAmount: string;
  rateNames: string;
  promoCodes: string;
  notes: string;
};

type ServiceRow = {
  id: number;
  name: string;
  kind: string;
  vehicleType: string;
  priceMode: string;
  oneWayPrice: string;
  twoWayPrice: string;
  details: string;
  active: boolean;
};

type TourRow = {
  id: number;
  name: string;
  category: string;
  ticketOnlyPrice: string;
  sharedTransferPrice: string;
  privateTransferPrice: string;
  details: string;
  active: boolean;
};

type TripPackageRow = {
  id: number;
  reference: string;
  quotationId: number | null;
  title: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientCompany: string;
  status: string;
  startDate: string | null;
  endDate: string | null;
  includesHotels: boolean;
  includeTax: boolean;
  markupMode: string;
  markupValue: string;
  hotelCostTotal: string;
  extrasCostTotal: string;
  tourismTaxAmount: string;
  markupAmount: string;
  quotedTotal: string;
  totalAmount: string;
  currency: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
};

type TripItemRow = {
  id: number;
  packageId: number;
  sortOrder: number;
  kind: string;
  serviceId: number | null;
  tourId: number | null;
  name: string;
  priceType: string;
  serviceDate: string | null;
  serviceTime: string;
  pickup: string;
  dropoff: string;
  persons: number;
  vehicles: number;
  unitPrice: string;
  totalAmount: string;
  details: string;
};

export type AppUser = {
  id: number;
  name: string;
  email: string;
  role: string;
  permissions: string;
  phone: string;
  active: boolean;
  lastLoginAt: string | null;
};

export type SmtpConfig = {
  id: number;
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string;
  fromName: string;
  fromEmail: string;
  replyTo: string;
  bccSelf: boolean;
  active: boolean;
};

export type DashboardData = {
  hotels: HotelRow[];
  markets: MarketRow[];
  locations: LocationRow[];
  hotelGroups: HotelGroupRow[];
  contacts: ContactRow[];
  contactAssignments: { id: number; hotelId: number; contactId: number; createdAt: string }[];
  amenities: AmenityRow[];
  hotelAmenities: HotelAmenityRow[];
  roomCategories: RoomCategoryRow[];
  rooms: RoomRow[];
  bedding: BeddingRow[];
  occupancies: OccupancyRow[];
  rates: RateRow[];
  blackouts: BlackoutRow[];
  bookings: BookingRow[];
  bookingItems: BookingItemRow[];
  quotations: QuotationRow[];
  quotationItems: QuotationItemRow[];
  services: ServiceRow[];
  tours: TourRow[];
  tripPackages: TripPackageRow[];
  tripPackageItems: TripItemRow[];
};

type View = "search" | "quotations" | "trips" | "dashboard" | "bookings" | "hotels" | "rooms" | "rates" | "blackouts" | "admin";
type Dialog = "hotel" | "room" | "rate" | "blackout" | "amenity" | "hotelAmenities" | "category" | "contact" | "group" | "market" | "occupancy" | null;

const navItems: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "search", label: "Search & compare", icon: SearchCheck },
  { id: "quotations", label: "Quotations", icon: FileSpreadsheet },
  { id: "trips", label: "Trip Packages", icon: Route },
  { id: "dashboard", label: "Overview", icon: LayoutDashboard },
  { id: "bookings", label: "Bookings", icon: BookOpenCheck },
  { id: "hotels", label: "Hotels", icon: Building2 },
  { id: "rooms", label: "Room types", icon: BedDouble },
  { id: "rates", label: "Rates & board", icon: BadgeDollarSign },
  { id: "blackouts", label: "Blackout dates", icon: CalendarX2 },
  { id: "admin", label: "Users & settings", icon: ShieldCheck },
];

/** Which permission unlocks each sidebar section. */
const VIEW_PERMISSION: Record<View, PermissionKey> = {
  search: "search",
  quotations: "quotations",
  trips: "trips",
  dashboard: "search",
  bookings: "bookings",
  hotels: "hotels",
  rooms: "rooms",
  rates: "rates",
  blackouts: "blackouts",
  admin: "users",
};

const pageTitles: Record<View, { eyebrow: string; title: string; copy: string }> = {
  search: { eyebrow: "All contracted hotels", title: "Search & compare rates", copy: "Enter the stay and guests — every contract is checked, priced, and can be added to quotations." },
  quotations: { eyebrow: "Proposals & Multi-Stay Itineraries", title: "Client Quotations", copy: "Retrieve saved quotes, combine multiple hotel stays into unified itineraries, and convert to bookings." },
  trips: { eyebrow: "Hotels + Tours, Tickets & Transfers", title: "Trip Packages", copy: "Add services such as airport pick up and drop back, tours and tickets, with dates and times — then export the full itinerary as a PDF." },
  dashboard: { eyebrow: "Contract operations", title: "Portfolio overview", copy: "Key figures across your hotel contracts, proposals, and reservations." },
  hotels: { eyebrow: "Supplier portfolio", title: "Contracted hotels", copy: "Supplier details, check-in policies, locations, media links, and tourism taxes." },
  rooms: { eyebrow: "Accommodation", title: "Room types & occupancy", copy: "Room categories, inventory, guest limits, extra bedding, and permitted occupancy combinations." },
  rates: { eyebrow: "Commercial contracts", title: "Rates & board plans", copy: "Seasonal net prices, booking windows, meal supplements, and extra-bed costs." },
  blackouts: { eyebrow: "Availability controls", title: "Blackout dates", copy: "Fully booked and stop-sale dates sent by hotels. These rooms never appear in search." },
  bookings: { eyebrow: "Reservation desk", title: "Bookings Ledger", copy: "Confirmed single and multi-hotel reservations with full segment breakdowns." },
  admin: { eyebrow: "Administration", title: "Users & settings", copy: "Manage staff accounts, permissions and the SMTP account used to email proposals." },
};

const formatMoney = (value: number | string, currency = "AED") =>
  `${currency} ${Number(value).toLocaleString("en-AE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

const formatDate = (date: string, options?: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat("en-GB", options ?? { day: "2-digit", month: "short", year: "numeric" }).format(new Date(`${date.slice(0, 10)}T00:00:00Z`));

const hotelInitials = (name: string) =>
  name
    .split(" ")
    .filter((word) => word.length > 2 && word !== "The")
    .slice(0, 2)
    .map((word) => word[0])
    .join("");

const card = "rounded-2xl border border-slate-200/80 bg-white shadow-[0_2px_10px_rgba(15,23,42,0.025)]";
const inputClass = "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10";
const selectClass = `${inputClass} appearance-none pr-9`;

function StatusBadge({ status }: { status: string }) {
  const tone =
    status === "confirmed" || status === "accepted" || status === "converted"
      ? ["bg-emerald-50 text-emerald-700", "bg-emerald-500"]
      : status === "cancelled" || status === "expired"
        ? ["bg-rose-50 text-rose-700", "bg-rose-500"]
        : status === "sent"
          ? ["bg-sky-50 text-sky-700", "bg-sky-500"]
          : ["bg-amber-50 text-amber-700", "bg-amber-500"];

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ${tone[0]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${tone[1]}`} />
      {status}
    </span>
  );
}

function Modal({ title, subtitle, onClose, children, wide = false }: { title: string; subtitle: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px]" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className={`max-h-[92vh] w-full overflow-y-auto rounded-[22px] bg-white shadow-2xl ${wide ? "max-w-4xl" : "max-w-3xl"}`}>
        <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5">
          <div>
            <h2 className="text-xl font-bold text-slate-950">{title}</h2>
            <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
          </div>
          <button onClick={onClose} className="rounded-xl border border-slate-200 p-2 text-slate-500 transition hover:bg-slate-50" aria-label="Close dialog"><X size={18} /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children, hint, className = "" }: { label: string; children: ReactNode; hint?: string; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-xs text-slate-400">{hint}</span>}
    </label>
  );
}

function SelectWrap({ children }: { children: ReactNode }) {
  return <div className="relative">{children}<ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} /></div>;
}

function SearchableSelect({
  name,
  value,
  onChange,
  options,
  placeholder = "Type to find a hotel…",
  required = false,
}: {
  name: string;
  value: number;
  onChange: (id: number) => void;
  options: { id: number; label: string; hint?: string }[];
  placeholder?: string;
  required?: boolean;
}) {
  const selected = options.find((option) => option.id === value);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState<string | null>(null);
  const [active, setActive] = useState(0);
  const display = query ?? selected?.label ?? "";
  const needle = (query ?? "").trim().toLowerCase();
  const browsing = !needle || needle === (selected?.label ?? "").toLowerCase();
  const filtered = browsing ? options : options.filter((option) => `${option.label} ${option.hint ?? ""}`.toLowerCase().includes(needle));

  const pick = (id: number) => {
    onChange(id);
    setQuery(null);
    setOpen(false);
  };

  return (
    <div className="relative">
      <input type="hidden" name={name} value={value || ""} required={required} />
      <input
        value={display}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
          setActive(0);
        }}
        onFocus={(event) => {
          setOpen(true);
          event.currentTarget.select();
        }}
        onBlur={() => {
          window.setTimeout(() => {
            setOpen(false);
            const typed = (query ?? "").trim().toLowerCase();
            if (!typed) {
              setQuery(null);
              return;
            }
            const match = options.find((option) => option.label.toLowerCase() === typed) ?? options.find((option) => option.label.toLowerCase().includes(typed));
            if (match) pick(match.id);
            else setQuery(null);
          }, 140);
        }}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            setOpen(true);
            setActive((index) => Math.min(index + 1, Math.max(0, filtered.length - 1)));
          } else if (event.key === "ArrowUp") {
            event.preventDefault();
            setActive((index) => Math.max(index - 1, 0));
          } else if (event.key === "Enter" && open && filtered[active]) {
            event.preventDefault();
            pick(filtered[active].id);
          } else if (event.key === "Escape") {
            setOpen(false);
            setQuery(null);
          }
        }}
        placeholder={placeholder}
        autoComplete="off"
        role="combobox"
        aria-expanded={open}
        aria-controls={`${name}-listbox`}
        aria-autocomplete="list"
        className={`${inputClass} pr-10`}
      />
      <button type="button" tabIndex={-1} onMouseDown={(event) => event.preventDefault()} onClick={() => setOpen((current) => !current)} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label="Show hotels">
        <ChevronDown size={16} className={`transition ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div id={`${name}-listbox`} role="listbox" className="absolute z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-xl border border-slate-200 bg-white py-1 shadow-xl">
          {filtered.map((option, index) => (
            <button
              type="button"
              key={option.id}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => pick(option.id)}
              className={`flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left text-sm ${option.id === value || index === active ? "bg-[#174e48] font-bold text-white" : "text-slate-700 hover:bg-slate-50"}`}
            >
              <span className="min-w-0">
                <span className="block truncate">{option.label}</span>
                {option.hint && <span className={`block truncate text-[10px] font-medium ${option.id === value || index === active ? "text-white/70" : "text-slate-400"}`}>{option.hint}</span>}
              </span>
            </button>
          ))}
          {filtered.length === 0 && <div className="px-3 py-3 text-xs text-slate-400">No hotel matches “{query}”</div>}
        </div>
      )}
    </div>
  );
}

function toList(value: unknown): string[] {
  if (Array.isArray(value)) return value.map((item) => String(item));
  if (value === undefined || value === null || value === "") return [];
  return [String(value)];
}

function SubmitRow({ saving, label }: { saving: boolean; label: string }) {
  return (
    <div className="mt-2 flex justify-end border-t border-slate-100 pt-5 md:col-span-2">
      <button disabled={saving} className="flex h-11 min-w-36 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white transition hover:bg-[#103f3a] disabled:opacity-60">
        {saving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
        {saving ? "Saving…" : label}
      </button>
    </div>
  );
}

export default function DashboardClient({
  data,
  initialSearch,
  today,
  currentUser,
  users,
  smtp,
}: {
  data: DashboardData;
  initialSearch: InitialSearch;
  today: string;
  currentUser: SessionUser;
  users: AppUser[];
  smtp: SmtpConfig | null;
}) {
  const router = useRouter();
  const allowed = (key: View) => can(currentUser, VIEW_PERMISSION[key]);
  const visibleNav = navItems.filter((item) => allowed(item.id));
  const [view, setView] = useState<View>(() => {
    if (typeof window !== "undefined") {
      const stored = window.sessionStorage.getItem("la_view") as View | null;
      if (stored && navItems.some((item) => item.id === stored)) return stored;
    }
    return "search";
  });
  const [dialog, setDialog] = useState<Dialog>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [rateHotel, setRateHotel] = useState<number>(0);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const cities = useMemo(() => Array.from(new Set(data.hotels.map((hotel) => hotel.city))).sort(), [data.hotels]);
  const locationsByCity = useMemo(() => {
    return data.locations.reduce<Record<string, string[]>>((map, place) => {
      map[place.city] = [...(map[place.city] ?? []), place.name];
      return map;
    }, {});
  }, [data.locations]);

  const amenityById = (id: number) => data.amenities.find((amenity) => amenity.id === id);
  const categoryLabel = (slug: string) => data.roomCategories.find((category) => category.slug === slug)?.label ?? slug;
  const beddingFor = (roomTypeId: number) => data.bedding.filter((item) => item.roomTypeId === roomTypeId);
  const hotelAmenityIds = (hotelId: number) => data.hotelAmenities.filter((link) => link.hotelId === hotelId).map((link) => link.amenityId);
  const locationName = (id: number | null) => (id ? data.locations.find((place) => place.id === id)?.name ?? "" : "");
  const printLocations = useMemo(
    () => Object.fromEntries(data.hotels.map((hotel) => [hotel.id, locationName(hotel.locationId)])),
    [data.hotels, data.locations], // eslint-disable-line react-hooks/exhaustive-deps
  );
  setPrintHotelLocations(printLocations);

  // Form & view state
  const [amenityEditHotel, setAmenityEditHotel] = useState<number>(0);
  const [contactHotel, setContactHotel] = useState<number>(0);
  const [contactGroupId, setContactGroupId] = useState<number>(0);
  const [groupHotelSelections, setGroupHotelSelections] = useState<number[]>([]);
  const [managerGroupId, setManagerGroupId] = useState<number | null>(null);
  const [managerHotelId, setManagerHotelId] = useState<number | null>(null);
  const [newHotelGroupId, setNewHotelGroupId] = useState<string>("");
  const [newHotelContactSlots, setNewHotelContactSlots] = useState<number[]>([0, 1]);
  const [newHotelSharedContactIds, setNewHotelSharedContactIds] = useState<number[]>([]);
  const [newHotelCity, setNewHotelCity] = useState("");
  const [newHotelLocationId, setNewHotelLocationId] = useState("");

  const [rateHotelId, setRateHotelId] = useState(0);
  const [rateRoomId, setRateRoomId] = useState(0);

  const [hotelLayout, setHotelLayout] = useState<"table" | "cards">("table");
  const [hotelCardQuery, setHotelCardQuery] = useState("");
  const [hotelColumnFilters, setHotelColumnFilters] = useState<Record<string, string>>({});
  const [expandedHotelRates, setExpandedHotelRates] = useState<number | null>(null);

  const [occupancyRoomId, setOccupancyRoomId] = useState<number>(0);
  const [occupancySlots, setOccupancySlots] = useState<number[]>([0, 1]);
  const [inventoryDraft, setInventoryDraft] = useState<Record<number, string>>({});

  const [blackoutHotelId, setBlackoutHotelId] = useState(0);
  const [blackoutRoomId, setBlackoutRoomId] = useState(0);
  const [blackoutRoomQuery, setBlackoutRoomQuery] = useState("");

  const [newMarket, setNewMarket] = useState("");

  // Quotation Management State
  const [viewingTrip, setViewingTrip] = useState<TripPackageRow | null>(null);
  const [newTripOpen, setNewTripOpen] = useState(false);
  const [printQuote, setPrintQuote] = useState<QuotationRow | null>(null);
  const [printTrip, setPrintTrip] = useState<TripPackageRow | null>(null);
  const [tripPricingEdit, setTripPricingEdit] = useState<{ includeTax: boolean; markupMode: "percent" | "amount"; markupValue: string } | null>(null);
  const [tripQuery, setTripQuery] = useState("");
  const [itemDraft, setItemDraft] = useState<{
    kind: string;
    catalogId: number;
    priceType: string;
    priceMode: string;
    name: string;
    unitPrice: string;
    persons: number;
    vehicles: number;
    details: string;
  }>({ kind: "service", catalogId: 0, priceType: "shared_one_way", priceMode: "per_person", name: "", unitPrice: "", persons: 2, vehicles: 1, details: "" });

  const pickCatalogItem = (kind: string, catalogId: number) => {
    if (kind === "service") {
      const service = data.services.find((item) => item.id === catalogId);
      const isPrivate = service?.kind === "private_transfer";
      const priceType = isPrivate ? "private_one_way" : "shared_one_way";
      setItemDraft((current) => ({
        ...current,
        kind,
        catalogId,
        name: service?.name ?? "",
        priceType,
        priceMode: service?.priceMode ?? (isPrivate ? "per_vehicle" : "per_person"),
        unitPrice: service ? String(service.oneWayPrice || 0) : "",
        details: service?.details ?? "",
      }));
    } else {
      const tour = data.tours.find((item) => item.id === catalogId);
      setItemDraft((current) => ({
        ...current,
        kind,
        catalogId,
        name: tour?.name ?? "",
        priceType: "ticket_only",
        priceMode: "per_person",
        unitPrice: tour ? String(tour.ticketOnlyPrice || 0) : "",
        details: tour?.details ?? "",
      }));
    }
  };
  const [quoteStatusFilter, setQuoteStatusFilter] = useState<string>("all");
  const [quoteSearchQuery, setQuoteSearchQuery] = useState("");
  const [selectedQuoteIds, setSelectedQuoteIds] = useState<number[]>([]);
  const [viewingQuotation, setViewingQuotation] = useState<QuotationRow | null>(null);
  const [markupEdit, setMarkupEdit] = useState<{ includeTax: boolean; markupMode: MarkupMode; markupValue: string } | null>(null);
  const closeQuotationView = () => {
    setViewingQuotation(null);
    setMarkupEdit(null);
  };
  const [combiningModalOpen, setCombiningModalOpen] = useState(false);
  const [viewingBooking, setViewingBooking] = useState<BookingRow | null>(null);

  const hotelName = (id: number) => data.hotels.find((hotel) => hotel.id === id)?.name ?? "Unknown hotel";
  const groupName = (id: number | null) => (id ? data.hotelGroups.find((group) => group.id === id)?.name ?? "" : "");
  const roomName = (id: number | null) => (id ? data.rooms.find((room) => room.id === id)?.name ?? "Unknown room" : "All room types");

  const contactsFor = (hotelId: number) => {
    const ids = new Set(data.contactAssignments.filter((item) => item.hotelId === hotelId).map((item) => item.contactId));
    return data.contacts.filter((contact) => ids.has(contact.id) && contact.active);
  };
  const groupCandidates = (groupId: number) => groupContactCandidates(groupId, data.contacts.filter((contact) => contact.active), data.contactAssignments, data.hotels);
  const inheritedCandidates = Number(newHotelGroupId) > 0 ? groupCandidates(Number(newHotelGroupId)) : [];
  const isWindowRate = (rate: RateRow) => Boolean(rate.bookingWindowStart || rate.bookingWindowEnd);
  const liveRates = (roomId: number) =>
    data.rates.filter((rate) => rate.roomTypeId === roomId && rate.active && rate.validFrom <= today && rate.validTo >= today);
  const cheapest = (rates: RateRow[]) => rates.slice().sort((a, b) => Number(a.baseRate) - Number(b.baseRate))[0];

  const openNewHotel = () => {
    setFormError("");
    setNewHotelCity("");
    setNewHotelLocationId("");
    setNewHotelGroupId("");
    setNewHotelSharedContactIds([]);
    setNewHotelContactSlots([0, 1]);
    setDialog("hotel");
  };
  const selectHotelGroup = (id: string) => {
    setNewHotelGroupId(id);
    setNewHotelSharedContactIds(Number(id) > 0 ? groupCandidates(Number(id)).map((contact) => contact.id) : []);
  };
  const openHotelContact = (hotelId: number) => {
    setFormError("");
    setManagerGroupId(null);
    setManagerHotelId(null);
    setContactGroupId(0);
    setContactHotel(hotelId);
    setDialog("contact");
  };
  const openGroupContact = (groupId: number) => {
    setFormError("");
    setManagerGroupId(null);
    setManagerHotelId(null);
    setContactHotel(0);
    setContactGroupId(groupId);
    setGroupHotelSelections(data.hotels.filter((hotel) => hotel.groupId === groupId).map((hotel) => hotel.id));
    setDialog("contact");
  };

  const createMarket = async () => {
    if (!newMarket.trim()) return;
    setSaving(true);
    try {
      const response = await fetch("/api/markets", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ label: newMarket }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to add market.");
      setNewMarket("");
      setToast({ type: "success", message: `${result.market.label} added. You can now tick it as not applicable.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to add market." });
    } finally {
      setSaving(false);
    }
  };

  const deleteMarket = async (market: MarketRow) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/markets?id=${market.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to delete market.");
      setToast({ type: "success", message: `${market.label} removed.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to delete market." });
    } finally {
      setSaving(false);
    }
  };

  const deleteContact = async (contact: ContactRow, hotelId: number) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/contacts?id=${contact.id}&hotelId=${hotelId}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to remove contact from this hotel.");
      setToast({ type: "success", message: `${contact.name} removed from ${hotelName(hotelId)} only. Group and other hotel assignments were kept.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to remove contact." });
    } finally {
      setSaving(false);
    }
  };

  const saveInventory = async (roomId: number) => {
    const value = inventoryDraft[roomId];
    if (value === undefined) return;
    setSaving(true);
    try {
      const response = await fetch("/api/rooms", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: roomId, defaultInventory: Number(value) }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to update inventory.");
      setToast({ type: "success", message: "Inventory updated." });
      setInventoryDraft((current) => {
        const next = { ...current };
        delete next[roomId];
        return next;
      });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to update inventory." });
    } finally {
      setSaving(false);
    }
  };

  const duplicateRoom = async (roomId: number) => {
    setSaving(true);
    try {
      const response = await fetch("/api/rooms", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ duplicateFrom: roomId }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to duplicate this room type.");
      setToast({ type: "success", message: `${result.room.name} created with occupancy and extra bedding copied.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to duplicate this room type." });
    } finally {
      setSaving(false);
    }
  };

  const deleteOccupancy = async (id: number) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/occupancy?id=${id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to remove occupancy.");
      setToast({ type: "success", message: "Occupancy combination removed." });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to remove occupancy." });
    } finally {
      setSaving(false);
    }
  };

  // Quotation Actions
  const handleUpdateQuoteStatus = async (quoteId: number, status: string) => {
    setSaving(true);
    try {
      const res = await fetch("/api/quotations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: quoteId, status }),
      });
      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || "Failed to update status.");
      setToast({ type: "success", message: `Quotation status updated to ${status}.` });
      router.refresh();
    } catch (err) {
      setToast({ type: "error", message: err instanceof Error ? err.message : "Failed to update." });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteQuotation = async (quoteId: number) => {
    setSaving(true);
    try {
      const res = await fetch(`/api/quotations?id=${quoteId}`, { method: "DELETE" });
      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || "Failed to delete.");
      setToast({ type: "success", message: "Quotation deleted." });
      if (viewingQuotation?.id === quoteId) closeQuotationView();
      setSelectedQuoteIds((cur) => cur.filter((id) => id !== quoteId));
      router.refresh();
    } catch (err) {
      setToast({ type: "error", message: err instanceof Error ? err.message : "Failed to delete." });
    } finally {
      setSaving(false);
    }
  };

  const handleConvertQuotationToBooking = async (quote: QuotationRow) => {
    setSaving(true);
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ convertQuotationId: quote.id }),
      });
      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || "Conversion failed.");
      setToast({ type: "success", message: `Quotation ${quote.reference} converted to Booking ${resData.booking.reference}!` });
      closeQuotationView();
      router.refresh();
    } catch (err) {
      setToast({ type: "error", message: err instanceof Error ? err.message : "Conversion failed." });
    } finally {
      setSaving(false);
    }
  };

  /**
   * Copies the client proposal in the WhatsApp / email pitch format:
   * hotel details per stay, the daily rate (hotel cost + our markup divided over the nights),
   * the markup-inclusive total, and whether the daily tourism tax is included or excluded.
   */
  const copyWhatsAppQuotation = (quote: QuotationRow) => {
    const items = data.quotationItems.filter((it) => it.quotationId === quote.id).sort((a, b) => a.sortOrder - b.sortOrder);
    const hotelCost = Number(quote.hotelCostTotal) || [quote.baseAmount, quote.boardAmount, quote.occupancyAmount, quote.extraBedAmount].reduce((sum, value) => sum + (Number(value) || 0), 0);
    const markup = Number(quote.markupAmount) || 0;
    const includeTax = quote.includeTax !== false;
    const tax = Number(quote.tourismTaxAmount) || 0;
    const nights = Math.max(1, Number(quote.totalNights) || 1);
    const quotedTotal = Number(quote.quotedTotal) || Number(quote.totalAmount) || 0;
    const dailyTax = tax / nights;
    const money2 = (value: number) => `AED ${value.toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    let text = `🏨 *Proposal: ${quote.title || "Hotel Stay Proposal"}*\n`;
    text += `Ref: ${quote.reference} | Client: ${quote.clientName}${quote.clientCompany ? ` | Company: ${quote.clientCompany}` : ""}\n`;

    items.forEach((it, idx) => {
      const stayCost = [it.baseAmount, it.boardAmount, it.occupancyAmount, it.extraBedAmount].reduce((sum, value) => sum + (Number(value) || 0), 0);
      // Share of our markup for this stay, proportional to what the hotel charges us for it.
      const stayMarkup = hotelCost > 0 ? (markup * stayCost) / hotelCost : markup / Math.max(1, items.length);
      const stayNights = Math.max(1, it.nights || 1);
      const dailyRate = (stayCost + stayMarkup) / stayNights / Math.max(1, it.rooms || 1);
      const hotel = data.hotels.find((h) => h.id === it.hotelId);

      text += `\n📍 *Stay ${idx + 1}:*\n`;
      text += `Hotel Name: *${hotelName(it.hotelId)}*\n`;
      text += `Location: ${hotel && hotel.locationId ? locationName(hotel.locationId) : hotel?.city ?? ""}\n`;
      text += `Room: *${roomName(it.roomTypeId)}*\n`;
      text += `Board: ${boardLabel(it.boardType)}\n`;
      text += `Check In: ${formatDate(it.checkIn)}\n`;
      text += `Check Out: ${formatDate(it.checkOut)}\n`;
      text += `Night: ${it.nights} night${it.nights === 1 ? "" : "s"}\n`;
      text += `Guests: ${it.adults} Adult${it.adults === 1 ? "" : "s"} · ${it.children} Child${it.children === 1 ? "" : "ren"} · ${it.infants} infant${it.infants === 1 ? "" : "s"}\n`;
      text += `Room(s): ${it.rooms}\n`;
      text += `Daily Rate: ${money2(dailyRate)}\n`;
    });

    text += `\n💰 *Total Proposal Cost: ${money2(quotedTotal)}*\n`;
    if (includeTax) text += `*Includes Daily Tourism tax: ${money2(dailyTax)} / night*`;
    else text += `*Excludes Daily Tourism tax: ${money2(dailyTax)} / night*`;
    text += "\n";
    if (quote.validUntil) text += `\n⏳ Proposal valid until: ${formatDate(quote.validUntil)}`;
    if (quote.notes) text += `\n📝 ${quote.notes}`;

    void navigator.clipboard.writeText(text);
    setToast({ type: "success", message: "Proposal copied — paste it into WhatsApp or your email client." });
  };

  const handleCombineSelectedQuotes = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (selectedQuoteIds.length < 2) return;
    setSaving(true);
    const formEl = new FormData(event.currentTarget);
    try {
      const res = await fetch("/api/quotations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          combineQuotationIds: selectedQuoteIds,
          title: formEl.get("title"),
          clientName: formEl.get("clientName"),
          clientCompany: formEl.get("clientCompany"),
          clientEmail: formEl.get("clientEmail"),
          clientPhone: formEl.get("clientPhone"),
          notes: formEl.get("notes"),
        }),
      });
      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || "Failed to combine.");
      setToast({ type: "success", message: `Combined quotation created with reference ${resData.quotation.reference}!` });
      setCombiningModalOpen(false);
      setSelectedQuoteIds([]);
      router.refresh();
    } catch (err) {
      setToast({ type: "error", message: err instanceof Error ? err.message : "Failed to combine." });
    } finally {
      setSaving(false);
    }
  };

  const normalizedSearch = search.trim().toLowerCase();

  const submitForm = async (event: FormEvent<HTMLFormElement>, endpoint: string, successMessage: string, transform?: (value: Record<string, unknown>) => Record<string, unknown>) => {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setToast(null);
    const formData = new FormData(event.currentTarget);
    const raw: Record<string, unknown> = {};
    for (const key of Array.from(new Set(formData.keys()))) {
      const values = formData.getAll(key);
      raw[key] = values.length > 1 ? values : values[0];
    }
    try {
      const response = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(transform ? transform(raw) : raw) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Something went wrong.");
      setDialog(null);
      setToast({ type: "success", message: successMessage });
      router.refresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to save changes.";
      setFormError(message);
      setToast({ type: "error", message });
    } finally {
      setSaving(false);
    }
  };

  // If a stored/selected section is not permitted for this user, fall back to the first allowed one.
  const effectiveView: View = allowed(view) ? view : (visibleNav[0]?.id ?? "search");
  if (effectiveView !== view) {
    if (typeof window !== "undefined") window.sessionStorage.setItem("la_view", effectiveView);
  }

  const navigate = (next: View) => {
    setView(next);
    setMenuOpen(false);
    setSearch("");
    if (typeof window !== "undefined") window.sessionStorage.setItem("la_view", next);
  };

  const upcomingBlackouts = data.blackouts.filter((item) => item.endDate >= today);
  const confirmedValue = data.bookings.filter((booking) => booking.status === "confirmed").reduce((sum, booking) => sum + Number(booking.totalAmount), 0);
  const upcomingArrivals = data.bookings.filter((booking) => booking.checkIn >= today && booking.status !== "cancelled").sort((a, b) => a.checkIn.localeCompare(b.checkIn));
  const page = pageTitles[effectiveView];

  // Filtering Hotels
  const columnMatch = (key: string, value: string) => {
    const query = hotelColumnFilters[key]?.trim().toLowerCase() ?? "";
    return !query || (value || "").toLowerCase().includes(query);
  };
  const hotelMatchesTableFilters = (hotel: HotelRow) =>
    columnMatch("hotel", hotel.name) &&
    columnMatch("group", groupName(hotel.groupId)) &&
    columnMatch("website", hotel.website) &&
    columnMatch("region", `${hotel.city} ${hotel.country}`) &&
    columnMatch("address", hotel.address) &&
    columnMatch("type", hotel.businessType);
  const contactMatchesTableFilters = (contact: ContactRow | null) =>
    columnMatch("email", contact?.email ?? "") &&
    columnMatch("name", contact?.name ?? "") &&
    columnMatch("position", contact?.position ?? "") &&
    columnMatch("phone", contact?.phone ?? "");
  const filteredHotels = data.hotels.filter((hotel) => `${hotel.name} ${hotel.city} ${hotel.supplierCode}`.toLowerCase().includes(normalizedSearch));
  const tableHotels = filteredHotels.filter(hotelMatchesTableFilters);
  const cardQuery = hotelCardQuery.trim().toLowerCase();
  const cardHotels = filteredHotels.filter((hotel) => {
    if (!cardQuery) return true;
    const people = contactsFor(hotel.id).map((contact) => `${contact.name} ${contact.email} ${contact.position}`).join(" ");
    return `${hotel.name} ${hotel.city} ${hotel.country} ${hotel.supplierCode} ${groupName(hotel.groupId)} ${people}`.toLowerCase().includes(cardQuery);
  });
  const blackoutRooms = data.rooms.filter((room) => !blackoutHotelId || room.hotelId === blackoutHotelId);

  const filteredRooms = data.rooms.filter((room) => `${room.name} ${room.code} ${categoryLabel(room.category)} ${hotelName(room.hotelId)}`.toLowerCase().includes(normalizedSearch));
  const filteredRates = data.rates.filter((rate) => (!rateHotel || rate.hotelId === rateHotel) && `${rate.name} ${hotelName(rate.hotelId)} ${roomName(rate.roomTypeId)} ${boardLabel(rate.boardType)}`.toLowerCase().includes(normalizedSearch));
  const filteredBookings = data.bookings.filter((booking) => `${booking.reference} ${booking.guestName} ${hotelName(booking.hotelId)}`.toLowerCase().includes(normalizedSearch));

  // Filtered Quotations
  const filteredQuotations = useMemo(() => {
    return data.quotations.filter((q) => {
      const matchStatus = quoteStatusFilter === "all" || q.status === quoteStatusFilter;
      const qQuery = quoteSearchQuery.trim().toLowerCase();
      const matchSearch =
        !qQuery ||
        `${q.reference} ${q.title} ${q.clientName} ${q.clientCompany} ${q.clientEmail}`.toLowerCase().includes(qQuery);
      return matchStatus && matchSearch;
    });
  }, [data.quotations, quoteStatusFilter, quoteSearchQuery]);

  // Live pricing preview for the quotation being viewed (tax inclusion + our markup).
  const viewingQuoteItems = viewingQuotation
    ? data.quotationItems.filter((it) => it.quotationId === viewingQuotation.id).sort((a, b) => a.sortOrder - b.sortOrder)
    : [];
  const viewingHotelCost =
    viewingQuoteItems.length > 0
      ? viewingQuoteItems.reduce(
          (sum, it) => sum + [it.baseAmount, it.boardAmount, it.occupancyAmount, it.extraBedAmount].reduce((s, v) => s + (Number(v) || 0), 0),
          0,
        )
      : viewingQuotation
        ? [viewingQuotation.baseAmount, viewingQuotation.boardAmount, viewingQuotation.occupancyAmount, viewingQuotation.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0)
        : 0;
  const viewingRooms = viewingQuoteItems.reduce((sum, it) => sum + (it.rooms || 1), 0) || 1;
  const viewingTax = viewingQuotation ? Number(viewingQuotation.tourismTaxAmount) || 0 : 0;
  const viewingPreview =
    viewingQuotation && markupEdit
      ? computeQuotationPricing({
          hotelCostTotal: viewingHotelCost,
          tourismTaxAmount: viewingTax,
          includeTax: markupEdit.includeTax,
          markupMode: markupEdit.markupMode,
          markupValue: Number(markupEdit.markupValue) || 0,
          totalNights: viewingQuotation.totalNights || 1,
          totalRooms: viewingRooms,
        })
      : null;
  const commercialChanged =
    Boolean(viewingQuotation && markupEdit) &&
    viewingQuotation !== null &&
    markupEdit !== null &&
    (viewingQuotation.includeTax !== markupEdit.includeTax ||
      viewingQuotation.markupMode !== markupEdit.markupMode ||
      Math.abs((Number(viewingQuotation.markupValue) || 0) - (Number(markupEdit.markupValue) || 0)) > 0.009);

  const saveQuotationCommercial = async () => {
    if (!viewingQuotation || !markupEdit) return;
    setSaving(true);
    try {
      const res = await fetch("/api/quotations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: viewingQuotation.id,
          includeTax: markupEdit.includeTax,
          markupMode: markupEdit.markupMode,
          markupValue: Number(markupEdit.markupValue) || 0,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to save tax & markup settings.");
      setViewingQuotation(data.quotation);
      setToast({ type: "success", message: "Tax & markup settings saved — totals updated." });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to save settings." });
    } finally {
      setSaving(false);
    }
  };

  /* ---------------- Trip packages ---------------- */

  const tripItemsFor = (packageId: number) =>
    data.tripPackageItems
      .filter((item) => item.packageId === packageId)
      .sort((a, b) => (a.serviceDate ?? "").localeCompare(b.serviceDate ?? "") || (a.serviceTime ?? "").localeCompare(b.serviceTime ?? "") || a.sortOrder - b.sortOrder);

  const hotelItemsFor = (quotationId: number | null) =>
    quotationId ? data.quotationItems.filter((item) => item.quotationId === quotationId).sort((a, b) => a.sortOrder - b.sortOrder) : [];

  const repriceTrip = async (packageId: number) => {
    await fetch("/api/trip-packages", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: packageId, reprice: true }),
    });
    router.refresh();
  };

  const handleCreateTrip = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    const formEl = new FormData(event.currentTarget);
    try {
      const res = await fetch("/api/trip-packages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: formEl.get("title"),
          clientName: formEl.get("clientName"),
          clientEmail: formEl.get("clientEmail"),
          clientPhone: formEl.get("clientPhone"),
          clientCompany: formEl.get("clientCompany"),
          quotationId: formEl.get("quotationId") || null,
          includesHotels: formEl.get("includesHotels") === "on",
          includeTax: formEl.get("includeTax") === "on",
          markupMode: formEl.get("markupMode"),
          markupValue: Number(formEl.get("markupValue")) || 0,
          startDate: formEl.get("startDate") || "",
          endDate: formEl.get("endDate") || "",
          notes: formEl.get("notes") || "",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to create trip package.");
      setNewTripOpen(false);
      navigate("trips");
      setViewingTrip(data.tripPackage);
      setTripPricingEdit({
        includeTax: data.tripPackage.includeTax !== false,
        markupMode: data.tripPackage.markupMode === "amount" ? "amount" : "percent",
        markupValue: data.tripPackage.markupValue || "0",
      });
      setToast({ type: "success", message: `Trip package ${data.tripPackage.reference} created. Now add transfers, tours and tickets.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to create trip package." });
    } finally {
      setSaving(false);
    }
  };

  const handleAddTripItem = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!viewingTrip) return;
    setSaving(true);
    const formEl = new FormData(event.currentTarget);
    try {
      const res = await fetch("/api/trip-package-items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          packageId: viewingTrip.id,
          kind: itemDraft.kind,
          serviceId: itemDraft.kind === "service" ? itemDraft.catalogId : null,
          tourId: itemDraft.kind === "tour" ? itemDraft.catalogId : null,
          name: itemDraft.name,
          priceType: itemDraft.priceType,
          priceMode: itemDraft.priceMode,
          serviceDate: formEl.get("serviceDate") || "",
          serviceTime: formEl.get("serviceTime") || "",
          pickup: formEl.get("pickup") || "",
          dropoff: formEl.get("dropoff") || "",
          persons: itemDraft.persons || 1,
          vehicles: itemDraft.vehicles || 1,
          unitPrice: Number(itemDraft.unitPrice) || 0,
          details: itemDraft.details,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to add this line.");
      setToast({ type: "success", message: `${itemDraft.name} added to the itinerary.` });
      setItemDraft((current) => ({ ...current, catalogId: 0, name: "", unitPrice: "", details: "" }));
      const refreshed = await fetch(`/api/trip-packages?id=${viewingTrip.id}`).then((r) => r.json());
      setViewingTrip(refreshed.tripPackage ?? viewingTrip);
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to add this line." });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTripItem = async (itemId: number) => {
    if (!viewingTrip) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/trip-package-items?id=${itemId}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to remove this line.");
      const refreshed = await fetch(`/api/trip-packages?id=${viewingTrip.id}`).then((r) => r.json());
      setViewingTrip(refreshed.tripPackage ?? viewingTrip);
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to remove this line." });
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateTripStatus = async (packageId: number, status: string) => {
    setSaving(true);
    try {
      const res = await fetch("/api/trip-packages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: packageId, status }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to update status.");
      if (viewingTrip?.id === packageId) setViewingTrip(data.tripPackage);
      setToast({ type: "success", message: `Trip package status set to ${status}.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to update status." });
    } finally {
      setSaving(false);
    }
  };

  const saveTripPricing = async () => {
    if (!viewingTrip || !tripPricingEdit) return;
    setSaving(true);
    try {
      const res = await fetch("/api/trip-packages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: viewingTrip.id,
          includeTax: tripPricingEdit.includeTax,
          markupMode: tripPricingEdit.markupMode,
          markupValue: Number(tripPricingEdit.markupValue) || 0,
          reprice: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to save pricing.");
      setViewingTrip(data.tripPackage);
      setTripPricingEdit({
        includeTax: data.tripPackage.includeTax !== false,
        markupMode: data.tripPackage.markupMode === "amount" ? "amount" : "percent",
        markupValue: data.tripPackage.markupValue || "0",
      });
      setToast({ type: "success", message: "Tax & markup saved — package total updated." });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to save pricing." });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTrip = async (packageId: number) => {
    setSaving(true);
    try {
      const res = await fetch(`/api/trip-packages?id=${packageId}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to delete trip package.");
      setViewingTrip(null);
      setToast({ type: "success", message: "Trip package deleted." });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to delete trip package." });
    } finally {
      setSaving(false);
    }
  };

  /* ---------------- PDF, share & email ---------------- */

  const [passwordOpen, setPasswordOpen] = useState(false);
  const [userFormOpen, setUserFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  const [userRole, setUserRole] = useState("agent");
  const [userPerms, setUserPerms] = useState<string[]>([]);
  const [emailTarget, setEmailTarget] = useState<{ kind: "quotation" | "trip"; id: number } | null>(null);
  const [emailSending, setEmailSending] = useState(false);
  const [shareBusy, setShareBusy] = useState(false);
  const shareSupported = useMemo(() => canShareFiles(), []);
  const showCost = can(currentUser, "view_cost");

  /** Client-facing stay rows: the markup is blended in and never shown separately. */
  const staysForPdf = (items: QuotationItemRow[], hotelCost: number, markup: number, extras = 0): PdfStay[] => {
    const base = hotelCost + extras;
    return items.map((it) => {
      const cost = [it.baseAmount, it.boardAmount, it.occupancyAmount, it.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0);
      const share = base > 0 ? (markup * cost) / base : 0;
      const hotel = data.hotels.find((h) => h.id === it.hotelId);
      return {
        id: it.id,
        hotelName: hotelName(it.hotelId),
        location: hotel ? [locationName(hotel.locationId), hotel.city].filter(Boolean).join(", ") : "",
        roomName: roomName(it.roomTypeId),
        boardType: it.boardType,
        checkIn: it.checkIn,
        checkOut: it.checkOut,
        nights: it.nights,
        adults: it.adults,
        children: it.children,
        infants: it.infants,
        rooms: it.rooms,
        quotedAmount: cost + share,
      };
    });
  };

  const quotationPdf = (quote: QuotationRow) => {
    const items = data.quotationItems.filter((it) => it.quotationId === quote.id).sort((a, b) => a.sortOrder - b.sortOrder);
    const hotelCost = Number(quote.hotelCostTotal) || [quote.baseAmount, quote.boardAmount, quote.occupancyAmount, quote.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0);
    const markup = Number(quote.markupAmount) || 0;
    return buildQuotationPdf(
      {
        reference: quote.reference,
        title: quote.title,
        clientName: quote.clientName,
        clientCompany: quote.clientCompany,
        clientEmail: quote.clientEmail,
        clientPhone: quote.clientPhone,
        validUntil: quote.validUntil,
        notes: quote.notes,
        status: quote.status,
        totalNights: quote.totalNights,
        tourismTaxAmount: Number(quote.tourismTaxAmount) || 0,
        includeTax: quote.includeTax !== false,
        quotedTotal: Number(quote.quotedTotal) || Number(quote.totalAmount) || 0,
        currency: quote.currency,
        createdAt: quote.createdAt,
      },
      staysForPdf(items, hotelCost, markup),
    );
  };

  const tripPdf = (pkg: TripPackageRow) => {
    const hotelItems = hotelItemsFor(pkg.quotationId);
    const lines = tripItemsFor(pkg.id);
    const hotelCost = Number(pkg.hotelCostTotal) || 0;
    const extras = Number(pkg.extrasCostTotal) || 0;
    const markup = Number(pkg.markupAmount) || 0;
    const base = hotelCost + extras;

    const pdfItems: PdfTripItem[] = lines.map((it) => {
      const cost = Number(it.totalAmount) || 0;
      const share = base > 0 ? (markup * cost) / base : 0;
      return {
        id: it.id,
        kind: it.kind,
        name: it.name,
        priceType: it.priceType,
        serviceDate: it.serviceDate,
        serviceTime: it.serviceTime,
        pickup: it.pickup,
        dropoff: it.dropoff,
        persons: it.persons,
        vehicles: it.vehicles,
        details: it.details,
        quotedAmount: cost + share,
      };
    });

    return buildTripPackagePdf(
      {
        reference: pkg.reference,
        title: pkg.title,
        clientName: pkg.clientName,
        clientCompany: pkg.clientCompany,
        clientEmail: pkg.clientEmail,
        clientPhone: pkg.clientPhone,
        status: pkg.status,
        startDate: pkg.startDate,
        endDate: pkg.endDate,
        includesHotels: pkg.includesHotels,
        includeTax: pkg.includeTax !== false,
        tourismTaxAmount: Number(pkg.tourismTaxAmount) || 0,
        hotelQuotedTotal: hotelCost + (base > 0 ? (markup * hotelCost) / base : 0),
        extrasQuotedTotal: extras + (base > 0 ? (markup * extras) / base : 0),
        quotedTotal: Number(pkg.quotedTotal) || Number(pkg.totalAmount) || 0,
        currency: pkg.currency,
        notes: pkg.notes,
        createdAt: pkg.createdAt,
      },
      staysForPdf(hotelItems, hotelCost, markup, extras),
      pdfItems,
    );
  };

  const shareCaption = (reference: string, title: string, clientName: string, total: string) =>
    `Proposal: ${title}\nRef: ${reference} | Client: ${clientName}\nTotal: ${total}\n\nThe full PDF is attached.`;

  const handleDownload = (kind: "quotation" | "trip", id: number) => {
    const quote = kind === "quotation" ? data.quotations.find((q) => q.id === id) : null;
    const pkg = kind === "trip" ? data.tripPackages.find((p) => p.id === id) : null;
    const source = quote ?? pkg;
    if (!source) return;
    const pdf = quote ? quotationPdf(quote) : tripPdf(pkg!);
    downloadPdf(pdf, pdfFileName(source.reference, source.title));
    setToast({ type: "success", message: "PDF downloaded." });
  };

  /** Shares the real PDF file through the device share sheet (WhatsApp, Telegram, Mail…). */
  const handleSharePdf = async (kind: "quotation" | "trip", id: number, messenger?: "whatsapp" | "telegram") => {
    const quote = kind === "quotation" ? data.quotations.find((q) => q.id === id) : null;
    const pkg = kind === "trip" ? data.tripPackages.find((p) => p.id === id) : null;
    const source = quote ?? pkg;
    if (!source) return;

    setShareBusy(true);
    try {
      const pdf = quote ? quotationPdf(quote) : tripPdf(pkg!);
      const fileName = pdfFileName(source.reference, source.title);
      const total = formatMoney(source.quotedTotal || source.totalAmount, source.currency);
      const caption = shareCaption(source.reference, source.title, source.clientName, total);

      if (messenger) {
        downloadPdf(pdf, fileName);
        openMessenger(messenger, caption, source.clientPhone);
        setToast({
          type: "success",
          message: `PDF downloaded and ${messenger === "whatsapp" ? "WhatsApp" : "Telegram"} opened — attach ${fileName} to the chat.`,
        });
        return;
      }

      const outcome = await sharePdfFile(pdf, fileName, source.title, caption);
      if (outcome === "shared") setToast({ type: "success", message: "PDF shared." });
      else if (outcome === "downloaded") setToast({ type: "success", message: `Your browser cannot attach files directly — ${fileName} was downloaded instead.` });
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to share this PDF." });
    } finally {
      setShareBusy(false);
    }
  };

  const handleSendEmail = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!emailTarget) return;
    setEmailSending(true);
    const formEl = new FormData(event.currentTarget);
    try {
      const quote = emailTarget.kind === "quotation" ? data.quotations.find((q) => q.id === emailTarget.id) : null;
      const pkg = emailTarget.kind === "trip" ? data.tripPackages.find((p) => p.id === emailTarget.id) : null;
      const source = quote ?? pkg;
      if (!source) throw new Error("Proposal not found.");

      const pdf = quote ? quotationPdf(quote) : tripPdf(pkg!);
      const base64 = pdf.output("datauristring").split(",")[1];

      const res = await fetch("/api/email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: formEl.get("to"),
          cc: formEl.get("cc"),
          subject: formEl.get("subject"),
          message: formEl.get("message"),
          pdfBase64: base64,
          fileName: pdfFileName(source.reference, source.title),
        }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Email failed.");
      setEmailTarget(null);
      setToast({ type: "success", message: result.message || "Email sent." });
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Email failed." });
    } finally {
      setEmailSending(false);
    }
  };

  const saveSmtp = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    const formEl = new FormData(event.currentTarget);
    try {
      const res = await fetch("/api/email", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          host: formEl.get("host"),
          port: Number(formEl.get("port")) || 587,
          secure: formEl.get("secure") === "true",
          username: formEl.get("username"),
          password: formEl.get("password"),
          fromName: formEl.get("fromName"),
          fromEmail: formEl.get("fromEmail"),
          replyTo: formEl.get("replyTo"),
          bccSelf: formEl.get("bccSelf") === "on",
          active: formEl.get("active") === "on",
        }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Unable to save SMTP settings.");
      setToast({ type: "success", message: "SMTP settings saved." });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to save SMTP settings." });
    } finally {
      setSaving(false);
    }
  };

  const sendTestEmail = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "test", to: currentUser.email }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Test email failed.");
      setToast({ type: "success", message: result.message || "Test email sent." });
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Test email failed." });
    } finally {
      setSaving(false);
    }
  };

  const saveUser = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    const formEl = new FormData(event.currentTarget);
    const payload: Record<string, unknown> = {
      name: formEl.get("name"),
      phone: formEl.get("phone"),
      role: userRole,
      permissions: userRole === "admin" ? [...ROLE_PRESETS.admin.permissions] : userPerms,
      password: formEl.get("password") || undefined,
    };
    try {
      const res = await fetch("/api/users", {
        method: editingUser ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingUser ? { ...payload, id: editingUser.id, active: formEl.get("active") === "on" } : { ...payload, email: formEl.get("email") }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Unable to save user.");
      setUserFormOpen(false);
      setEditingUser(null);
      setToast({ type: "success", message: editingUser ? "User updated." : "User created." });
      router.refresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to save user.";
      setFormError(message);
      setToast({ type: "error", message });
    } finally {
      setSaving(false);
    }
  };

  const deleteUser = async (person: AppUser) => {
    setSaving(true);
    try {
      const res = await fetch(`/api/users?id=${person.id}`, { method: "DELETE" });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Unable to delete user.");
      setToast({ type: "success", message: `${person.name} removed.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to delete user." });
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    const formEl = new FormData(event.currentTarget);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "change-password",
          currentPassword: formEl.get("currentPassword"),
          newPassword: formEl.get("newPassword"),
        }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Unable to change password.");
      setPasswordOpen(false);
      setToast({ type: "success", message: "Password updated." });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to change password.";
      setFormError(message);
      setToast({ type: "error", message });
    } finally {
      setSaving(false);
    }
  };

  const logout = async () => {
    await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "logout" }) });
    if (typeof window !== "undefined") window.sessionStorage.removeItem("la_view");
    router.replace("/login");
    router.refresh();
  };

  const addAction: Partial<Record<View, { label: string; dialog: Dialog }>> = {
    hotels: { label: "Add hotel", dialog: "hotel" },
    rooms: { label: "Add room type", dialog: "room" },
    rates: { label: "Add rate plan", dialog: "rate" },
    blackouts: { label: "Add blackout dates", dialog: "blackout" },
  };

  const bookingTable = (rows: BookingRow[]) => (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[980px] text-left">
        <thead className="bg-slate-50/70 text-[10px] uppercase tracking-[0.08em] text-slate-400">
          <tr>
            <th className="px-5 py-3.5">Reference / guest</th>
            <th className="px-4 py-3.5">Hotel & Stays</th>
            <th className="px-4 py-3.5">Stay Dates</th>
            <th className="px-4 py-3.5">Guests</th>
            <th className="px-4 py-3.5">Board</th>
            <th className="px-4 py-3.5">Net total</th>
            <th className="px-5 py-3.5">Status</th>
            <th className="px-4 py-3.5 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((booking) => {
            const bItems = data.bookingItems.filter((it) => it.bookingId === booking.id);
            const isMulti = bItems.length > 1;

            return (
              <tr key={booking.id} className="text-sm transition hover:bg-slate-50/60">
                <td className="px-5 py-4">
                  <div className="flex items-center gap-1.5 font-extrabold text-[#175a53]">
                    {booking.reference}
                    {isMulti && <span className="rounded bg-teal-100 px-1.5 py-0.5 text-[9px] font-bold text-teal-800">{bItems.length} Stays</span>}
                    {booking.quotationId && <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[9px] font-bold text-sky-800">From Quote</span>}
                  </div>
                  <div className="mt-1 text-xs font-semibold text-slate-700">{booking.guestName}</div>
                  <div className="mt-0.5 text-[10px] text-slate-400">{booking.guestEmail}</div>
                </td>
                <td className="px-4 py-4">
                  {isMulti ? (
                    <div className="space-y-1">
                      {bItems.map((it, idx) => (
                        <div key={it.id} className="text-xs">
                          <span className="font-bold text-slate-800">{idx + 1}. {hotelName(it.hotelId)}</span>
                          <span className="text-[10px] text-slate-400"> · {roomName(it.roomTypeId)} ({it.nights} nts)</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <>
                      <div className="max-w-[230px] truncate text-xs font-bold text-slate-700">{hotelName(booking.hotelId)}</div>
                      <div className="mt-1 max-w-[230px] truncate text-[10px] text-slate-400">{roomName(booking.roomTypeId)}</div>
                    </>
                  )}
                </td>
                <td className="px-4 py-4">
                  <div className="text-xs font-semibold text-slate-600">{formatDate(booking.checkIn, { day: "2-digit", month: "short" })} – {formatDate(booking.checkOut)}</div>
                  <div className="mt-1 text-[10px] text-slate-400">{booking.nights} nights · {booking.rooms} room{booking.rooms > 1 ? "s" : ""}</div>
                </td>
                <td className="px-4 py-4 text-xs text-slate-600">{booking.adults}A · {booking.children}C · {booking.infants}I</td>
                <td className="px-4 py-4 text-xs text-slate-600">{boardLabel(booking.boardType)}</td>
                <td className="px-4 py-4">
                  <div className="font-extrabold text-slate-900">{formatMoney(booking.totalAmount, booking.currency)}</div>
                  <div className="mt-1 text-[10px] text-slate-400">incl. {formatMoney(booking.tourismTaxAmount)} tax</div>
                </td>
                <td className="px-5 py-4"><StatusBadge status={booking.status} /></td>
                <td className="px-4 py-4 text-right">
                  <button
                    onClick={() => setViewingBooking(booking)}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50"
                  >
                    <Eye size={13} /> View
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {rows.length === 0 && (
        <div className="grid place-items-center px-6 py-16 text-center">
          <MoonStar size={26} className="text-slate-300" />
          <div className="mt-3 text-sm font-bold text-slate-700">No reservations found</div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f7f9] text-slate-900">
      {dialog && formError && <div role="alert" className="fixed right-4 top-4 z-[100] flex max-w-md items-start gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-800 shadow-xl"><AlertTriangle size={18} className="mt-0.5 shrink-0" /><span className="flex-1">{formError}</span><button type="button" onClick={() => setFormError("")} aria-label="Dismiss error" className="rounded p-0.5 hover:bg-rose-100"><X size={16} /></button></div>}
      {menuOpen && <button className="fixed inset-0 z-30 bg-slate-950/40 md:hidden" onClick={() => setMenuOpen(false)} aria-label="Close navigation" />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[252px] flex-col border-r border-slate-200/80 bg-white transition-transform duration-300 md:translate-x-0 ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex h-[78px] items-center gap-3 border-b border-slate-100 px-6">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#164e48] text-white shadow-lg shadow-teal-900/15"><Hotel size={21} strokeWidth={2.2} /></div>
          <div>
            <div className="text-[15px] font-extrabold tracking-tight text-slate-950">Luxury Attractions</div>
            <div className="mt-0.5 text-[10px] font-bold uppercase tracking-[0.16em] text-[#b27a4b]">Hotel contracts</div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-3.5 py-6">
          <p className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Workspace</p>
          <nav className="space-y-1">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              const active = effectiveView === item.id;
              const firstContract = visibleNav.find((nav) => ["hotels", "rooms", "rates", "blackouts"].includes(nav.id))?.id === item.id;
              const firstAdmin = item.id === "admin";
              return (
                <div key={item.id}>
                  {firstContract && <p className="mb-2 mt-6 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Contracts</p>}
                  {firstAdmin && <p className="mb-2 mt-6 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Administration</p>}
                  <button onClick={() => navigate(item.id)} className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-left text-sm font-semibold transition ${active ? "bg-[#eaf4f2] text-[#14544d]" : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"}`}>
                    <Icon size={18} strokeWidth={active ? 2.3 : 1.9} />
                    <span className="flex-1">{item.label}</span>
                    {item.id === "quotations" && data.quotations.length > 0 && (
                      <span className="rounded-full bg-teal-100 px-2 py-0.5 text-[10px] font-extrabold text-teal-800">{data.quotations.length}</span>
                    )}
                    {item.id === "blackouts" && upcomingBlackouts.length > 0 && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-700">{upcomingBlackouts.length}</span>}
                  </button>
                </div>
              );
            })}
          </nav>
          <div className="mt-8 rounded-2xl bg-[#173f3b] p-4 text-white">
            <div className="flex items-center gap-2 text-xs font-bold text-teal-100"><Sparkles size={14} /> Multi-Stay Quotations</div>
            <p className="mt-2 text-[11px] leading-5 text-teal-50/80">Add multiple hotel stays to create custom itineraries (e.g. 2 nts Al Khoory Executive + 2 nts Sky Garden) and convert directly to bookings.</p>
          </div>
        </div>
        <div className="border-t border-slate-100 p-4">
          <div className="flex items-center gap-3 rounded-xl p-2">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#dcece9] text-xs font-extrabold text-[#15554e]">
              {currentUser.name.split(" ").filter(Boolean).slice(0, 2).map((word) => word[0]).join("").toUpperCase() || "LA"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold">{currentUser.name}</p>
              <p className="truncate text-[11px] capitalize text-slate-400">{ROLE_PRESETS[currentUser.role]?.label ?? currentUser.role}</p>
            </div>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button onClick={() => setPasswordOpen(true)} className="inline-flex h-8 items-center justify-center gap-1.5 rounded-lg border border-slate-200 text-[11px] font-bold text-slate-600 hover:bg-slate-50">
              <KeyRound size={13} /> Password
            </button>
            <button onClick={() => void logout()} className="inline-flex h-8 items-center justify-center gap-1.5 rounded-lg border border-rose-200 text-[11px] font-bold text-rose-700 hover:bg-rose-50">
              <LogOut size={13} /> Sign out
            </button>
          </div>
        </div>
      </aside>

      <main className="min-h-screen md:pl-[252px]">
        <header className="sticky top-0 z-20 flex h-[78px] items-center gap-4 border-b border-slate-200/80 bg-white/95 px-4 backdrop-blur md:px-7 lg:px-9">
          <button onClick={() => setMenuOpen(true)} className="rounded-xl border border-slate-200 p-2 text-slate-600 md:hidden" aria-label="Open navigation"><Menu size={20} /></button>
          {effectiveView !== "search" && effectiveView !== "dashboard" && effectiveView !== "quotations" ? (
            <div className="relative hidden w-full max-w-md sm:block">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={`Search ${pageTitles[effectiveView].title.toLowerCase()}…`} className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/70 pl-10 pr-4 text-sm outline-none transition focus:border-teal-600 focus:bg-white focus:ring-4 focus:ring-teal-700/10" />
            </div>
          ) : (
            <div className="hidden text-sm font-bold text-slate-500 sm:block">{data.hotels.length} contracted hotels · {data.rooms.length} room types · {data.quotations.length} active quotations</div>
          )}
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-500 lg:flex"><CircleDot size={13} className="text-emerald-500" /> Net rates in AED</div>
            {effectiveView !== "search" && can(currentUser, "search") && (
              <button onClick={() => navigate("search")} className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a]"><Search size={16} /> <span className="hidden sm:inline">Search rates</span></button>
            )}
          </div>
        </header>

        <div className="mx-auto max-w-[1540px] p-4 md:p-7 lg:p-9">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a66e42]"><Sparkles size={13} /> {page.eyebrow}</div>
              <h1 className="text-2xl font-extrabold tracking-[-0.025em] text-slate-950 md:text-[30px]">{page.title}</h1>
              <p className="mt-1.5 text-sm text-slate-500">{page.copy}</p>
            </div>
            {addAction[effectiveView] && can(currentUser, VIEW_PERMISSION[effectiveView]) && (
              <button onClick={() => {
                if (effectiveView === "hotels") { openNewHotel(); return; }
                if (effectiveView === "rooms") { setOccupancySlots([0, 1]); setDialog("room"); return; }
                if (effectiveView === "blackouts") { setBlackoutHotelId(data.hotels[0]?.id ?? 0); setBlackoutRoomId(0); setBlackoutRoomQuery(""); setDialog("blackout"); return; }
                if (effectiveView === "rates") { setRateHotelId(data.hotels[0]?.id ?? 0); setRateRoomId(0); setDialog("rate"); return; }
                setDialog(addAction[effectiveView]!.dialog);
              }} className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a]"><Plus size={17} /> {addAction[effectiveView]!.label}</button>
            )}
          </div>

          {toast && (
            <div className={`mb-5 flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold ${toast.type === "success" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-rose-200 bg-rose-50 text-rose-800"}`}>
              {toast.type === "success" ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />}
              <span className="flex-1">{toast.message}</span>
              <button onClick={() => setToast(null)} aria-label="Dismiss"><X size={16} /></button>
            </div>
          )}

          {/* SEARCH & COMPARE VIEW */}
          <div className={effectiveView === "search" ? "" : "hidden"}>
            <SearchPanel
              initial={initialSearch}
              cities={cities}
              locationsByCity={locationsByCity}
              amenityOptions={data.amenities.map((amenity) => ({ slug: amenity.slug, label: amenity.label, icon: amenity.icon }))}
              categoryOptions={data.roomCategories.map((category) => ({ slug: category.slug, label: category.label }))}
              onBooked={(reference) => {
                setToast({ type: "success", message: `Booking confirmed — reference ${reference}. It has been added to the bookings ledger.` });
                router.refresh();
              }}
              onQuotationSaved={(reference) => {
                setToast({ type: "success", message: `Quotation proposal ${reference} saved! You can retrieve it in the Quotations tab.` });
                router.refresh();
              }}
            />
          </div>

          {/* QUOTATIONS VIEW */}
          {effectiveView === "quotations" && (
            <div className="space-y-6">
              {/* Metrics */}
              <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "Active Quotations", value: data.quotations.length, note: `${data.quotationItems.length} total hotel stay segments`, icon: FileSpreadsheet, tone: "bg-teal-50 text-teal-700" },
                  { label: "Multi-Hotel Itineraries", value: data.quotations.filter((q) => data.quotationItems.filter((it) => it.quotationId === q.id).length > 1).length, note: "Combined twin/multi-stay quotes", icon: Layers, tone: "bg-indigo-50 text-indigo-700" },
                  { label: "Converted to Bookings", value: data.quotations.filter((q) => q.status === "converted").length, note: "Successfully turned into reservations", icon: CheckCircle2, tone: "bg-emerald-50 text-emerald-700" },
                  { label: "Pipeline Value", value: formatMoney(data.quotations.reduce((sum, q) => sum + Number(q.totalAmount), 0)), note: "Total quoted revenue in AED", icon: WalletCards, tone: "bg-violet-50 text-violet-700" },
                ].map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <div key={stat.label} className={`${card} p-5`}>
                      <div className="flex items-start justify-between">
                        <div className={`grid h-10 w-10 place-items-center rounded-xl ${stat.tone}`}>
                          <Icon size={19} />
                        </div>
                      </div>
                      <div className="mt-4 text-[25px] font-extrabold tracking-tight text-slate-950">{stat.value}</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-700">{stat.label}</div>
                      <div className="mt-2 text-[11px] text-slate-400">{stat.note}</div>
                    </div>
                  );
                })}
              </section>

              {/* Toolbar & Filters */}
              <div className={`${card} p-4`}>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative min-w-[240px]">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
                      <input
                        value={quoteSearchQuery}
                        onChange={(e) => setQuoteSearchQuery(e.target.value)}
                        placeholder="Search quote ref, client, title, company…"
                        className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/70 pl-9 pr-3 text-xs font-semibold outline-none focus:border-teal-600 focus:bg-white"
                      />
                    </div>

                    <div className="flex items-center rounded-xl bg-slate-100 p-1 text-xs font-bold">
                      {["all", "draft", "sent", "accepted", "converted"].map((st) => (
                        <button
                          key={st}
                          onClick={() => setQuoteStatusFilter(st)}
                          className={`rounded-lg px-3 py-1.5 capitalize transition ${quoteStatusFilter === st ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-800"}`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {selectedQuoteIds.length >= 2 && (
                      <button
                        onClick={() => setCombiningModalOpen(true)}
                        className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-extrabold text-white shadow-md shadow-teal-900/15 hover:bg-[#103f3a]"
                      >
                        <Layers size={15} /> Combine Selected ({selectedQuoteIds.length}) into 1 Itinerary
                      </button>
                    )}
                    <button
                      onClick={() => navigate("search")}
                      className="inline-flex h-10 items-center gap-2 rounded-xl border border-teal-200 bg-teal-50 px-4 text-xs font-bold text-teal-800 hover:bg-teal-100"
                    >
                      <Plus size={15} /> New Quote from Search
                    </button>
                  </div>
                </div>

                {selectedQuoteIds.length > 0 && selectedQuoteIds.length < 2 && (
                  <div className="mt-3 text-xs text-amber-700">
                    💡 Select 1 more quotation to combine them into a single multi-hotel itinerary proposal.
                  </div>
                )}
              </div>

              {/* Quotations Table */}
              <div className={`${card} overflow-hidden`}>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1050px] text-left">
                    <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                      <tr>
                        <th className="w-10 px-4 py-3.5">
                          <input
                            type="checkbox"
                            checked={filteredQuotations.length > 0 && selectedQuoteIds.length === filteredQuotations.length}
                            onChange={(e) => setSelectedQuoteIds(e.target.checked ? filteredQuotations.map((q) => q.id) : [])}
                            className="accent-teal-700"
                            aria-label="Select all"
                          />
                        </th>
                        <th className="px-4 py-3.5">Reference & Proposal Title</th>
                        <th className="px-4 py-3.5">Client & Company</th>
                        <th className="px-4 py-3.5">Hotel Stays / Itinerary</th>
                        <th className="px-4 py-3.5">Nights & Dates</th>
                        <th className="px-4 py-3.5">Net Quoted Total</th>
                        <th className="px-4 py-3.5">Status</th>
                        <th className="px-4 py-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredQuotations.map((quote) => {
                        const items = data.quotationItems.filter((it) => it.quotationId === quote.id);
                        const isMulti = items.length > 1;
                        const isSelected = selectedQuoteIds.includes(quote.id);

                        return (
                          <tr key={quote.id} className={`text-sm transition hover:bg-slate-50/60 ${isSelected ? "bg-teal-50/40" : ""}`}>
                            <td className="px-4 py-4">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={(e) => setSelectedQuoteIds((cur) => e.target.checked ? [...cur, quote.id] : cur.filter((id) => id !== quote.id))}
                                className="accent-teal-700"
                                aria-label={`Select quote ${quote.reference}`}
                              />
                            </td>
                            <td className="px-4 py-4">
                              <div className="flex items-center gap-2 font-extrabold text-[#175a53]">
                                <span>{quote.reference}</span>
                                {isMulti && (
                                  <span className="rounded bg-teal-100 px-1.5 py-0.5 text-[9px] font-bold text-teal-800">
                                    {items.length} Stays
                                  </span>
                                )}
                              </div>
                              <div className="mt-0.5 text-xs font-bold text-slate-800">{quote.title || "Custom Proposal"}</div>
                              <div className="mt-0.5 text-[10px] text-slate-400">Created {formatDate(quote.createdAt)}</div>
                            </td>
                            <td className="px-4 py-4">
                              <div className="font-bold text-slate-800">{quote.clientName}</div>
                              {quote.clientCompany && <div className="text-[11px] font-medium text-slate-500">{quote.clientCompany}</div>}
                              {quote.clientPhone && <div className="text-[10px] text-slate-400">{quote.clientPhone}</div>}
                            </td>
                            <td className="max-w-[320px] px-4 py-4">
                              <div className="space-y-1">
                                {items.map((it, idx) => (
                                  <div key={it.id} className="truncate text-xs">
                                    <span className="font-bold text-slate-800">{idx + 1}. {hotelName(it.hotelId)}</span>
                                    <span className="text-[10px] text-slate-500"> ({roomName(it.roomTypeId)} · {it.nights} nts · {boardLabel(it.boardType)})</span>
                                  </div>
                                ))}
                                {items.length === 0 && <span className="text-xs text-slate-400">No stays loaded</span>}
                              </div>
                            </td>
                            <td className="px-4 py-4">
                              <div className="text-xs font-bold text-slate-700">{quote.totalNights} nights</div>
                              {items[0] && items[items.length - 1] && (
                                <div className="mt-0.5 text-[10px] text-slate-500">
                                  {formatDate(items[0].checkIn, { day: "2-digit", month: "short" })} → {formatDate(items[items.length - 1].checkOut, { day: "2-digit", month: "short" })}
                                </div>
                              )}
                            </td>
                            <td className="px-4 py-4">
                              <div className="font-extrabold text-slate-900">{formatMoney(quote.totalAmount, quote.currency)}</div>
                              <div className="mt-0.5 text-[10px] text-slate-400">
                                {Number(quote.markupAmount) > 0 ? `+${formatMoney(quote.markupAmount)} markup · ` : ""}
                                {quote.includeTax ? "incl. " : "excl. "}{formatMoney(quote.tourismTaxAmount)} tax
                              </div>
                            </td>
                            <td className="px-4 py-4">
                              <div className="relative inline-block">
                                <select
                                  value={quote.status}
                                  onChange={(e) => void handleUpdateQuoteStatus(quote.id, e.target.value)}
                                  className="cursor-pointer appearance-none rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-bold text-slate-700 outline-none hover:bg-slate-50 focus:border-teal-600"
                                >
                                  <option value="draft">Draft</option>
                                  <option value="sent">Sent</option>
                                  <option value="accepted">Accepted</option>
                                  <option value="converted">Converted</option>
                                  <option value="expired">Expired</option>
                                </select>
                              </div>
                            </td>
                            <td className="px-4 py-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setViewingQuotation(quote);
                                    setMarkupEdit({
                                      includeTax: quote.includeTax !== false,
                                      markupMode: quote.markupMode === "amount" ? "amount" : "percent",
                                      markupValue: quote.markupValue || "0",
                                    });
                                  }}
                                  className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                                  title="View detailed proposal breakdown"
                                >
                                  <Eye size={14} />
                                </button>
                                <button
                                  type="button"
                                  disabled={shareBusy}
                                  onClick={() => void handleSharePdf("quotation", quote.id)}
                                  className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-teal-50 hover:text-teal-800 disabled:opacity-50"
                                  title={shareSupported ? "Share PDF (WhatsApp, Telegram, Mail…)" : "Download PDF to share"}
                                >
                                  <ShareIcon size={14} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDownload("quotation", quote.id)}
                                  className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50"
                                  title="Download PDF"
                                >
                                  <Download size={14} />
                                </button>
                                {can(currentUser, "send_email") && (
                                  <button
                                    type="button"
                                    onClick={() => setEmailTarget({ kind: "quotation", id: quote.id })}
                                    className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-sky-50 hover:text-sky-700"
                                    title="Email this quotation"
                                  >
                                    <Mail size={14} />
                                  </button>
                                )}
                                {quote.status !== "converted" && (
                                  <button
                                    type="button"
                                    onClick={() => void handleConvertQuotationToBooking(quote)}
                                    className="inline-flex items-center gap-1 rounded-lg bg-[#174e48] px-2.5 py-1.5 text-xs font-bold text-white hover:bg-[#103f3a]"
                                    title="Convert this quote directly into a confirmed reservation"
                                  >
                                    <BookOpenCheck size={13} /> Convert
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => void handleDeleteQuotation(quote.id)}
                                  className="rounded-lg p-2 text-slate-300 hover:bg-rose-50 hover:text-rose-600"
                                  title="Delete quotation"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {filteredQuotations.length === 0 && (
                    <div className="grid place-items-center px-6 py-16 text-center">
                      <FileSpreadsheet size={28} className="text-slate-300" />
                      <div className="mt-3 text-sm font-bold text-slate-700">No quotations found</div>
                      <p className="mt-1 text-xs text-slate-400">Search for hotel stays and click &ldquo;+ Add to Quote&rdquo; to create your first client proposal.</p>
                      <button
                        onClick={() => navigate("search")}
                        className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-[#174e48] px-4 py-2 text-xs font-bold text-white"
                      >
                        <Search size={14} /> Search Rates & Build Quote
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TRIP PACKAGES VIEW */}
          {effectiveView === "trips" && (
            <div className="space-y-6">
              <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "Trip packages", value: data.tripPackages.length, note: `${data.services.length} services · ${data.tours.length} tours/tickets`, icon: Route, tone: "bg-teal-50 text-teal-700" },
                  { label: "Hotel stays linked", value: data.tripPackages.filter((p) => p.quotationId).length, note: "Packages carrying a saved quotation", icon: FileSpreadsheet, tone: "bg-indigo-50 text-indigo-700" },
                  { label: "Extras (tours & transfers)", value: formatMoney(data.tripPackages.reduce((sum, p) => sum + (Number(p.extrasCostTotal) || 0), 0)), note: "Total cost of added services", icon: TicketPercent, tone: "bg-amber-50 text-amber-700" },
                  { label: "Package pipeline value", value: formatMoney(data.tripPackages.reduce((sum, p) => sum + (Number(p.quotedTotal) || Number(p.totalAmount) || 0), 0)), note: "Client-facing totals incl. markup", icon: WalletCards, tone: "bg-violet-50 text-violet-700" },
                ].map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <div key={stat.label} className={`${card} p-5`}>
                      <div className="grid h-10 w-10 place-items-center rounded-xl ${stat.tone}"><Icon size={19} /></div>
                      <div className="mt-4 text-[25px] font-extrabold tracking-tight text-slate-950">{stat.value}</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-700">{stat.label}</div>
                      <div className="mt-2 text-[11px] text-slate-400">{stat.note}</div>
                    </div>
                  );
                })}
              </section>

              <div className={`${card} flex flex-wrap items-center justify-between gap-3 p-4`}>
                <div className="relative min-w-[280px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
                  <input value={tripQuery} onChange={(event) => setTripQuery(event.target.value)} placeholder="Search package ref, title or client…" className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/70 pl-9 pr-3 text-xs font-semibold outline-none focus:border-teal-600 focus:bg-white" />
                </div>
                <button onClick={() => setNewTripOpen(true)} className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-extrabold text-white shadow-md shadow-teal-900/15 hover:bg-[#103f3a]">
                  <PackagePlus size={16} /> New trip package
                </button>
              </div>

              <div className={`${card} overflow-hidden`}>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1120px] text-left">
                    <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                      <tr>
                        <th className="px-4 py-3.5">Package</th>
                        <th className="px-4 py-3.5">Client</th>
                        <th className="px-4 py-3.5">Dates</th>
                        <th className="px-4 py-3.5">Itinerary lines</th>
                        <th className="px-4 py-3.5">Hotels stay</th>
                        <th className="px-4 py-3.5">Extras</th>
                        <th className="px-4 py-3.5">Package total</th>
                        <th className="px-4 py-3.5">Status</th>
                        <th className="px-4 py-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.tripPackages
                        .filter((pkg) => {
                          const q = tripQuery.trim().toLowerCase();
                          return !q || `${pkg.reference} ${pkg.title} ${pkg.clientName} ${pkg.clientCompany}`.toLowerCase().includes(q);
                        })
                        .map((pkg) => {
                          const lines = tripItemsFor(pkg.id);
                          const hotelItems = hotelItemsFor(pkg.quotationId);
                          return (
                            <tr key={pkg.id} className="text-sm hover:bg-slate-50/60">
                              <td className="px-4 py-4">
                                <div className="font-extrabold text-[#175a53]">{pkg.reference}</div>
                                <div className="mt-0.5 text-xs font-bold text-slate-800">{pkg.title}</div>
                                <div className="mt-0.5 text-[10px] text-slate-400">{pkg.clientCompany || "Individual guest"}</div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="font-semibold text-slate-700">{pkg.clientName}</div>
                                <div className="text-[10px] text-slate-400">{pkg.clientEmail}</div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="text-xs font-semibold text-slate-600">{pkg.startDate ? formatDate(pkg.startDate, { day: "2-digit", month: "short", year: "numeric" }) : "TBC"}</div>
                                <div className="text-[10px] text-slate-400">{pkg.endDate ? `→ ${formatDate(pkg.endDate, { day: "2-digit", month: "short", year: "numeric" })}` : "open"}</div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="text-xs font-bold">{lines.length} line{lines.length === 1 ? "" : "s"}</div>
                                <div className="text-[10px] text-slate-400">{lines.filter((l) => l.kind === "service").length} services · {lines.filter((l) => l.kind === "tour").length} tours/tickets</div>
                              </td>
                              <td className="px-4 py-4">
                                {pkg.quotationId ? (
                                  <>
                                    <div className="text-xs font-bold text-slate-700">{hotelItems.length} stay{hotelItems.length === 1 ? "" : "s"}</div>
                                    <div className="text-[10px] text-slate-400">{formatMoney(pkg.hotelCostTotal)} net hotel cost</div>
                                  </>
                                ) : (
                                  <span className="text-[11px] text-slate-400">No hotel stay</span>
                                )}
                              </td>
                              <td className="px-4 py-4 text-xs font-bold">{formatMoney(pkg.extrasCostTotal)}</td>
                              <td className="px-4 py-4">
                                <div className="font-extrabold text-slate-900">{formatMoney(pkg.quotedTotal || pkg.totalAmount, pkg.currency)}</div>
                                <div className="text-[10px] text-slate-400">{Number(pkg.markupAmount) > 0 ? `+${formatMoney(pkg.markupAmount)} markup · ` : ""}{pkg.includeTax ? "incl." : "excl."} tax</div>
                              </td>
                              <td className="px-4 py-4">
                                <select value={pkg.status} onChange={(event) => void handleUpdateTripStatus(pkg.id, event.target.value)} className="cursor-pointer rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-bold text-slate-700 outline-none hover:bg-slate-50 focus:border-teal-600">
                                  {["draft", "sent", "confirmed", "completed", "cancelled"].map((st) => <option key={st} value={st}>{st}</option>)}
                                </select>
                              </td>
                              <td className="px-4 py-4 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  <button onClick={() => { setViewingTrip(pkg); setTripPricingEdit({ includeTax: pkg.includeTax !== false, markupMode: pkg.markupMode === "amount" ? "amount" : "percent", markupValue: pkg.markupValue || "0" }); }} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 hover:text-slate-900" title="View & edit itinerary"><Eye size={14} /></button>
                                  <button disabled={shareBusy} onClick={() => void handleSharePdf("trip", pkg.id)} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-teal-50 hover:text-teal-800 disabled:opacity-50" title={shareSupported ? "Share PDF (WhatsApp, Telegram, Mail…)" : "Download PDF to share"}><ShareIcon size={14} /></button>
                                  <button onClick={() => handleDownload("trip", pkg.id)} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50" title="Download PDF"><Download size={14} /></button>
                                  {can(currentUser, "send_email") && (
                                    <button onClick={() => setEmailTarget({ kind: "trip", id: pkg.id })} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-sky-50 hover:text-sky-700" title="Email this package"><Mail size={14} /></button>
                                  )}
                                  <button onClick={() => setPrintTrip(pkg)} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50" title="Print preview"><Printer size={14} /></button>
                                  <button onClick={() => void handleDeleteTrip(pkg.id)} className="rounded-lg p-2 text-slate-300 hover:bg-rose-50 hover:text-rose-600" title="Delete"><Trash2 size={14} /></button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                  {data.tripPackages.length === 0 && (
                    <div className="grid place-items-center px-6 py-16 text-center">
                      <Route size={28} className="text-slate-300" />
                      <div className="mt-3 text-sm font-bold text-slate-700">No trip packages yet</div>
                      <p className="mt-1 max-w-md text-xs text-slate-400">Create a package to sell airport pick up & drop back, tours and tickets alongside your hotel quotation — then export the whole itinerary as a PDF.</p>
                      <button onClick={() => setNewTripOpen(true)} className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-[#174e48] px-4 py-2 text-xs font-bold text-white"><PackagePlus size={14} /> Create first package</button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ADMIN: USERS & SETTINGS */}
          {effectiveView === "admin" && can(currentUser, "users") && (
            <div className="space-y-6">
              <section className={`${card} overflow-hidden`}>
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
                  <div>
                    <h2 className="font-extrabold">Staff accounts</h2>
                    <p className="mt-1 text-xs text-slate-400">{users.length} user{users.length === 1 ? "" : "s"} · roles set what each person can open and whether they see net cost and markup.</p>
                  </div>
                  <button onClick={() => { setEditingUser(null); setUserRole("agent"); setUserPerms([...ROLE_PRESETS.agent.permissions]); setFormError(""); setUserFormOpen(true); }} className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-extrabold text-white hover:bg-[#103f3a]">
                    <UserPlus size={15} /> Add user
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[900px] text-left">
                    <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                      <tr>
                        <th className="px-5 py-3.5">Name & email</th>
                        <th className="px-4 py-3.5">Role</th>
                        <th className="px-4 py-3.5">Permissions</th>
                        <th className="px-4 py-3.5">Last sign in</th>
                        <th className="px-4 py-3.5">Status</th>
                        <th className="px-5 py-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users.map((person) => {
                        const perms = person.permissions.split(",").filter(Boolean);
                        return (
                          <tr key={person.id} className="text-sm hover:bg-slate-50/60">
                            <td className="px-5 py-4">
                              <div className="font-bold text-slate-800">{person.name}{person.id === currentUser.id && <span className="ml-2 rounded bg-teal-50 px-1.5 py-0.5 text-[9px] font-bold text-teal-700">You</span>}</div>
                              <div className="mt-0.5 text-[11px] text-slate-400">{person.email}</div>
                            </td>
                            <td className="px-4 py-4"><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold capitalize text-slate-700">{ROLE_PRESETS[person.role]?.label ?? person.role}</span></td>
                            <td className="max-w-[300px] px-4 py-4">
                              <div className="text-[11px] text-slate-500">{person.role === "admin" ? "All permissions" : `${perms.length} permission${perms.length === 1 ? "" : "s"}`}</div>
                              {person.role !== "admin" && perms.includes("view_cost") && <div className="mt-0.5 text-[10px] font-bold text-amber-700">Can see net cost & markup</div>}
                            </td>
                            <td className="px-4 py-4 text-[11px] text-slate-500">{person.lastLoginAt ? formatDate(person.lastLoginAt) : "Never"}</td>
                            <td className="px-4 py-4"><StatusBadge status={person.active ? "active" : "disabled"} /></td>
                            <td className="px-5 py-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button onClick={() => { setEditingUser(person); setUserRole(person.role); setUserPerms(person.permissions.split(",").filter(Boolean)); setFormError(""); setUserFormOpen(true); }} className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 hover:bg-slate-50">Edit</button>
                                {person.id !== currentUser.id && (
                                  <button onClick={() => void deleteUser(person)} className="rounded-lg p-2 text-slate-300 hover:bg-rose-50 hover:text-rose-600" title="Delete user"><Trash2 size={14} /></button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </section>

              {can(currentUser, "settings") && (
                <section className={`${card} p-5`}>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="flex items-center gap-2 font-extrabold"><Mail size={17} className="text-[#174e48]" /> Email (SMTP)</h2>
                      <p className="mt-1 text-xs text-slate-400">Used to email quotations and trip packages with the PDF attached.</p>
                    </div>
                    <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${smtp?.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                      {smtp?.active ? "Active" : "Not configured"}
                    </span>
                  </div>

                  <form onSubmit={saveSmtp} className="mt-4 grid gap-4 md:grid-cols-2">
                    <Field label="SMTP host"><input name="host" required defaultValue={smtp?.host ?? ""} className={inputClass} placeholder="smtp.gmail.com" /></Field>
                    <div className="grid grid-cols-2 gap-3">
                      <Field label="Port"><input name="port" type="number" min="1" defaultValue={smtp?.port ?? 587} className={inputClass} /></Field>
                      <Field label="Encryption"><SelectWrap><select name="secure" defaultValue={smtp?.secure ? "true" : "false"} className={selectClass}><option value="false">STARTTLS (587)</option><option value="true">SSL/TLS (465)</option></select></SelectWrap></Field>
                    </div>
                    <Field label="SMTP username"><input name="username" defaultValue={smtp?.username ?? ""} className={inputClass} placeholder="sales@luxuryattractions.com" /></Field>
                    <Field label="SMTP password" hint={smtp?.password ? "Leave blank to keep the saved password." : "App password recommended for Gmail / Outlook."}>
                      <input name="password" type="password" className={inputClass} placeholder={smtp?.password ? "•••••••• (saved)" : "App password"} />
                    </Field>
                    <Field label="From name"><input name="fromName" defaultValue={smtp?.fromName ?? "Luxury Attractions"} className={inputClass} /></Field>
                    <Field label="From email"><input name="fromEmail" type="email" required defaultValue={smtp?.fromEmail ?? ""} className={inputClass} placeholder="sales@luxuryattractions.com" /></Field>
                    <Field label="Reply-to (optional)"><input name="replyTo" type="email" defaultValue={smtp?.replyTo ?? ""} className={inputClass} /></Field>
                    <div className="flex flex-col justify-end gap-2">
                      <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs font-bold text-slate-700"><input name="active" type="checkbox" defaultChecked={smtp?.active ?? false} className="accent-teal-700" /> Enable email sending</label>
                      <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs font-bold text-slate-700"><input name="bccSelf" type="checkbox" defaultChecked={smtp?.bccSelf ?? false} className="accent-teal-700" /> BCC a copy to the from-address</label>
                    </div>
                    <div className="flex flex-wrap justify-end gap-2 border-t border-slate-100 pt-4 md:col-span-2">
                      <button type="button" disabled={saving} onClick={() => void sendTestEmail()} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-4 text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50">
                        <SendIcon size={15} /> Send test email
                      </button>
                      <button disabled={saving} className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white hover:bg-[#103f3a] disabled:opacity-60">
                        {saving ? <Loader2 size={16} className="animate-spin" /> : <Settings size={16} />} Save SMTP settings
                      </button>
                    </div>
                  </form>
                </section>
              )}
            </div>
          )}

          {/* DASHBOARD OVERVIEW VIEW */}
          {effectiveView === "dashboard" && (
            <>
              <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "Contracted hotels", value: data.hotels.length, note: `${cities.length} emirates / cities`, icon: Building2, tone: "bg-teal-50 text-teal-700", target: "hotels" as View },
                  { label: "Client Quotations", value: data.quotations.length, note: `${data.quotationItems.length} total stay segments`, icon: FileSpreadsheet, tone: "bg-indigo-50 text-indigo-700", target: "quotations" as View },
                  { label: "Active blackout periods", value: upcomingBlackouts.length, note: "Excluded from search results", icon: CalendarX2, tone: "bg-amber-50 text-amber-700", target: "blackouts" as View },
                  { label: "Confirmed value", value: formatMoney(confirmedValue), note: `${data.bookings.length} reservations on file`, icon: WalletCards, tone: "bg-violet-50 text-violet-700", target: "bookings" as View },
                ].map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <button key={stat.label} onClick={() => navigate(stat.target)} className={`${card} group p-5 text-left transition hover:-translate-y-0.5 hover:shadow-lg`}>
                      <div className="flex items-start justify-between"><div className={`grid h-10 w-10 place-items-center rounded-xl ${stat.tone}`}><Icon size={19} /></div><ArrowUpRight size={16} className="text-slate-300 transition group-hover:text-slate-600" /></div>
                      <div className="mt-4 text-[25px] font-extrabold tracking-tight text-slate-950">{stat.value}</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-700">{stat.label}</div>
                      <div className="mt-2 text-[11px] text-slate-400">{stat.note}</div>
                    </button>
                  );
                })}
              </section>
              <section className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.5fr)_minmax(320px,.8fr)]">
                <div className={`${card} overflow-hidden`}>
                  <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4"><div><h2 className="font-extrabold text-slate-950">Upcoming arrivals</h2><p className="mt-1 text-xs text-slate-400">Next check-ins across all hotels</p></div><button onClick={() => navigate("bookings")} className="flex items-center gap-1 text-xs font-bold text-[#166159]">All bookings <ArrowUpRight size={14} /></button></div>
                  {bookingTable(upcomingArrivals.slice(0, 6))}
                </div>
                <div className={`${card} p-5`}>
                  <div className="flex items-center justify-between"><h2 className="font-extrabold text-slate-950">Recent Quotation Proposals</h2><button onClick={() => navigate("quotations")} className="text-[11px] font-bold text-[#166159]">View all</button></div>
                  <div className="mt-4 space-y-3">
                    {data.quotations.slice(0, 4).map((q) => {
                      const qItems = data.quotationItems.filter((it) => it.quotationId === q.id);
                      return (
                        <div key={q.id} className="rounded-xl border border-slate-100 p-3 hover:border-teal-200">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="font-bold text-slate-800">{q.title}</div>
                              <div className="text-[11px] text-slate-500">{q.clientName} · {q.totalNights} nts · {qItems.length} stay{qItems.length > 1 ? "s" : ""}</div>
                            </div>
                            <span className="font-extrabold text-[#174e48]">{formatMoney(q.totalAmount)}</span>
                          </div>
                        </div>
                      );
                    })}
                    {data.quotations.length === 0 && <p className="text-xs text-slate-400">No quotations created yet.</p>}
                  </div>
                </div>
              </section>
            </>
          )}

          {/* HOTELS VIEW */}
          {effectiveView === "hotels" && (
            <>
            <section className={`${card} mb-5 flex flex-wrap items-center justify-between gap-4 px-5 py-4`}>
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">Amenity types</h2>
                <p className="mt-1 text-xs text-slate-400">These appear as filters in search. Add new ones as your contracts grow.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {data.amenities.map((amenity) => (
                  <span key={amenity.id} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200" title={`${data.hotelAmenities.filter((link) => link.amenityId === amenity.id).length} hotels`}>
                    <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={12} />
                    <span className="text-slate-400">{data.hotelAmenities.filter((link) => link.amenityId === amenity.id).length}</span>
                  </span>
                ))}
                <button onClick={() => setDialog("amenity")} className="inline-flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-1.5 text-[11px] font-bold text-white"><Plus size={13} /> Add amenity</button>
              </div>
            </section>
            <section className={`${card} mb-5 flex flex-wrap items-center justify-between gap-3 px-5 py-4`}>
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">Hotel groups & contacts</h2>
                <p className="mt-1 text-xs text-slate-400">
                  {data.hotelGroups.length} group{data.hotelGroups.length === 1 ? "" : "s"} · {data.contacts.length} contacts · one sales team can cover every property in a group
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="grid grid-cols-2 rounded-xl bg-slate-100 p-1 text-[11px] font-bold">
                  {(["table", "cards"] as const).map((layout) => (
                    <button key={layout} onClick={() => setHotelLayout(layout)} className={`rounded-lg px-3 py-1.5 transition ${hotelLayout === layout ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"}`}>
                      {layout === "table" ? "Table view" : "Card view"}
                    </button>
                  ))}
                </div>
                <button onClick={() => setDialog("group")} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-600"><Plus size={13} /> Add group</button>
                <button onClick={() => setManagerGroupId(data.hotelGroups[0]?.id ?? null)} disabled={!data.hotelGroups.length} className="inline-flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 py-1.5 text-[11px] font-bold text-teal-800 hover:bg-teal-100 disabled:opacity-50"><UsersRound size={13} /> Manage group contacts</button>
                {hotelLayout === "cards" && (
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                    <input value={hotelCardQuery} onChange={(event) => setHotelCardQuery(event.target.value)} placeholder="Search hotels…" className="h-8 w-44 rounded-lg border border-slate-200 bg-white pl-8 pr-3 text-[11px] font-semibold text-slate-700 outline-none focus:border-teal-600 sm:w-56" />
                  </div>
                )}
                <button onClick={() => openHotelContact(data.hotels[0]?.id ?? 0)} className="inline-flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-1.5 text-[11px] font-bold text-white"><Plus size={13} /> Add contact</button>
              </div>
            </section>

            {hotelLayout === "table" && (
              <section className={`${card} mb-5 overflow-hidden`}>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1500px] text-left text-xs">
                    <thead className="bg-[#174e48] text-[10px] uppercase tracking-[0.06em] text-white">
                      <tr>
                        <th className="px-3 py-3">Hotel</th>
                        <th className="px-3 py-3">Group</th>
                        <th className="px-3 py-3">Website</th>
                        <th className="px-3 py-3">Email</th>
                        <th className="px-3 py-3">Name</th>
                        <th className="px-3 py-3">Position</th>
                        <th className="px-3 py-3">Contact No</th>
                        <th className="px-3 py-3">Chat</th>
                        <th className="px-3 py-3">Region/Country</th>
                        <th className="px-3 py-3">Address</th>
                        <th className="px-3 py-3">Business Type</th>
                        <th className="px-3 py-3">Contracts</th>
                        <th className="px-3 py-3">Media</th>
                        <th className="px-3 py-3">Business Card</th>
                        <th className="px-3 py-3"></th>
                      </tr>
                      <tr className="bg-white text-[11px] font-medium normal-case tracking-normal text-slate-700">
                        {[
                          ["hotel", "Hotel"],
                          ["group", "Group"],
                          ["website", "Website"],
                          ["email", "Email"],
                          ["name", "Name"],
                          ["position", "Position"],
                          ["phone", "Phone"],
                          ["", ""],
                          ["region", "City / country"],
                          ["address", "Address"],
                          ["type", "Type"],
                          ["", ""],
                          ["", ""],
                          ["", ""],
                          ["", ""],
                        ].map(([key, placeholder], index) => (
                          <th key={`${key}-${index}`} className="px-2 py-2 font-medium">
                            {key ? (
                              <input
                                value={hotelColumnFilters[key] ?? ""}
                                onChange={(event) => setHotelColumnFilters((current) => ({ ...current, [key]: event.target.value }))}
                                placeholder={placeholder}
                                className="h-8 w-full min-w-[88px] rounded-md border border-slate-200 bg-slate-50 px-2 text-[11px] font-semibold text-slate-700 outline-none placeholder:font-medium placeholder:normal-case placeholder:text-slate-400 focus:border-teal-600 focus:bg-white"
                              />
                            ) : null}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {tableHotels.flatMap((hotel) => {
                        const contacts = contactsFor(hotel.id);
                        const rows = contacts.length > 0 ? contacts : [null];
                        const visible = rows.filter((contact) => contactMatchesTableFilters(contact));
                        if (visible.length === 0) return [];
                        return visible.map((contact, rowIndex) => (
                          <tr key={`${hotel.id}-${contact?.id ?? "none"}`} className="align-top hover:bg-slate-50/60">
                            <td className="border-l-4 border-[#0ea5b7] px-3 py-3 font-bold text-slate-900">
                              {rowIndex === 0 && <><div>{hotel.name}</div><button onClick={() => setManagerHotelId(hotel.id)} className="mt-1.5 text-[10px] font-bold text-teal-700 hover:underline">Manage contacts</button></>}
                            </td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? groupName(hotel.groupId) || "—" : ""}</td>
                            <td className="px-3 py-3">{rowIndex === 0 && hotel.website ? <a href={hotel.website} target="_blank" rel="noreferrer" className="text-sky-700 underline">{hotel.website.replace(/^https?:\/\//, "")}</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3">{contact?.email ? <a href={`mailto:${contact.email}`} className="text-sky-700 underline">{contact.email}</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3 font-semibold text-slate-800">{contact?.name ?? "No contact added"}</td>
                            <td className="px-3 py-3 text-slate-600">{contact?.position || "—"}</td>
                            <td className="px-3 py-3 whitespace-nowrap font-semibold text-slate-700">{contact?.phone || "—"}</td>
                            <td className="px-3 py-3">
                              <div className="flex gap-1">
                                {contact?.whatsapp && contact.phone && <a href={messagingLink("whatsapp", contact.phone)} target="_blank" rel="noreferrer" title="WhatsApp" className="rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700">WA</a>}
                                {contact?.telegram && contact.phone && <a href={messagingLink("telegram", contact.phone)} target="_blank" rel="noreferrer" title="Telegram" className="rounded bg-sky-50 px-1.5 py-0.5 text-[10px] font-bold text-sky-700">TG</a>}
                                {contact?.viber && contact.phone && <a href={messagingLink("viber", contact.phone)} target="_blank" rel="noreferrer" title="Viber" className="rounded bg-violet-50 px-1.5 py-0.5 text-[10px] font-bold text-violet-700">VB</a>}
                                {!contact?.phone && <span className="text-slate-300">—</span>}
                              </div>
                              {contact?.otherContact && <div className="mt-1 text-[10px] text-slate-500">{contact.otherContact}</div>}
                            </td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? `${locationName(hotel.locationId) ? `${locationName(hotel.locationId)}, ` : ""}${hotel.city}, ${hotel.country}` : ""}</td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? hotel.address || "—" : ""}</td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? hotel.businessType : ""}</td>
                            <td className="px-3 py-3">{rowIndex === 0 && hotel.contractsFolderLink ? <a href={hotel.contractsFolderLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">Folder</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3">{rowIndex === 0 && hotel.mediaLink ? <a href={hotel.mediaLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded bg-violet-50 px-1.5 py-0.5 text-[10px] font-bold text-violet-700">Media</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3">{contact?.businessCardLink ? <a href={contact.businessCardLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">Card</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3">{contact && <button disabled={saving} onClick={() => void deleteContact(contact, hotel.id)} className="rounded p-1 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" title={`Remove ${contact.name} from ${hotel.name} only`} aria-label={`Remove ${contact.name} from ${hotel.name} only`}><Trash2 size={14} /></button>}</td>
                          </tr>
                        ));
                      })}
                    </tbody>
                  </table>
                  {tableHotels.length === 0 && <div className="px-6 py-10 text-center text-sm text-slate-500">No hotels match these column filters.</div>}
                </div>
              </section>
            )}

            <section className={hotelLayout === "cards" ? "grid gap-4 md:grid-cols-2 xl:grid-cols-3" : "hidden"}>
              {cardHotels.length === 0 && <div className={`${card} col-span-full px-6 py-10 text-center text-sm text-slate-500`}>No hotels match “{hotelCardQuery}”.</div>}
              {cardHotels.map((hotel, index) => {
                const hotelRooms = data.rooms.filter((room) => room.hotelId === hotel.id);
                const hotelRates = data.rates.filter((rate) => rate.hotelId === hotel.id);
                const colors = ["from-[#174e48] to-[#247267]", "from-[#263d5d] to-[#3e6089]", "from-[#5c4736] to-[#8a6a4f]"];
                return (
                  <article key={hotel.id} className={`${card} overflow-hidden transition hover:-translate-y-0.5 hover:shadow-lg`}>
                    <div className={`bg-gradient-to-br ${colors[index % colors.length]} p-5 text-white`}>
                      <div className="flex items-start justify-between"><div className="grid h-11 w-11 place-items-center rounded-xl bg-white/15 text-sm font-extrabold ring-1 ring-white/15">{hotelInitials(hotel.name)}</div><span className="rounded-full bg-white/12 px-2.5 py-1 text-[10px] font-bold ring-1 ring-white/15">{hotel.supplierCode}</span></div>
                      <h2 className="mt-5 text-lg font-extrabold">{hotel.name}</h2>
                      <div className="mt-1.5 flex items-center gap-2 text-xs text-white/70"><MapPin size={13} /> {locationName(hotel.locationId) ? `${locationName(hotel.locationId)}, ` : ""}{hotel.city}, {hotel.country}</div>
                      {groupName(hotel.groupId) && <div className="mt-1 text-[11px] font-semibold text-white/60">Part of {groupName(hotel.groupId)}</div>}
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {hotel.website && <a href={hotel.website} target="_blank" rel="noreferrer" className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">Website</a>}
                        {hotel.contractsFolderLink && <a href={hotel.contractsFolderLink} target="_blank" rel="noreferrer" className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">Contracts folder</a>}
                        {hotel.mediaLink && <a href={hotel.mediaLink} target="_blank" rel="noreferrer" className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">Media</a>}
                        <span className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">{hotel.businessType}</span>
                      </div>
                      <div className="mt-3 flex">{Array.from({ length: hotel.starRating }).map((_, star) => <Star key={star} size={12} className="fill-[#e7b980] text-[#e7b980]" />)}</div>
                    </div>
                    <div className="p-5">
                      <div className="grid grid-cols-3 divide-x divide-slate-100 text-center">
                        <div><div className="text-lg font-extrabold">{hotelRooms.length}</div><div className="text-[10px] text-slate-400">Room types</div></div>
                        <div><div className="text-lg font-extrabold">{hotelRates.length}</div><div className="text-[10px] text-slate-400">Rate lines</div></div>
                        <div><div className="text-lg font-extrabold">{Number(hotel.tourismTax)}</div><div className="text-[10px] text-slate-400">Tax AED</div></div>
                      </div>
                      <div className="mt-4">
                        <button type="button" onClick={() => setExpandedHotelRates((current) => current === hotel.id ? null : hotel.id)} className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-left">
                          <span className="text-xs font-extrabold text-slate-800">Room types & rates · {hotelRooms.length}</span>
                          <ChevronDown size={15} className={`text-slate-400 transition ${expandedHotelRates === hotel.id ? "rotate-180" : ""}`} />
                        </button>
                        {expandedHotelRates === hotel.id && (
                          <div className="mt-2 space-y-2">
                            {hotelRooms.length === 0 && <p className="rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-400">No room types yet.</p>}
                            {hotelRooms.map((room) => {
                              const current = liveRates(room.id);
                              const windowRate = cheapest(current.filter(isWindowRate));
                              const normalRate = cheapest(current.filter((rate) => !isWindowRate(rate)));
                              return (
                                <div key={room.id} className="rounded-xl border border-slate-100 p-3">
                                  <div className="flex items-start justify-between gap-2">
                                    <div>
                                      <div className="text-xs font-extrabold text-slate-800">{room.name}</div>
                                      <div className="mt-0.5 text-[10px] text-slate-400">Sleeps {room.baseSleeps} · {room.defaultInventory} rooms</div>
                                    </div>
                                    {room.mediaLink && <a href={room.mediaLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-md bg-violet-50 px-1.5 py-1 text-[10px] font-bold text-violet-700"><Images size={11} /> Media</a>}
                                  </div>
                                  <div className="mt-2 flex flex-wrap gap-1.5">
                                    {normalRate && <span className="rounded-md border border-teal-200 bg-teal-50 px-2 py-1 text-[10px] font-bold text-teal-800">Normal · {boardLabel(normalRate.boardType)} {formatMoney(normalRate.baseRate)}</span>}
                                    {windowRate && <span className="rounded-md border border-amber-200 bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-800">Booking window · {boardLabel(windowRate.boardType)} {formatMoney(windowRate.baseRate)}{windowRate.promoCode ? ` · ${windowRate.promoCode}` : ""}</span>}
                                    {!normalRate && !windowRate && <span className="text-[10px] text-slate-400">No live rate for today</span>}
                                  </div>
                                </div>
                              );
                            })}
                            <div className="flex flex-wrap gap-2 pt-1 text-[10px] font-semibold">
                              <span className="rounded bg-teal-50 px-2 py-1 text-teal-800">Teal = normal contracted rate</span>
                              <span className="rounded bg-amber-50 px-2 py-1 text-amber-800">Amber = booking-window / promo only</span>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="mt-5 border-t border-slate-100 pt-4">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Amenities</span>
                          <button
                            onClick={() => { setAmenityEditHotel(hotel.id); setDialog("hotelAmenities"); }}
                            className="text-[10px] font-bold text-[#166159]"
                          >
                            Edit
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {hotelAmenityIds(hotel.id).map((amenityId) => {
                            const amenity = amenityById(amenityId);
                            if (!amenity) return null;
                            return (
                              <span key={amenityId} className="inline-flex items-center gap-1 rounded-md bg-slate-50 px-2 py-1 text-[10px] font-bold text-slate-600 ring-1 ring-slate-200">
                                <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={11} />
                              </span>
                            );
                          })}
                          {hotelAmenityIds(hotel.id).length === 0 && <span className="text-[11px] text-slate-400">None set</span>}
                        </div>
                      </div>
                      <div className="mt-4 space-y-2.5 border-t border-slate-100 pt-4 text-xs text-slate-500">
                        <div className="flex items-center justify-between"><span className="flex items-center gap-2"><Clock3 size={14} /> Check-in / out</span><b className="text-slate-700">{hotel.checkInTime} / {hotel.checkOutTime}</b></div>
                        <div className="flex items-center justify-between"><span>Tax basis</span><b className="text-slate-700">{hotel.tourismTaxBasis.replace("_", " / ")}</b></div>
                      </div>
                      <div className="mt-4 border-t border-slate-100 pt-4">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Contacts ({contactsFor(hotel.id).length})</span>
                          <div className="flex items-center gap-3"><button onClick={() => setManagerHotelId(hotel.id)} className="text-[10px] font-bold text-[#166159]">Manage</button><button onClick={() => openHotelContact(hotel.id)} className="text-[10px] font-bold text-[#166159]">Add new</button></div>
                        </div>
                        <div className="space-y-2">
                          {contactsFor(hotel.id).map((contact) => (
                            <div key={contact.id} className="rounded-xl border border-slate-100 p-2.5">
                              <div className="flex items-start justify-between gap-2">
                                <div className="min-w-0">
                                  <div className="truncate text-xs font-bold text-slate-800">{contact.name}</div>
                                  <div className="truncate text-[10px] text-slate-500">{contact.position}</div>
                                </div>
                                <button disabled={saving} onClick={() => void deleteContact(contact, hotel.id)} className="rounded p-1 text-slate-300 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" title={`Remove only from ${hotel.name}`} aria-label={`Remove ${contact.name} from ${hotel.name}`}><Trash2 size={13} /></button>
                              </div>
                              {contact.email && <a href={`mailto:${contact.email}`} className="mt-1 block truncate text-[10px] text-sky-700 underline">{contact.email}</a>}
                              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                                {contact.phone && <span className="text-[10px] font-semibold text-slate-600">{contact.phone}</span>}
                                {contact.whatsapp && contact.phone && <a href={messagingLink("whatsapp", contact.phone)} target="_blank" rel="noreferrer" className="rounded bg-emerald-50 px-1.5 py-0.5 text-[9px] font-bold text-emerald-700">WhatsApp</a>}
                                {contact.telegram && contact.phone && <a href={messagingLink("telegram", contact.phone)} target="_blank" rel="noreferrer" className="rounded bg-sky-50 px-1.5 py-0.5 text-[9px] font-bold text-sky-700">Telegram</a>}
                                {contact.viber && contact.phone && <a href={messagingLink("viber", contact.phone)} target="_blank" rel="noreferrer" className="rounded bg-violet-50 px-1.5 py-0.5 text-[9px] font-bold text-violet-700">Viber</a>}
                                {contact.businessCardLink && <a href={contact.businessCardLink} target="_blank" rel="noreferrer" className="rounded bg-slate-100 px-1.5 py-0.5 text-[9px] font-bold text-slate-600">Card</a>}
                              </div>
                              {contact.otherContact && <div className="mt-1 text-[10px] text-slate-500">Other: {contact.otherContact}</div>}
                            </div>
                          ))}
                          {contactsFor(hotel.id).length === 0 && <p className="text-[11px] text-slate-400">No contacts yet.</p>}
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
            </section>
            </>
          )}

          {/* ROOMS VIEW */}
          {effectiveView === "rooms" && (
            <>
            <section className={`${card} mb-5 flex flex-wrap items-center justify-between gap-4 px-5 py-4`}>
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">Search categories</h2>
                <p className="mt-1 text-xs text-slate-400">These are the room types guests can search for across all hotels. Add your own if a contract needs one.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {data.roomCategories.map((category) => (
                  <span key={category.id} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200" title={`${data.rooms.filter((room) => room.category === category.slug).length} room types`}>
                    {category.label}
                    <span className="text-slate-400">{data.rooms.filter((room) => room.category === category.slug).length}</span>
                  </span>
                ))}
                <button onClick={() => setDialog("category")} className="inline-flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-1.5 text-[11px] font-bold text-white"><Plus size={13} /> Add category</button>
              </div>
            </section>
            <section className={`${card} overflow-hidden`}>
              <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-extrabold">Room inventory</h2><p className="mt-1 text-xs text-slate-400">{filteredRooms.length} room types · the category is what search uses to compare hotels (e.g. every “Triple Room”)</p></div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[980px] text-left">
                  <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                    <tr><th className="px-5 py-3.5">Room & hotel</th><th className="px-4 py-3.5">Category</th><th className="px-4 py-3.5">Sleeps / max occupancy</th><th className="px-4 py-3.5">Permitted combinations</th><th className="px-4 py-3.5">Extra bedding</th><th className="px-4 py-3.5">Inventory</th><th className="px-5 py-3.5">Actions</th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredRooms.map((room) => (
                      <tr key={room.id} className="text-sm hover:bg-slate-50/60">
                        <td className="px-5 py-4"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-teal-50 text-teal-700"><BedDouble size={17} /></div><div><div className="font-bold text-slate-800">{room.name}</div><div className="mt-0.5 text-[11px] text-slate-400">{hotelName(room.hotelId)} · {room.code}</div></div></div></td>
                        <td className="px-4 py-4"><span className="rounded-md bg-teal-50 px-2 py-1 text-[10px] font-extrabold uppercase text-teal-700">{categoryLabel(room.category)}</span></td>
                        <td className="px-4 py-4 text-xs text-slate-600"><b className="text-slate-800">Sleeps {room.baseSleeps}</b><div className="mt-0.5">{room.maxAdults} adults · {room.maxChildren} children · {room.maxInfants} infants</div></td>
                        <td className="max-w-[260px] px-4 py-4">
                          <div className="flex flex-wrap gap-1">{data.occupancies.filter((rule) => rule.roomTypeId === room.id).map((rule) => <span key={rule.id} title={rule.label} className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-1.5 py-1 text-[10px] font-semibold text-slate-500">{rule.label}<button type="button" onClick={() => void deleteOccupancy(rule.id)} className="text-slate-300 hover:text-rose-600" aria-label={`Remove ${rule.label}`}><X size={10} /></button></span>)}</div>
                          <button type="button" onClick={() => { setOccupancyRoomId(room.id); setDialog("occupancy"); }} className="mt-2 text-[10px] font-bold text-[#166159]">+ Add occupancy</button>
                        </td>
                        <td className="max-w-[240px] px-4 py-4">
                          <div className="flex flex-wrap gap-1">
                            {beddingFor(room.id).map((option) => (
                              <span key={option.id} className={`rounded-md px-1.5 py-1 text-[10px] font-bold ${option.free ? "bg-emerald-50 text-emerald-700" : "bg-violet-50 text-violet-700"}`} title={option.perStay ? "Charged once per stay" : "Charged per night"}>
                                {option.label} ×{option.maxPerRoom}{option.free ? " free" : ` ${Number(option.ratePerNight)}`}
                              </span>
                            ))}
                            {beddingFor(room.id).length === 0 && <span className="text-[11px] text-slate-400">None</span>}
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-1.5">
                            <input type="number" min="0" value={inventoryDraft[room.id] ?? String(room.defaultInventory)} onChange={(event) => setInventoryDraft((current) => ({ ...current, [room.id]: event.target.value }))} className="h-9 w-16 rounded-lg border border-slate-200 px-2 text-xs font-bold" />
                            <button type="button" disabled={saving || inventoryDraft[room.id] === undefined} onClick={() => void saveInventory(room.id)} className="rounded-lg bg-slate-900 px-2 py-1.5 text-[10px] font-bold text-white disabled:opacity-40">Save</button>
                          </div>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex flex-wrap items-center gap-1.5">
                            {room.mediaLink && <a href={room.mediaLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-lg bg-violet-50 px-2 py-1.5 text-[10px] font-bold text-violet-700"><Images size={12} /> Media</a>}
                            <button type="button" disabled={saving} onClick={() => void duplicateRoom(room.id)} className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-2 py-1.5 text-[10px] font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50"><Copy size={12} /> Duplicate</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
            </>
          )}

          {/* RATES VIEW */}
          {effectiveView === "rates" && (
            <section className={`${card} overflow-hidden`}>
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
                <div><h2 className="font-extrabold">Seasonal rate lines</h2><p className="mt-1 text-xs text-slate-400">{filteredRates.length} lines · net AED · shorter periods (e.g. festive peak) override the season they fall in</p></div>
                <div className="w-full sm:w-72"><SelectWrap><select value={rateHotel} onChange={(event) => setRateHotel(Number(event.target.value))} className={`${selectClass} h-10`}><option value={0}>All hotels</option>{data.hotels.map((hotel) => <option key={hotel.id} value={hotel.id}>{hotel.name}</option>)}</select></SelectWrap></div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1320px] text-left">
                  <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                    <tr><th className="px-5 py-3.5">Rate & hotel</th><th className="px-4 py-3.5">Room</th><th className="px-4 py-3.5">Stay period</th><th className="px-4 py-3.5">Booking window</th><th className="px-4 py-3.5">Market / promo</th><th className="px-4 py-3.5">Board</th><th className="px-4 py-3.5">Base net</th><th className="px-4 py-3.5">Meal supplement</th><th className="px-5 py-3.5">Extra adult / child / bed</th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredRates.slice(0, 250).map((rate) => (
                      <tr key={rate.id} className="text-sm hover:bg-slate-50/60">
                        <td className="px-5 py-3.5"><div className="font-bold text-slate-800">{rate.name}</div><div className="mt-0.5 text-[11px] text-slate-400">{hotelName(rate.hotelId)}</div></td>
                        <td className="px-4 py-3.5 text-xs font-semibold text-slate-600">{roomName(rate.roomTypeId)}</td>
                        <td className="px-4 py-3.5"><div className="flex items-center gap-1.5 text-xs text-slate-600"><CalendarDays size={13} /> {formatDate(rate.validFrom, { day: "2-digit", month: "short", year: "2-digit" })} – {formatDate(rate.validTo, { day: "2-digit", month: "short", year: "2-digit" })}</div>{rate.minimumNights > 1 && <div className="mt-1 text-[10px] font-semibold text-amber-700">Min. {rate.minimumNights} nights</div>}</td>
                        <td className="px-4 py-3.5 text-xs text-slate-600">{rate.bookingWindowStart || rate.bookingWindowEnd ? <span className="inline-flex items-center gap-1.5 rounded-full bg-sky-50 px-2 py-1 text-[10px] font-bold text-sky-700"><Clock3 size={11} /> {rate.bookingWindowStart ? formatDate(rate.bookingWindowStart, { day: "2-digit", month: "short", year: "2-digit" }) : "open"} – {rate.bookingWindowEnd ? formatDate(rate.bookingWindowEnd, { day: "2-digit", month: "short", year: "2-digit" }) : "open"}</span> : <span className="text-[10px] text-slate-400">Always open</span>}</td>
                        <td className="px-4 py-3.5 text-xs">
                          <div className="font-semibold text-slate-600">{marketLabel(rate.market)}</div>
                          {parseMarketList(rate.marketExclusions).length > 0 && <div className="mt-0.5 text-[10px] text-rose-600">excl. {parseMarketList(rate.marketExclusions).map((slug) => marketLabel(slug)).join(", ")}</div>}
                          {rate.promoCode && <div className="mt-1 inline-flex items-center gap-1 rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-rose-700">{rate.promoCode}</div>}
                        </td>
                        <td className="px-4 py-3.5"><span className="inline-flex items-center gap-1.5 rounded-full bg-orange-50 px-2.5 py-1 text-[10px] font-bold text-orange-700"><UtensilsCrossed size={11} /> {boardLabel(rate.boardType)}</span></td>
                        <td className="px-4 py-3.5"><div className="font-extrabold text-slate-900">{formatMoney(rate.baseRate)}</div><div className="text-[10px] text-slate-400">per {rate.rateBasis === "person_night" ? "person" : "room"} / night</div></td>
                        <td className="px-4 py-3.5 text-xs text-slate-600">{Number(rate.boardAdultSupplement) === 0 ? <span className="text-slate-400">Included</span> : rate.boardSupplementBasis === "room_night" ? <>{formatMoney(rate.boardAdultSupplement)} per room</> : <><div>Adult {formatMoney(rate.boardAdultSupplement)}</div><div className="mt-0.5">Child {formatMoney(rate.boardChildSupplement)}</div></>}</td>
                        <td className="px-5 py-3.5 text-xs text-slate-600">{formatMoney(rate.extraAdultRate)} / {formatMoney(rate.extraChildRate)} / {formatMoney(rate.extraBedRate)}{rate.extraBedBasis === "per_stay" ? " stay" : ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredRates.length > 250 && <div className="border-t border-slate-100 px-5 py-3 text-center text-xs text-slate-400">Showing 250 of {filteredRates.length} lines — choose a hotel to narrow the list.</div>}
              </div>
            </section>
          )}

          {/* BLACKOUT DATES VIEW */}
          {effectiveView === "blackouts" && (
            <section className="grid gap-4 lg:grid-cols-2">
              {data.blackouts.filter((item) => `${hotelName(item.hotelId)} ${item.reason}`.toLowerCase().includes(normalizedSearch)).map((blackout) => {
                const past = blackout.endDate < today;
                return (
                  <article key={blackout.id} className={`${card} p-5 ${past ? "opacity-60" : ""}`}>
                    <div className="flex items-start gap-4">
                      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-amber-50 text-amber-700"><CalendarX2 size={22} /></div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="font-extrabold text-slate-900">{hotelName(blackout.hotelId)}</h2><span className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide ${past ? "bg-slate-100 text-slate-500" : "bg-rose-50 text-rose-700"}`}>{past ? "Past" : "Do not book"}</span></div>
                        <p className="mt-1 text-xs font-semibold text-slate-500">{roomName(blackout.roomTypeId)}</p>
                        <div className="mt-4 flex items-center gap-2 rounded-xl bg-slate-50 px-3.5 py-3 text-sm font-bold text-slate-700"><CalendarDays size={16} className="text-amber-700" /> {formatDate(blackout.startDate)} <span className="text-slate-300">→</span> {formatDate(blackout.endDate)}</div>
                        <p className="mt-3 text-xs leading-5 text-slate-500">{blackout.reason}</p>
                      </div>
                    </div>
                  </article>
                );
              })}
              <button onClick={() => { setBlackoutHotelId(data.hotels[0]?.id ?? 0); setBlackoutRoomId(0); setBlackoutRoomQuery(""); setDialog("blackout"); }} className="flex min-h-[190px] items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-white/50 text-sm font-bold text-slate-400 transition hover:border-teal-300 hover:text-teal-700"><Plus size={17} className="mr-2" /> Record fully booked dates</button>
            </section>
          )}

          {/* BOOKINGS LEDGER VIEW */}
          {effectiveView === "bookings" && (
            <section className={`${card} overflow-hidden`}>
              <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-extrabold">Reservation ledger</h2><p className="mt-1 text-xs text-slate-400">{filteredBookings.length} reservations · {formatMoney(confirmedValue)} confirmed value · single & multi-hotel bookings</p></div>
              {bookingTable(filteredBookings)}
            </section>
          )}
        </div>
      </main>

      {/* DIALOGS */}
      {dialog === "hotel" && (
        <Modal title="Add contracted hotel" subtitle="Supplier profile with tax and arrival policies." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/hotels", "Hotel added with the selected group and contacts. Now add its rooms and rates.", (raw) => ({
            ...raw,
            groupId: Number(newHotelGroupId) > 0 ? Number(newHotelGroupId) : null,
            newGroup: newHotelGroupId === "__new__" ? { name: String(raw.newGroupName ?? ""), website: String(raw.newGroupWebsite ?? "") } : null,
            includedContactIds: newHotelSharedContactIds,
            locationId: Number(newHotelLocationId) > 0 ? Number(newHotelLocationId) : null,
            amenityIds: toList(raw.amenityIds),
            contacts: newHotelContactSlots
              .map((slot) => ({
                name: String(raw[`contactName${slot}`] ?? ""),
                position: String(raw[`contactPosition${slot}`] ?? ""),
                email: String(raw[`contactEmail${slot}`] ?? ""),
                phone: String(raw[`contactPhone${slot}`] ?? ""),
                businessCardLink: String(raw[`contactCard${slot}`] ?? ""),
                whatsapp: raw[`contactWhatsapp${slot}`] === "on",
                telegram: raw[`contactTelegram${slot}`] === "on",
                viber: raw[`contactViber${slot}`] === "on",
                otherContact: String(raw[`contactOther${slot}`] ?? ""),
                addToGroup: raw[`contactShare${slot}`] === "on" && newHotelGroupId !== "",
              }))
              .filter((contact) => contact.name.trim().length > 0),
          }))} className="grid gap-4 md:grid-cols-2">
            <Field label="Hotel name"><input name="name" required className={inputClass} placeholder="e.g. Jumeirah Al Naseem" /></Field>
            <Field label="Supplier code"><input name="supplierCode" required className={inputClass} placeholder="e.g. JAN-DXB" /></Field>
            <Field label="City / emirate" hint="The parent area, e.g. Dubai.">
              <input name="city" required list="city-options" value={newHotelCity} onChange={(event) => { setNewHotelCity(event.target.value); setNewHotelLocationId(""); }} className={inputClass} placeholder="Dubai" />
              <datalist id="city-options">{Array.from(new Set([...cities, ...data.locations.map((place) => place.city)])).sort().map((city) => <option key={city} value={city} />)}</datalist>
            </Field>
            <Field label="Location in this city / emirate" hint="A district inside the city, e.g. Deira. Pick one or type a new name.">
              <SelectWrap>
                <select value={newHotelLocationId} onChange={(event) => setNewHotelLocationId(event.target.value)} className={selectClass}>
                  <option value="">No location set</option>
                  {data.locations.filter((place) => place.city.toLowerCase() === newHotelCity.trim().toLowerCase()).map((place) => <option key={place.id} value={place.id}>{place.name}</option>)}
                  <option value="__new__">＋ Add a new location</option>
                </select>
              </SelectWrap>
              {newHotelLocationId === "__new__" && <input name="newLocationName" required className={`${inputClass} mt-2`} placeholder={`New location in ${newHotelCity || "this city"}, e.g. Deira`} />}
            </Field>
            <Field label="Star rating"><SelectWrap><select name="starRating" defaultValue="4" className={selectClass}>{[5, 4, 3, 2, 1].map((stars) => <option key={stars} value={stars}>{stars} stars</option>)}</select></SelectWrap></Field>
            <div className="md:col-span-2 rounded-2xl border border-teal-100 bg-[#f0f8f6] p-4 sm:p-5">
              <div className="flex items-start gap-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-teal-700"><UsersRound size={17} /></div><div><div className="text-sm font-extrabold text-[#174e48]">Umbrella company & shared sales team</div><p className="mt-0.5 text-[11px] leading-5 text-slate-500">Choosing a group brings in contacts used at its other hotels. Untick anyone this hotel does not need.</p></div></div>
              <label className="mt-4 block"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Umbrella company</span><SelectWrap><select value={newHotelGroupId} onChange={(event) => selectHotelGroup(event.target.value)} className={selectClass}><option value="">Independent (no group)</option>{data.hotelGroups.map((group) => <option key={group.id} value={group.id}>{group.name}</option>)}<option value="__new__">＋ Create a new umbrella company</option></select></SelectWrap></label>
              {newHotelGroupId === "__new__" && <div className="mt-3 grid gap-3 rounded-xl border border-teal-200 bg-white p-3 sm:grid-cols-2"><Field label="New group name"><input name="newGroupName" required className={inputClass} placeholder="e.g. Al Khoory Hotels" /></Field><Field label="Group website (optional)"><input name="newGroupWebsite" type="url" className={inputClass} placeholder="https://hotelgroup.com" /></Field><p className="text-[11px] leading-5 text-slate-500 sm:col-span-2">The umbrella company and this hotel will be saved together. Contacts marked “also share with group” will be available for its next hotels.</p></div>}
              {Number(newHotelGroupId) > 0 && <div className="mt-4 rounded-xl border border-teal-200 bg-white p-3.5"><div className="flex items-center justify-between gap-2"><span className="text-xs font-extrabold text-slate-800">Contacts from this group and its hotels</span><span className="rounded-full bg-teal-50 px-2 py-1 text-[10px] font-bold text-teal-700">{newHotelSharedContactIds.length} selected</span></div>{inheritedCandidates.length > 0 ? <div className="mt-3 grid gap-2 sm:grid-cols-2">{inheritedCandidates.map((contact) => <label key={contact.id} className={`flex cursor-pointer items-start gap-2.5 rounded-xl border p-3 transition ${newHotelSharedContactIds.includes(contact.id) ? "border-teal-300 bg-teal-50/60" : "border-slate-200 bg-white"}`}><input type="checkbox" checked={newHotelSharedContactIds.includes(contact.id)} onChange={(event) => setNewHotelSharedContactIds((current) => event.target.checked ? [...current, contact.id] : current.filter((id) => id !== contact.id))} className="mt-0.5 accent-teal-700" /><span className="min-w-0"><span className="block truncate text-xs font-bold text-slate-800">{contact.name}</span><span className="block truncate text-[10px] text-slate-500">{contact.position || contact.email || contact.phone || "Sales contact"}</span><span className="mt-1 block text-[10px] font-semibold text-teal-700">{contact.groupId ? "Group contact" : "From another group hotel"}</span></span></label>)}</div> : <p className="mt-2 text-xs text-slate-400">No contacts yet in this group. Add the first below, or save the hotel without contacts.</p>}<p className="mt-3 text-[11px] text-slate-500">Unchecked contacts stay at their original hotel or group; this new hotel will not use them.</p></div>}
            </div>
            <Field label="Business type"><input name="businessType" defaultValue="Hotel" className={inputClass} placeholder="Hotel / Hotel Apartments / DMC" /></Field>
            <Field label="Website"><input name="website" className={inputClass} placeholder="https://hotel.com" /></Field>
            <Field label="Contracts folder (Google Drive)" hint="Where the signed contracts for this hotel are stored."><input name="contractsFolderLink" className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
            <Field label="Hotel media (Google Drive)" className="md:col-span-2" hint="Photos, floor plans or a media pack for this hotel."><input name="mediaLink" className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Contacts</span>
              <p className="mb-3 text-xs text-slate-400">Add as many as you need. Tick WhatsApp or Telegram and the number becomes a chat link.</p>
              <div className="space-y-3">
                {newHotelContactSlots.map((slot, index) => (
                  <div key={slot} className="rounded-xl border border-slate-200 bg-white p-3.5">
                    <div className="mb-3 flex items-center justify-between"><span className="text-xs font-extrabold text-slate-700">New contact {index + 1} <span className="font-medium text-slate-400">· optional</span></span><button type="button" onClick={() => setNewHotelContactSlots((slots) => slots.filter((item) => item !== slot))} className="text-[10px] font-bold text-rose-600 hover:underline">Remove block</button></div>
                    <div className="grid gap-3 md:grid-cols-2">
                      <Field label="Full name"><input name={`contactName${slot}`} className={inputClass} placeholder={slot === 0 ? "Farah Cadinouche" : ""} /></Field>
                      <Field label="Company position"><input name={`contactPosition${slot}`} className={inputClass} placeholder="Director of Sales & Marketing" /></Field>
                      <Field label="Email"><input name={`contactEmail${slot}`} type="email" className={inputClass} placeholder="name@hotel.com" /></Field>
                      <Field label="Contact number"><input name={`contactPhone${slot}`} className={inputClass} placeholder="+971501234567" /></Field>
                    </div>
                    <div className="mt-3 grid gap-3 md:grid-cols-2">
                      <Field label="Business card / contact card link"><input name={`contactCard${slot}`} className={inputClass} placeholder="https://drive.google.com/file/d/…" /></Field>
                      <Field label="Other (SMS, WeChat, extension…)"><input name={`contactOther${slot}`} className={inputClass} placeholder="e.g. WeChat: hotel Dos" /></Field>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {([["contactWhatsapp", "WhatsApp"], ["contactTelegram", "Telegram"], ["contactViber", "Viber"]] as const).map(([field, label]) => (
                        <label key={field} className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"><input name={`${field}${slot}`} type="checkbox" defaultChecked={field === "contactWhatsapp"} className="accent-teal-700" /> {label}</label>
                      ))}
                    </div>
                    {newHotelGroupId !== "" && <label className="mt-3 flex cursor-pointer items-center gap-2.5 rounded-xl border border-teal-200 bg-teal-50 px-3 py-2.5 text-xs font-bold text-teal-900"><input name={`contactShare${slot}`} type="checkbox" className="accent-teal-700" /> Also add this contact to the umbrella company <span className="font-medium text-teal-700">(available to other hotels)</span></label>}
                  </div>
                ))}
              </div>
              <button type="button" onClick={() => setNewHotelContactSlots((slots) => [...slots, (Math.max(-1, ...slots) + 1)])} className="mt-3 inline-flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 py-2 text-xs font-bold text-teal-800 hover:bg-teal-100"><Plus size={14} /> Add another contact</button>
              <p className="mt-2 text-[11px] text-slate-400">Hotel-only contacts are not automatically added to the umbrella company. You can change their group membership later.</p>
            </div>
            <Field label="Contact email"><input name="contactEmail" type="email" className={inputClass} placeholder="contracts@hotel.com" /></Field>
            <Field label="Contact phone"><input name="contactPhone" className={inputClass} placeholder="+971" /></Field>
            <Field label="Check-in time"><input name="checkInTime" type="time" defaultValue="15:00" className={inputClass} /></Field>
            <Field label="Check-out time"><input name="checkOutTime" type="time" defaultValue="12:00" className={inputClass} /></Field>
            <Field label="Tourism tax (AED)"><input name="tourismTax" type="number" min="0" step="0.01" defaultValue="15" className={inputClass} /></Field>
            <Field label="Tax basis"><SelectWrap><select name="tourismTaxBasis" className={selectClass}><option value="room_night">Per room / night</option><option value="person_night">Per person / night</option><option value="per_stay">Per room / stay</option></select></SelectWrap></Field>
            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Amenities</span>
              <div className="grid gap-2 sm:grid-cols-2">
                {data.amenities.map((amenity) => (
                  <label key={amenity.id} className="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-3.5 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-50">
                    <input type="checkbox" name="amenityIds" value={amenity.id} className="accent-teal-700" />
                    <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={14} />
                  </label>
                ))}
              </div>
            </div>
            <SubmitRow saving={saving} label="Save hotel" />
          </form>
        </Modal>
      )}

      {dialog === "room" && (
        <Modal title="Add room type" subtitle="Choose the category so this room is compared with similar rooms at other hotels." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/rooms", "Room type added.", (raw) => ({
            ...raw,
            extraBedAllowed: Number(raw.extra_bedMax) > 0,
            occupancies: occupancySlots
              .map((slot) => ({
                adults: Number(raw[`occAdults${slot}`] || 0),
                children: Number(raw[`occChildren${slot}`] || 0),
                infants: Number(raw[`occInfants${slot}`] || 0),
                extraBeds: Number(raw[`occExtra${slot}`] || 0),
                label: String(raw[`occLabel${slot}`] ?? ""),
              }))
              .filter((item) => item.adults > 0),
          }))} className="grid gap-4 md:grid-cols-2">
            <Field label="Hotel"><SelectWrap><select name="hotelId" required className={selectClass}>{data.hotels.map((hotel) => <option key={hotel.id} value={hotel.id}>{hotel.name}</option>)}</select></SelectWrap></Field>
            <Field label="Search category" hint="Rooms in the same category are compared with each other in search."><SelectWrap><select name="category" required className={selectClass}>{data.roomCategories.map((category) => <option key={category.slug} value={category.slug}>{category.label}</option>)}</select></SelectWrap></Field>
            <Field label="Room name (as the hotel calls it)"><input name="name" required className={inputClass} placeholder="Triple Room Sea View" /></Field>
            <Field label="Room code"><input name="code" required className={inputClass} placeholder="TRIPLE" /></Field>
            <Field label="Max adults"><input name="maxAdults" type="number" min="1" defaultValue="3" className={inputClass} /></Field>
            <Field label="Adults included in base rate"><input name="includedAdults" type="number" min="1" defaultValue="2" className={inputClass} /></Field>
            <Field label="Max children"><input name="maxChildren" type="number" min="0" defaultValue="2" className={inputClass} /></Field>
            <Field label="Max infants"><input name="maxInfants" type="number" min="0" defaultValue="1" className={inputClass} /></Field>
            <Field label="Sleeps without extra bedding" hint="Guests above this need an extra bed or sofa bed."><input name="baseSleeps" type="number" min="1" defaultValue="3" className={inputClass} /></Field>
            <Field label="Contracted allocation (rooms)"><input name="defaultInventory" type="number" min="1" defaultValue="5" className={inputClass} /></Field>
            <Field label="Room media (Google Drive)" className="md:col-span-2" hint="Photos of this room type. Shown next to the room name in search results."><input name="mediaLink" className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
            <div className="md:col-span-2 rounded-2xl border border-slate-200 p-4">
              <div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Occupancy combinations</span><button type="button" onClick={() => setOccupancySlots((slots) => [...slots, Math.max(-1, ...slots) + 1])} className="text-[11px] font-bold text-[#166159]">+ Add combination</button></div>
              <p className="mb-3 text-xs text-slate-400">Leave blank to use the standard combinations from the max occupancy above.</p>
              <div className="space-y-3">
                {occupancySlots.map((slot) => (
                  <div key={slot} className="grid gap-2 rounded-xl bg-slate-50 p-3 sm:grid-cols-5">
                    <Field label="Adults"><input name={`occAdults${slot}`} type="number" min="0" defaultValue={slot === 0 ? 2 : ""} className={`${inputClass} h-10`} /></Field>
                    <Field label="Children"><input name={`occChildren${slot}`} type="number" min="0" defaultValue="0" className={`${inputClass} h-10`} /></Field>
                    <Field label="Infants"><input name={`occInfants${slot}`} type="number" min="0" defaultValue="0" className={`${inputClass} h-10`} /></Field>
                    <Field label="Extra beds"><input name={`occExtra${slot}`} type="number" min="0" defaultValue="0" className={`${inputClass} h-10`} /></Field>
                    <Field label="Label"><input name={`occLabel${slot}`} className={`${inputClass} h-10`} placeholder="e.g. 2 adults + 1 child" /></Field>
                  </div>
                ))}
              </div>
            </div>
            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Extra bedding</span>
              <p className="mb-3 text-xs text-slate-400">Set how many are allowed per room. Leave “allowed” at 0 if the room cannot take it. Baby cots are often free.</p>
              <div className="grid gap-3 lg:grid-cols-3">
                {BEDDING_KINDS.map((kind) => (
                  <div key={kind.value} className="rounded-xl border border-slate-200 p-3.5">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-extrabold text-slate-800">{kind.label}</span>
                      <span className="text-[10px] text-slate-400">{kind.hint}</span>
                    </div>
                    <label className="mt-3 block">
                      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Allowed per room</span>
                      <input name={`${kind.value}Max`} type="number" min="0" max="4" defaultValue={kind.value === "baby_cot" ? 1 : 0} className={`${inputClass} h-10`} />
                    </label>
                    <label className="mt-2.5 flex items-center gap-2 text-xs font-semibold text-slate-600"><input name={`${kind.value}Free`} type="checkbox" defaultChecked={kind.value === "baby_cot"} className="accent-teal-700" /> Free of charge</label>
                    <label className="mt-2.5 block">
                      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Cost per night (AED)</span>
                      <input name={`${kind.value}Rate`} type="number" min="0" step="0.01" defaultValue="0" className={`${inputClass} h-10`} />
                    </label>
                    <label className="mt-2.5 flex items-center gap-2 text-xs font-semibold text-slate-600"><input name={`${kind.value}PerStay`} type="checkbox" className="accent-teal-700" /> Charge once per stay</label>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11px] text-slate-400">If a rate line has an extra-bed price for the season, it is used instead of the default above.</p>
            </div>
            <SubmitRow saving={saving} label="Save room type" />
          </form>
        </Modal>
      )}

      {dialog === "rate" && (
        <Modal title="Add rate line" subtitle="One line per room, board type and validity period." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/rates", "Rate line added.", (raw) => ({ ...raw, roomTypeId: rateRoomId, hotelId: data.rooms.find((room) => room.id === rateRoomId)?.hotelId, marketExclusions: toList(raw.marketExclusions) }))} className="grid gap-4 md:grid-cols-2">
            <Field label="Hotel" hint="Type inside the box to shorten the list.">
              <SearchableSelect
                name="rateHotelId"
                required
                value={rateHotelId}
                onChange={(id) => { setRateHotelId(id); setRateRoomId(0); }}
                placeholder="Type a hotel name…"
                options={data.hotels.map((hotel) => ({ id: hotel.id, label: hotel.name, hint: `${locationName(hotel.locationId) ? `${locationName(hotel.locationId)}, ` : ""}${hotel.city} · ${hotel.supplierCode}` }))}
              />
            </Field>
            <Field label="Room type" hint={rateHotelId ? `Only rooms at ${hotelName(rateHotelId)}.` : "Pick a hotel first."}>
              <SearchableSelect
                name="roomTypeIdPicker"
                required
                value={rateRoomId}
                onChange={(id) => setRateRoomId(id)}
                placeholder={rateHotelId ? "Type a room name…" : "Choose a hotel first"}
                options={data.rooms.filter((room) => room.hotelId === rateHotelId).map((room) => ({ id: room.id, label: room.name, hint: `${room.code} · ${categoryLabel(room.category)}` }))}
              />
            </Field>
            <Field label="Rate name"><input name="name" required className={inputClass} placeholder="Winter 2026 BB" /></Field>
            <Field label="Board type"><SelectWrap><select name="boardType" defaultValue="breakfast" className={selectClass}><option value="room_only">Room only</option><option value="breakfast">Bed & breakfast</option><option value="half_board">Half board</option><option value="full_board">Full board</option></select></SelectWrap></Field>
            <Field label="Stay period from" hint="First night the guest can stay on this rate."><input name="validFrom" required type="date" className={inputClass} /></Field>
            <Field label="Stay period to (last night)"><input name="validTo" required type="date" className={inputClass} /></Field>
            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 md:col-span-2">
              <span className="mb-1 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Booking window (optional)</span>
              <p className="mb-3 text-xs text-slate-400">Only lets this rate be booked between these dates — used for flash sales and early-bird offers. Leave blank to keep it open the whole time.</p>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Booking opens</span><input name="bookingWindowStart" type="date" className={inputClass} /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Booking closes</span><input name="bookingWindowEnd" type="date" className={inputClass} /></label>
              </div>
            </div>
            <Field label="Market"><SelectWrap><select name="market" defaultValue="all" className={selectClass}>{data.markets.map((market) => <option key={market.slug} value={market.slug}>{market.label}</option>)}</select></SelectWrap></Field>
            <Field label="Promo code (optional)"><input name="promoCode" className={inputClass} placeholder="e.g. RAMADAN-FLASH-4" /></Field>
            <div className="md:col-span-2">
              <div className="mb-2 flex items-center justify-between gap-3">
                <span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Markets not applicable</span>
                <button type="button" onClick={() => setDialog("market")} className="text-[11px] font-bold text-[#166159]">Add market / nationality</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {data.markets.filter((market) => market.slug !== "all").map((market) => (
                  <label key={market.id} className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50">
                    <input name="marketExclusions" type="checkbox" value={market.slug} className="accent-teal-700" /> {market.label}
                  </label>
                ))}
              </div>
            </div>
            <Field label="Base rate (AED)"><input name="baseRate" required type="number" min="0" step="0.01" className={inputClass} /></Field>
            <Field label="Base rate is"><SelectWrap><select name="rateBasis" className={selectClass}><option value="room_night">Per room / night</option><option value="person_night">Per person / night</option></select></SelectWrap></Field>
            <Field label="Meal supplement – adult (or per room)"><input name="boardAdultSupplement" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Meal supplement – child"><input name="boardChildSupplement" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Meal supplement is" hint="Leave supplements at 0 if meals are included in the base rate." className="md:col-span-2"><SelectWrap><select name="boardSupplementBasis" className={selectClass}><option value="person_night">Per person / night</option><option value="room_night">Per room / night (adult field used)</option></select></SelectWrap></Field>
            <Field label="Extra adult / night"><input name="extraAdultRate" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Child / night"><input name="extraChildRate" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Extra bed cost"><input name="extraBedRate" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Extra bed charged"><SelectWrap><select name="extraBedBasis" className={selectClass}><option value="bed_night">Per bed / night</option><option value="per_stay">Per bed / stay</option></select></SelectWrap></Field>
            <Field label="Minimum nights"><input name="minimumNights" type="number" min="1" defaultValue="1" className={inputClass} /></Field>
            <SubmitRow saving={saving} label="Save rate line" />
          </form>
        </Modal>
      )}

      {dialog === "amenity" && (
        <Modal title="Add amenity type" subtitle="New amenity types become available to every hotel and as a search filter." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/amenities", "Amenity type added. You can now tick it for any hotel.")} className="grid gap-4">
            <Field label="Amenity name" hint="The code is generated from the name, e.g. “Spa access” becomes spa_access.">
              <input name="label" required className={inputClass} placeholder="e.g. Spa access" />
            </Field>
            <Field label="Icon">
              <SelectWrap>
                <select name="icon" defaultValue="check" className={selectClass}>
                  <option value="waves">Swimming (waves)</option>
                  <option value="umbrella">Beach (umbrella)</option>
                  <option value="dumbbell">Gym (dumbbell)</option>
                  <option value="train">Metro (train)</option>
                  <option value="check">Generic (tick)</option>
                </select>
              </SelectWrap>
            </Field>
            <SubmitRow saving={saving} label="Save amenity" />
          </form>
        </Modal>
      )}

      {dialog === "occupancy" && (
        <Modal title="Add occupancy combination" subtitle={occupancyRoomId ? `${roomName(occupancyRoomId)} · ${hotelName(data.rooms.find((room) => room.id === occupancyRoomId)?.hotelId ?? 0)}` : ""} onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/occupancy", "Occupancy combination added.", (raw) => ({ ...raw, roomTypeId: occupancyRoomId }))} className="grid gap-4 sm:grid-cols-2">
            <Field label="Adults"><input name="adults" type="number" min="1" defaultValue="2" required className={inputClass} /></Field>
            <Field label="Children"><input name="children" type="number" min="0" defaultValue="0" className={inputClass} /></Field>
            <Field label="Infants"><input name="infants" type="number" min="0" defaultValue="0" className={inputClass} /></Field>
            <Field label="Extra beds"><input name="extraBeds" type="number" min="0" defaultValue="0" className={inputClass} /></Field>
            <Field label="Label" className="sm:col-span-2"><input name="label" className={inputClass} placeholder="e.g. 1 adult + 2 children" /></Field>
            <SubmitRow saving={saving} label="Save occupancy" />
          </form>
        </Modal>
      )}

      {dialog === "contact" && (
        <Modal title={contactGroupId ? "Add umbrella company contact" : "Add hotel contact"} subtitle={contactGroupId ? `${groupName(contactGroupId)} · choose which hotels use this person` : contactHotel ? hotelName(contactHotel) : "Choose a hotel"} onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/contacts", "Contact added to the selected group or hotels.", (raw) => ({
            ...raw,
            hotelId: contactGroupId ? null : contactHotel,
            groupId: contactGroupId || null,
            hotelIds: contactGroupId ? groupHotelSelections : [],
            addToGroup: contactGroupId ? true : raw.addToGroup === "on",
            whatsapp: raw.whatsapp === "on",
            telegram: raw.telegram === "on",
            viber: raw.viber === "on",
          }))} className="grid gap-4 md:grid-cols-2">
            {!contactGroupId && <Field label="Hotel" className="md:col-span-2"><SelectWrap><select value={contactHotel} onChange={(event) => setContactHotel(Number(event.target.value))} required className={selectClass}>{data.hotels.map((hotel) => <option key={hotel.id} value={hotel.id}>{hotel.name}</option>)}</select></SelectWrap></Field>}
            <Field label="Full name"><input name="name" required className={inputClass} placeholder="Farah Cadinouche" /></Field>
            <Field label="Company position"><input name="position" className={inputClass} placeholder="Assistant Director of Sales" /></Field>
            <Field label="Email"><input name="email" type="email" className={inputClass} placeholder="name@hotel.com" /></Field>
            <Field label="Contact number" hint="Include the country code so chat links work."><input name="phone" className={inputClass} placeholder="+971509340811" /></Field>
            <Field label="Business card link" className="md:col-span-2" hint="Paste a Google Drive link to their card."><input name="businessCardLink" className={inputClass} placeholder="https://drive.google.com/file/d/…" /></Field>
            <div className="md:col-span-2"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Chat apps available</span><div className="flex flex-wrap gap-2"><label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600"><input name="whatsapp" type="checkbox" defaultChecked className="accent-teal-700" /> WhatsApp</label><label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600"><input name="telegram" type="checkbox" className="accent-teal-700" /> Telegram</label><label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600"><input name="viber" type="checkbox" className="accent-teal-700" /> Viber</label></div></div>
            <Field label="Other" className="md:col-span-2"><input name="otherContact" className={inputClass} placeholder="e.g. WeChat, SMS only, extension 204" /></Field>
            {!contactGroupId && data.hotels.find((hotel) => hotel.id === contactHotel)?.groupId && <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-teal-200 bg-teal-50 px-4 py-3 text-sm font-bold text-teal-900 md:col-span-2"><input name="addToGroup" type="checkbox" className="accent-teal-700" /><span>Add this contact to {groupName(data.hotels.find((hotel) => hotel.id === contactHotel)?.groupId ?? null)} <span className="block text-xs font-normal text-teal-700">The contact becomes available for other hotels in this umbrella company.</span></span></label>}
            {contactGroupId > 0 && <div className="md:col-span-2"><div className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Also assign to these hotels</div><div className="grid gap-2 sm:grid-cols-2">{data.hotels.filter((hotel) => hotel.groupId === contactGroupId).map((hotel) => <label key={hotel.id} className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-700"><input type="checkbox" checked={groupHotelSelections.includes(hotel.id)} onChange={(event) => setGroupHotelSelections((current) => event.target.checked ? [...current, hotel.id] : current.filter((id) => id !== hotel.id))} className="accent-teal-700" />{hotel.name}</label>)}</div><p className="mt-2 text-[11px] text-slate-500">Leave hotels unticked to keep the person in the group only. You can assign them later.</p></div>}
            <SubmitRow saving={saving} label="Save contact" />
          </form>
        </Modal>
      )}

      {dialog === "group" && (
        <Modal title="Add umbrella company" subtitle="Group several hotels under one sales team, e.g. Al Khoory Hotels." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/hotel-groups", "Group added. You can now assign hotels to it.")} className="grid gap-4 md:grid-cols-2">
            <Field label="Group name"><input name="name" required className={inputClass} placeholder="Al Khoory Hotels" /></Field>
            <Field label="Group website"><input name="website" className={inputClass} placeholder="https://alkhooryhotels.com" /></Field>
            <Field label="Notes" className="md:col-span-2"><input name="notes" className={inputClass} placeholder="One sales team covers all properties." /></Field>
            <SubmitRow saving={saving} label="Save group" />
          </form>
        </Modal>
      )}

      {dialog === "market" && (
        <Modal title="Markets & nationalities" subtitle="Add the markets you sell to, or nationalities a rate does not apply to." onClose={() => setDialog(null)}>
          <div className="flex gap-2">
            <input value={newMarket} onChange={(event) => setNewMarket(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void createMarket(); } }} placeholder="e.g. DRC Nationals" className={inputClass} />
            <button onClick={() => void createMarket()} disabled={saving || !newMarket.trim()} className="h-11 shrink-0 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white disabled:opacity-50">Add</button>
          </div>
          <p className="mt-2 text-xs text-slate-400">These appear in the rate form under “Markets not applicable” and as the Client market in search.</p>
          <div className="mt-4 max-h-80 space-y-1.5 overflow-y-auto">
            {data.markets.map((market) => (
              <div key={market.id} className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2.5">
                <div>
                  <div className="text-sm font-bold text-slate-800">{market.label}</div>
                  <div className="text-[10px] text-slate-400">{market.slug}</div>
                </div>
                {market.slug === "all" ? <span className="text-[10px] font-bold uppercase text-slate-300">Default</span> : (
                  <button onClick={() => void deleteMarket(market)} className="rounded-lg p-1.5 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600" title="Delete"><Trash2 size={15} /></button>
                )}
              </div>
            ))}
          </div>
        </Modal>
      )}

      {dialog === "category" && (
        <Modal title="Add search category" subtitle="New categories appear in the search dropdown and can be used by any hotel." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/room-categories", "Category added. You can now use it when adding a room type.")} className="grid gap-4">
            <Field label="Category name" hint="The code is generated from the name, e.g. “Quad Room” becomes quad_room.">
              <input name="label" required className={inputClass} placeholder="e.g. Quad Room" />
            </Field>
            <SubmitRow saving={saving} label="Save category" />
          </form>
        </Modal>
      )}

      {dialog === "hotelAmenities" && (
        <Modal title="Hotel amenities" subtitle={amenityEditHotel ? hotelName(amenityEditHotel) : ""} onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/hotel-amenities", "Amenities updated. Search filters now use the new set.", (raw) => ({ hotelId: amenityEditHotel, amenityIds: toList(raw.amenityIds) }))} className="grid gap-4">
            <div className="grid gap-2 sm:grid-cols-2">
              {data.amenities.map((amenity) => {
                const checked = hotelAmenityIds(amenityEditHotel).includes(amenity.id);
                return (
                  <label key={amenity.id} className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-3 text-sm font-semibold transition ${checked ? "border-teal-600 bg-teal-50/60 text-teal-800" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
                    <input type="checkbox" name="amenityIds" value={amenity.id} defaultChecked={checked} className="accent-teal-700" />
                    <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={14} />
                  </label>
                );
              })}
            </div>
            <p className="text-xs text-slate-400">Untick everything and save to clear the amenities for this hotel.</p>
            <SubmitRow saving={saving} label="Save amenities" />
          </form>
        </Modal>
      )}

      {dialog === "blackout" && (
        <Modal title="Record fully booked dates" subtitle="Rooms in this period will be excluded from search and cannot be booked." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/blackouts", "Blackout dates saved.")} className="grid gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <Field label="Hotel" hint="Type inside this box like an Excel combo box — matching hotels appear as you type.">
                <SearchableSelect
                  name="hotelId"
                  required
                  value={blackoutHotelId}
                  onChange={(id) => { setBlackoutHotelId(id); setBlackoutRoomId(0); setBlackoutRoomQuery(""); }}
                  placeholder="Type a hotel name…"
                  options={data.hotels.map((hotel) => ({ id: hotel.id, label: hotel.name, hint: `${locationName(hotel.locationId) ? `${locationName(hotel.locationId)}, ` : ""}${hotel.city} · ${hotel.supplierCode}` }))}
                />
              </Field>
              <p className="mt-2 text-[11px] text-slate-400">The room type list below updates to the rooms this hotel actually has.</p>
            </div>
            <div className="md:col-span-2">
              <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
                <span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-500">
                  Room type{blackoutHotelId ? ` · ${blackoutRooms.length} at ${hotelName(blackoutHotelId)}` : ""}
                </span>
                <button type="button" onClick={() => { setBlackoutRoomId(0); setBlackoutRoomQuery(""); }} className="text-[11px] font-bold text-[#166159]">Use all room types</button>
              </div>
              <input type="hidden" name="roomTypeId" value={blackoutRoomId || ""} />
              <div className="relative mb-2">
                <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
                <input value={blackoutRoomQuery} onChange={(event) => setBlackoutRoomQuery(event.target.value)} placeholder='Type to shorten the list, e.g. “Triple” or “DLX”…' className={`${inputClass} pl-9`} />
              </div>
              <div className="overflow-hidden rounded-xl border border-slate-200">
                <button type="button" onClick={() => setBlackoutRoomId(0)} className={`flex w-full items-center justify-between px-4 py-3 text-left text-sm font-bold ${blackoutRoomId === 0 ? "bg-[#174e48] text-white" : "bg-white text-slate-800 hover:bg-slate-50"}`}>
                  <span>All room types</span>
                  <span className={`text-[10px] font-semibold ${blackoutRoomId === 0 ? "text-white/80" : "text-slate-400"}`}>full hotel stop sale</span>
                </button>
                {blackoutRooms
                  .filter((room) => `${room.name} ${room.code}`.toLowerCase().includes(blackoutRoomQuery.trim().toLowerCase()))
                  .map((room) => (
                    <button type="button" key={room.id} onClick={() => setBlackoutRoomId(room.id)} className={`flex w-full items-center justify-between border-t border-slate-100 px-4 py-3 text-left text-sm ${blackoutRoomId === room.id ? "bg-[#174e48] font-bold text-white" : "text-slate-700 hover:bg-slate-50"}`}>
                      <span>{room.name}</span>
                      <span className={`text-[10px] font-bold tracking-wide ${blackoutRoomId === room.id ? "text-white/70" : "text-slate-400"}`}>{room.code}</span>
                    </button>
                  ))}
              </div>
              <p className="mt-2 text-[11px] text-slate-400">{blackoutRoomId === 0 ? "Every room type at this hotel will be blocked for those nights." : `${roomName(blackoutRoomId)} only will be blocked.`}</p>
            </div>
            <Field label="First night closed"><input name="startDate" required type="date" className={inputClass} /></Field>
            <Field label="Last night closed"><input name="endDate" required type="date" className={inputClass} /></Field>
            <Field label="Reason" className="md:col-span-2"><input name="reason" required className={inputClass} placeholder="Hotel fully booked" /></Field>
            <SubmitRow saving={saving} label="Block these dates" />
          </form>
        </Modal>
      )}

      {/* DETAIL MODAL: VIEW QUOTATION PROPOSAL */}
      {viewingQuotation && (
        <Modal
          title={`Quotation · ${viewingQuotation.reference}`}
          subtitle={viewingQuotation.title || "Itinerary Proposal"}
          onClose={closeQuotationView}
          wide
        >
          <div className="space-y-6">
            {/* Header info */}
            <div className="grid gap-4 rounded-2xl bg-slate-50 p-5 sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Client / Guest</span>
                <div className="mt-1 font-bold text-slate-900">{viewingQuotation.clientName}</div>
                {viewingQuotation.clientCompany && <div className="text-xs text-slate-500">{viewingQuotation.clientCompany}</div>}
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Contact Details</span>
                <div className="mt-1 text-xs text-slate-700">{viewingQuotation.clientEmail || "—"}</div>
                <div className="text-xs text-slate-700">{viewingQuotation.clientPhone || "—"}</div>
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Itinerary Overview</span>
                <div className="mt-1 text-xs font-bold text-slate-800">{viewingQuotation.totalNights} Nights Total</div>
                <div className="text-xs text-slate-500">{data.quotationItems.filter((it) => it.quotationId === viewingQuotation.id).length} Hotel Stay Segments</div>
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Proposal Status</span>
                <div className="mt-1">
                  <StatusBadge status={viewingQuotation.status} />
                </div>
              </div>
            </div>

            {/* Stays breakdown */}
            <div>
              <h3 className="mb-3 text-sm font-extrabold text-slate-900">Hotel Stays & Pricing in this Proposal</h3>
              <div className="space-y-3">
                {data.quotationItems
                  .filter((it) => it.quotationId === viewingQuotation.id)
                  .map((item, idx) => {
                    const h = data.hotels.find((hotel) => hotel.id === item.hotelId);
                    const r = data.rooms.find((room) => room.id === item.roomTypeId);

                    return (
                      <div key={item.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
                        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-slate-50/60 px-5 py-3.5">
                          <div className="flex items-center gap-2">
                            <span className="grid h-6 w-6 place-items-center rounded-full bg-[#174e48] text-xs font-extrabold text-white">
                              {idx + 1}
                            </span>
                            <span className="font-extrabold text-slate-900">{h?.name}</span>
                            <span className="text-xs text-slate-400">({h?.city})</span>
                          </div>
                          <div className="text-right">
                            <span className="font-extrabold text-[#174e48]">{formatMoney(item.totalAmount, viewingQuotation.currency)}</span>
                            <span className="ml-1 text-[10px] text-slate-400">total stay</span>
                          </div>
                        </div>

                        <div className="grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4">
                          <div>
                            <span className="text-[10px] font-extrabold uppercase text-slate-400">Room & Board</span>
                            <div className="mt-1 font-bold text-slate-800">{r?.name}</div>
                            <div className="text-xs font-semibold text-teal-800">{boardLabel(item.boardType)}</div>
                            {r?.mediaLink && (
                              <a href={r.mediaLink} target="_blank" rel="noreferrer" className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-bold text-violet-700 hover:underline">
                                <Images size={12} /> Room Media ↗
                              </a>
                            )}
                          </div>
                          <div>
                            <span className="text-[10px] font-extrabold uppercase text-slate-400">Dates & Duration</span>
                            <div className="mt-1 font-semibold text-slate-800">
                              {formatDate(item.checkIn)} → {formatDate(item.checkOut)}
                            </div>
                            <div className="text-xs text-slate-500">{item.nights} Nights · {item.rooms} Room(s)</div>
                          </div>
                          <div>
                            <span className="text-[10px] font-extrabold uppercase text-slate-400">Occupancy & Beds</span>
                            <div className="mt-1 text-xs font-semibold text-slate-700">
                              {item.adults} Adults{item.children ? ` + ${item.children} Child` : ""}{item.infants ? ` + ${item.infants} Inf` : ""}
                            </div>
                            {(item.extraBeds > 0 || item.sofaBeds > 0 || item.babyCots > 0) && (
                              <div className="mt-0.5 text-[11px] text-slate-500">
                                {[item.extraBeds ? `${item.extraBeds} Extra bed` : "", item.sofaBeds ? `${item.sofaBeds} Sofa bed` : "", item.babyCots ? `${item.babyCots} Cot` : ""].filter(Boolean).join(", ")}
                              </div>
                            )}
                          </div>
                          <div>
                            <span className="text-[10px] font-extrabold uppercase text-slate-400">Cost Breakdown</span>
                            <div className="mt-1 space-y-0.5 text-[11px] text-slate-600">
                              <div>Room: <b>{formatMoney(item.baseAmount)}</b></div>
                              {Number(item.boardAmount) > 0 && <div>Board: <b>{formatMoney(item.boardAmount)}</b></div>}
                              {Number(item.extraBedAmount) > 0 && <div>Beds: <b>{formatMoney(item.extraBedAmount)}</b></div>}
                              <div>Tax: <b>{formatMoney(item.tourismTaxAmount)}</b></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* Tax inclusion & our markup — internal only */}
            {!showCost && (
              <div className="rounded-2xl border border-teal-200 bg-teal-50/40 p-5">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="text-xs font-extrabold text-teal-900">Quotation summary ({viewingQuotation.totalNights} nights)</div>
                    <div className="mt-1 text-xs text-slate-600">Tourism tax {viewingQuotation.includeTax ? "included" : "excluded — payable at the hotel"}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-extrabold uppercase tracking-wider text-teal-800">Client quoted total</div>
                    <div className="text-2xl font-extrabold text-[#174e48]">{formatMoney(viewingQuotation.quotedTotal || viewingQuotation.totalAmount, viewingQuotation.currency)}</div>
                  </div>
                </div>
              </div>
            )}
            {showCost && (
            <div className="rounded-2xl border border-teal-200 bg-teal-50/40 p-5">
              <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-extrabold text-teal-900">Tax & markup ({viewingQuotation.totalNights} Nights)</div>
                      <p className="mt-0.5 text-[11px] text-slate-500">Hotel rates are what the hotel charges us — the total below is what the client is quoted.</p>
                    </div>
                    <button
                      type="button"
                      disabled={saving || !commercialChanged}
                      onClick={() => void saveQuotationCommercial()}
                      className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-[#174e48] px-3.5 text-xs font-bold text-white hover:bg-[#103f3a] disabled:opacity-50"
                    >
                      {saving ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />} Save pricing
                    </button>
                  </div>

                  <div className="mt-4 space-y-2 rounded-xl bg-white p-3.5 text-xs text-slate-600">
                    <div className="flex justify-between"><span>Hotel net cost (room + meals + bedding):</span><b className="text-slate-900">{formatMoney(viewingHotelCost, viewingQuotation.currency)}</b></div>
                    <div className="flex justify-between"><span>Our markup:</span><b className="text-teal-700">+ {formatMoney(viewingPreview?.markupAmount ?? 0, viewingQuotation.currency)}</b></div>
                    <div className="flex justify-between">
                      <span>Tourism tax {viewingPreview?.includeTax ? "included in total" : "excluded from total"}:</span>
                      <b className={viewingPreview?.includeTax ? "text-slate-900" : "text-amber-700"}>{formatMoney(viewingTax, viewingQuotation.currency)}</b>
                    </div>
                  </div>

                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-teal-200 bg-white px-3.5 py-3">
                      <input
                        type="checkbox"
                        checked={markupEdit?.includeTax ?? true}
                        onChange={(event) => setMarkupEdit((current) => (current ? { ...current, includeTax: event.target.checked } : current))}
                        className="accent-teal-700"
                      />
                      <span>
                        <span className="block text-xs font-extrabold text-slate-800">Include tourism tax in quote</span>
                        <span className="block text-[10px] text-slate-400">Uncheck to show it as a separate daily fee</span>
                      </span>
                    </label>

                    <div className="rounded-xl border border-teal-200 bg-white p-3.5">
                      <span className="block text-xs font-extrabold text-slate-800">Our markup</span>
                      <div className="mt-2 flex items-center gap-2">
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={markupEdit?.markupValue ?? "0"}
                          onChange={(event) => setMarkupEdit((current) => (current ? { ...current, markupValue: event.target.value } : current))}
                          className="h-9 w-full rounded-lg border border-slate-200 px-2.5 text-sm font-bold outline-none focus:border-teal-700"
                        />
                        <div className="flex overflow-hidden rounded-lg border border-slate-200 p-0.5">
                          {(["percent", "amount"] as const).map((mode) => (
                            <button
                              key={mode}
                              type="button"
                              onClick={() => setMarkupEdit((current) => (current ? { ...current, markupMode: mode } : current))}
                              className={`rounded-md px-2 py-1 text-[10px] font-extrabold transition ${markupEdit?.markupMode === mode ? "bg-teal-700 text-white" : "text-slate-500 hover:bg-slate-100"}`}
                            >
                              {mode === "percent" ? "%" : "AED"}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl bg-[#174e48] p-4 text-white">
                  <div className="text-[10px] uppercase tracking-wider text-teal-100">Client quoted total{viewingPreview && !viewingPreview.includeTax ? " (excl. tax)" : " (incl. tax)"}</div>
                  <div className="mt-0.5 text-2xl font-extrabold">{formatMoney(viewingPreview?.quotedTotal ?? viewingQuotation.totalAmount, viewingQuotation.currency)}</div>
                  <div className="mt-3 space-y-1 border-t border-white/10 pt-3 text-[11px] text-teal-100/90">
                    <div className="flex justify-between"><span>Daily rate / room</span><b>{formatMoney(viewingPreview?.dailyRate ?? 0, viewingQuotation.currency)}</b></div>
                    <div className="flex justify-between"><span>Daily tourism tax</span><b>{formatMoney(viewingPreview?.dailyTax ?? 0, viewingQuotation.currency)} / night</b></div>
                    <div className="flex justify-between"><span>Total nights</span><b>{viewingQuotation.totalNights}</b></div>
                  </div>
                  {!viewingPreview?.includeTax && (
                    <div className="mt-3 rounded-lg bg-white/10 px-2.5 py-2 text-[10px] text-teal-50">
                      Tourism tax is excluded from the quoted total — the client pays it at check-in.
                    </div>
                  )}
                </div>
              </div>

              {viewingQuotation.notes && <div className="mt-4 text-xs text-slate-500 italic">Notes: {viewingQuotation.notes}</div>}
            </div>

            )}

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => copyWhatsAppQuotation(viewingQuotation)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  <Copy size={14} /> Copy WhatsApp / Email Proposal
                </button>
                <button
                  type="button"
                  disabled={shareBusy}
                  onClick={() => void handleSharePdf("quotation", viewingQuotation.id)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white hover:bg-[#103f3a] disabled:opacity-60"
                >
                  <ShareIcon size={14} /> Share PDF
                </button>
                <button
                  type="button"
                  onClick={() => handleDownload("quotation", viewingQuotation.id)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  <Download size={14} /> Download PDF
                </button>
                {can(currentUser, "send_email") && (
                  <button
                    type="button"
                    onClick={() => setEmailTarget({ kind: "quotation", id: viewingQuotation.id })}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-sky-200 bg-sky-50 px-4 text-xs font-bold text-sky-800 hover:bg-sky-100"
                  >
                    <Mail size={14} /> Email
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => void handleSharePdf("quotation", viewingQuotation.id, "whatsapp")}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-800 hover:bg-emerald-100"
                  title="Download the PDF and open WhatsApp"
                >
                  WhatsApp
                </button>
                <button
                  type="button"
                  onClick={() => void handleSharePdf("quotation", viewingQuotation.id, "telegram")}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-sky-200 bg-white px-3 text-xs font-bold text-sky-700 hover:bg-sky-50"
                  title="Download the PDF and open Telegram"
                >
                  Telegram
                </button>
                <button
                  type="button"
                  onClick={() => setPrintQuote(viewingQuotation)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  <Printer size={14} /> Print
                </button>
              </div>

              <div className="flex items-center gap-2">
                {viewingQuotation.status !== "converted" && (
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => void handleConvertQuotationToBooking(viewingQuotation)}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-5 text-xs font-extrabold text-white shadow-md shadow-teal-900/15 hover:bg-[#103f3a] disabled:opacity-60"
                  >
                    <BookOpenCheck size={15} /> Convert to Confirmed Booking
                  </button>
                )}
                <button
                  type="button"
                  onClick={closeQuotationView}
                  className="h-10 rounded-xl border border-slate-200 px-4 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* COMBINE QUOTATIONS MODAL */}
      {combiningModalOpen && (
        <Modal
          title="Combine Selected Quotations"
          subtitle={`Merge ${selectedQuoteIds.length} quotations into one multi-hotel proposal`}
          onClose={() => setCombiningModalOpen(false)}
          wide
        >
          <form onSubmit={handleCombineSelectedQuotes} className="space-y-5">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <div className="text-xs font-extrabold text-slate-800">Stays being combined:</div>
              <div className="mt-2 space-y-2">
                {data.quotationItems
                  .filter((it) => selectedQuoteIds.includes(it.quotationId))
                  .map((it, idx) => (
                    <div key={it.id} className="flex items-center justify-between rounded-lg bg-white p-2.5 text-xs">
                      <div>
                        <span className="font-bold text-slate-900">{idx + 1}. {hotelName(it.hotelId)}</span>
                        <span className="text-slate-500"> ({roomName(it.roomTypeId)} · {it.nights} nts · {formatDate(it.checkIn)} → {formatDate(it.checkOut)})</span>
                      </div>
                      <span className="font-extrabold text-[#174e48]">{formatMoney(it.totalAmount)}</span>
                    </div>
                  ))}
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Combined Proposal Title" className="md:col-span-2">
                <input
                  name="title"
                  defaultValue={`Combined Itinerary Proposal (${selectedQuoteIds.length} hotels)`}
                  required
                  className={inputClass}
                />
              </Field>
              <Field label="Client / Guest Name">
                <input
                  name="clientName"
                  defaultValue={data.quotations.find((q) => q.id === selectedQuoteIds[0])?.clientName || ""}
                  required
                  className={inputClass}
                />
              </Field>
              <Field label="Company / Partner">
                <input
                  name="clientCompany"
                  defaultValue={data.quotations.find((q) => q.id === selectedQuoteIds[0])?.clientCompany || ""}
                  className={inputClass}
                />
              </Field>
              <Field label="Client Email">
                <input
                  name="clientEmail"
                  type="email"
                  defaultValue={data.quotations.find((q) => q.id === selectedQuoteIds[0])?.clientEmail || ""}
                  className={inputClass}
                />
              </Field>
              <Field label="Client Phone">
                <input
                  name="clientPhone"
                  defaultValue={data.quotations.find((q) => q.id === selectedQuoteIds[0])?.clientPhone || ""}
                  className={inputClass}
                />
              </Field>
              <Field label="Proposal Notes" className="md:col-span-2">
                <textarea
                  name="notes"
                  placeholder="Additional notes for the combined proposal…"
                  className="min-h-20 w-full rounded-xl border border-slate-200 p-3 text-xs outline-none focus:border-teal-700"
                />
              </Field>
            </div>

            <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
              <button
                type="button"
                onClick={() => setCombiningModalOpen(false)}
                className="h-10 rounded-xl border border-slate-200 px-4 text-xs font-bold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-5 text-xs font-bold text-white hover:bg-[#103f3a] disabled:opacity-60"
              >
                {saving ? <Loader2 size={15} className="animate-spin" /> : <Layers size={15} />} Combine & Save Itinerary
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* NEW TRIP PACKAGE MODAL */}
      {newTripOpen && (
        <Modal
          title="New trip package"
          subtitle="Add tours, tickets and transfers — optionally linked to a saved hotel quotation."
          onClose={() => setNewTripOpen(false)}
          wide
        >
          <form onSubmit={handleCreateTrip} className="grid gap-5 md:grid-cols-2">
            <div className="grid content-start gap-4 md:col-span-2">
              <Field label="Package title">
                <input name="title" required defaultValue="Dubai Stay + Tours & Transfers" className={inputClass} />
              </Field>

              <div className="rounded-2xl border border-teal-100 bg-[#f0f8f6] p-4">
                <div className="text-xs font-extrabold text-[#174e48]">Hotels stay (optional)</div>
                <p className="mt-0.5 text-[11px] text-slate-500">Link a saved quotation to carry the hotel stay into this package. Leave empty for a tours-only package.</p>
                <label className="mt-3 block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Linked quotation</span><SelectWrap><select name="quotationId" className={selectClass}><option value="">No hotel stay (tours & services only)</option>{data.quotations.map((q) => <option key={q.id} value={q.id}>{q.reference} · {q.title} · {q.clientName}</option>)}</select></SelectWrap></label>
                <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold text-slate-600">
                  <label className="flex cursor-pointer items-center gap-2"><input type="checkbox" name="includesHotets" defaultChecked hidden /><input type="checkbox" name="includesHotels" defaultChecked className="accent-teal-700" /> Include the hotel stay in this package</label>
                </div>
              </div>

              <div className="rounded-2xl border border-teal-100 bg-[#f0f8f6] p-4">
                <div className="text-xs font-extrabold text-[#174e48]">Tax & markup</div>
                <div className="mt-3 grid gap-3 sm:grid-cols-3">
                  <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-bold text-slate-700 sm:col-span-3">
                    <input type="checkbox" name="includeTax" defaultChecked className="accent-teal-700" /> Include tourism tax in the package total
                  </label>
                  <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Markup value</span><input name="markupValue" type="number" min="0" step="0.01" defaultValue="0" className={`${inputClass} h-10`} /></label>
                  <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Markup type</span><SelectWrap><select name="markupMode" className={`${selectClass} h-10`}><option value="percent">% of net cost</option><option value="amount">Flat AED amount</option></select></SelectWrap></label>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Client / Guest name"><input name="clientName" required className={inputClass} placeholder="James Robertson" /></Field>
                <Field label="Company / Partner"><input name="clientCompany" className={inputClass} placeholder="Luxury Tours UK" /></Field>
                <Field label="Client email"><input name="clientEmail" type="email" className={inputClass} placeholder="client@agency.com" /></Field>
                <Field label="Client phone"><input name="clientPhone" className={inputClass} placeholder="+971…" /></Field>
                <Field label="Package start date"><input name="startDate" type="date" className={inputClass} /></Field>
                <Field label="Package end date"><input name="endDate" type="date" className={inputClass} /></Field>
                <Field label="Package notes" className="md:col-span-2"><textarea name="notes" className="min-h-20 w-full rounded-xl border border-slate-200 p-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" placeholder="Travel preferences, guides, special requests…" /></Field>
              </div>
            </div>
            <div className="flex justify-end border-t border-slate-100 pt-4 md:col-span-2">
              <button disabled={saving} className="flex h-11 min-w-44 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white hover:bg-[#103f3a] disabled:opacity-60">
                {saving ? <Loader2 size={16} className="animate-spin" /> : <PackagePlus size={16} />} Create trip package
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* TRIP PACKAGE DETAIL / ITINERARY MODAL */}
      {viewingTrip && (
        <Modal
          title={`${viewingTrip.reference} · ${viewingTrip.title}`}
          subtitle={`${viewingTrip.clientName}${viewingTrip.clientCompany ? ` — ${viewingTrip.clientCompany}` : ""}`}
          onClose={() => { setViewingTrip(null); setTripPricingEdit(null); }}
          wide
        >
          <div className="space-y-6">
            {/* Status & dates */}
            <div className="flex flex-wrap items-center gap-3 rounded-2xl bg-slate-50 p-4">
              <select value={viewingTrip.status} onChange={(event) => void handleUpdateTripStatus(viewingTrip.id, event.target.value)} className="cursor-pointer rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 outline-none focus:border-teal-600">
                {["draft", "sent", "confirmed", "completed", "cancelled"].map((st) => <option key={st} value={st}>{st}</option>)}
              </select>
              <span className="text-xs text-slate-500">{viewingTrip.startDate ? formatDate(viewingTrip.startDate, { year: "numeric" }) : "Start TBC"} → {viewingTrip.endDate ? formatDate(viewingTrip.endDate, { year: "numeric" }) : "End TBC"}</span>
              {viewingTrip.quotationId && <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-[10px] font-bold text-indigo-700">Hotel stay linked to quotation #{viewingTrip.quotationId}</span>}
              <div className="ml-auto flex flex-wrap gap-2">
                <button disabled={shareBusy} onClick={() => void handleSharePdf("trip", viewingTrip.id)} className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-[#174e48] px-3.5 text-xs font-bold text-white hover:bg-[#103f3a] disabled:opacity-60"><ShareIcon size={14} /> Share PDF</button>
                <button onClick={() => handleDownload("trip", viewingTrip.id)} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:bg-slate-50"><Download size={14} /> Download</button>
                {can(currentUser, "send_email") && (
                  <button onClick={() => setEmailTarget({ kind: "trip", id: viewingTrip.id })} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-sky-200 bg-sky-50 px-3 text-xs font-bold text-sky-800 hover:bg-sky-100"><Mail size={14} /> Email</button>
                )}
                <button onClick={() => void handleSharePdf("trip", viewingTrip.id, "whatsapp")} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-800 hover:bg-emerald-100" title="Download the PDF and open WhatsApp">WhatsApp</button>
                <button onClick={() => void handleSharePdf("trip", viewingTrip.id, "telegram")} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-sky-200 bg-white px-3 text-xs font-bold text-sky-700 hover:bg-sky-50" title="Download the PDF and open Telegram">Telegram</button>
                <button onClick={() => setPrintTrip(viewingTrip)} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 hover:bg-slate-50"><Printer size={14} /> Print</button>
              </div>
            </div>

            {/* Part 1: hotels stay */}
            {hotelItemsFor(viewingTrip.quotationId).length > 0 && (
              <section>
                <h3 className="mb-2 border-l-4 border-[#174e48] pl-2 text-xs font-extrabold uppercase tracking-wide text-[#174e48]">Part 1 · Hotels stay</h3>
                <div className="overflow-hidden rounded-xl border border-slate-200">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                      <tr><th className="px-3 py-2">Hotel</th><th className="px-3 py-2">Room / Board</th><th className="px-3 py-2">Dates</th><th className="px-3 py-2 text-right">Net stay cost</th></tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {hotelItemsFor(viewingTrip.quotationId).map((it) => {
                        const stay = [it.baseAmount, it.boardAmount, it.occupancyAmount, it.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0);
                        return (
                          <tr key={it.id}>
                            <td className="px-3 py-2 font-bold text-slate-800">{hotelName(it.hotelId)}</td>
                            <td className="px-3 py-2 text-slate-600">{roomName(it.roomTypeId)} · {boardLabel(it.boardType)}</td>
                            <td className="px-3 py-2 text-slate-600">{formatDate(it.checkIn)} → {formatDate(it.checkOut)} ({it.nights} nts)</td>
                            <td className="px-3 py-2 text-right font-bold">{formatMoney(stay)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* Part 2: tours/tickets itinerary */}
            <section>
              <h3 className="mb-2 border-l-4 border-[#174e48] pl-2 text-xs font-extrabold uppercase tracking-wide text-[#174e48]">Part 2 · Tours, tickets & transfers itinerary</h3>
              <div className="space-y-2">
                {tripItemsFor(viewingTrip.id).map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-200 p-3">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-xs font-extrabold text-[#174e48]">{item.serviceDate ? formatDate(item.serviceDate) : "Date TBC"} {item.serviceTime ? `· ${item.serviceTime}` : ""}</div>
                        <div className="text-sm font-extrabold text-slate-900">{item.name}</div>
                        <div className="text-[11px] text-slate-500">{item.kind === "tour" ? { ticket_only: "Ticket only", shared: "Shared transfer", private: "Private transfer" }[item.priceType] ?? item.priceType : { shared_one_way: "Shared – one way", shared_two_way: "Shared – two way", private_one_way: "Private vehicle – one way", private_two_way: "Private vehicle – two way", per_person: "Per person", per_vehicle: "Per vehicle" }[item.priceType] ?? item.priceType}</div>
                        <div className="mt-1 grid gap-1 text-[11px] text-slate-500 sm:grid-cols-2">
                          {item.pickup && <div><b className="text-slate-600">Pick-up:</b> {item.pickup}</div>}
                          {item.dropoff && <div><b className="text-slate-600">Drop-off:</b> {item.dropoff}</div>}
                        </div>
                        {item.details && <div className="mt-1 text-[11px] italic text-slate-500">{item.details}</div>}
                      </div>
                      <div className="text-right">
                        <div className="font-extrabold text-slate-900">{formatMoney(item.totalAmount)}</div>
                        <div className="text-[10px] text-slate-400">{item.kind === "service" && (item.priceType.startsWith("private") || item.priceType === "per_vehicle") ? `${item.vehicles} vehicle(s)` : `${item.persons} pax`} × {formatMoney(item.unitPrice)}</div>
                        <button onClick={() => void handleDeleteTripItem(item.id)} className="mt-1.5 rounded-lg p-1.5 text-slate-300 hover:bg-rose-50 hover:text-rose-600" title="Remove"><Trash2 size={14} /></button>
                      </div>
                    </div>
                  </div>
                ))}
                {tripItemsFor(viewingTrip.id).length === 0 && <p className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-4 text-xs text-slate-400">No services or tours added yet — use the form below.</p>}
              </div>
            </section>

            {/* Add line form */}
            <section className="rounded-2xl border border-teal-100 bg-[#f0f8f6] p-4">
              <div className="text-xs font-extrabold text-[#174e48]">Add a service or tour / ticket</div>
              <form onSubmit={handleAddTripItem} className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Type</span><SelectWrap><select value={itemDraft.kind} onChange={(event) => { const kind = event.target.value; const id = kind === "service" ? data.services[0]?.id ?? 0 : data.tours[0]?.id ?? 0; pickCatalogItem(kind, id); }} className={`${selectClass} h-10`}><option value="service">Service / transfer</option><option value="tour">Tour / ticket</option></select></SelectWrap></label>

                <label className="block sm:col-span-2"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">{itemDraft.kind === "service" ? "Service" : "Tour / ticket"}</span>
                  <SelectWrap>
                    <select value={itemDraft.catalogId || ""} onChange={(event) => pickCatalogItem(itemDraft.kind, Number(event.target.value))} className={`${selectClass} h-10`}>
                      <option value="">Choose…</option>
                      {itemDraft.kind === "service"
                        ? data.services.map((svc) => <option key={svc.id} value={svc.id}>{svc.name} {svc.vehicleType ? `· ${svc.vehicleType}` : ""}</option>)
                        : data.tours.map((tour) => <option key={tour.id} value={tour.id}>{tour.name} · {tour.category === "ticket" ? "Ticket" : "Tour"}</option>)}
                    </select>
                  </SelectWrap>
                </label>

                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Price applies to</span>
                  <SelectWrap>
                    <select value={itemDraft.priceType} onChange={(event) => {
                      const priceType = event.target.value;
                      const svc = data.services.find((item) => item.id === itemDraft.catalogId);
                      const tour = data.tours.find((item) => item.id === itemDraft.catalogId);
                      const isPrivateType = priceType.startsWith("private");
                      let unitPrice = itemDraft.unitPrice;
                      let priceMode = itemDraft.priceMode;
                      if (itemDraft.kind === "service" && svc) {
                        priceMode = isPrivateType ? "per_vehicle" : "per_person";
                        unitPrice = priceType.includes("two_way") ? String(svc.twoWayPrice || 0) : String(svc.oneWayPrice || 0);
                      } else if (itemDraft.kind === "tour" && tour) {
                        priceMode = "per_person";
                        unitPrice = priceType === "shared" ? String(tour.sharedTransferPrice || 0) : priceType === "private" ? String(tour.privateTransferPrice || 0) : String(tour.ticketOnlyPrice || 0);
                      }
                      setItemDraft((current) => ({ ...current, priceType, priceMode, unitPrice }));
                    }} className={`${selectClass} h-10`}>
                      {itemDraft.kind === "service" ? (
                        <>
                          <option value="shared_one_way">Shared – one way (per person)</option>
                          <option value="shared_two_way">Shared – two way (per person)</option>
                          <option value="private_one_way">Private vehicle – one way</option>
                          <option value="private_two_way">Private vehicle – two way</option>
                        </>
                      ) : (
                        <>
                          <option value="ticket_only">Ticket only (per person)</option>
                          <option value="shared">Shared transfer (per person)</option>
                          <option value="private">Private transfer</option>
                        </>
                      )}
                    </select>
                  </SelectWrap>
                </label>

                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Name</span><input name="itemName" value={itemDraft.name} onChange={(event) => setItemDraft((current) => ({ ...current, name: event.target.value }))} required className={`${inputClass} h-10`} /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Unit price (AED)</span><input name="unitPrice" type="number" min="0" step="0.01" value={itemDraft.unitPrice} onChange={(event) => setItemDraft((current) => ({ ...current, unitPrice: event.target.value }))} className={`${inputClass} h-10`} /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">{itemDraft.priceMode === "per_vehicle" ? "Vehicles" : "Persons"}</span>
                  <input name="persons" type="number" min="1" value={itemDraft.persons} onChange={(event) => setItemDraft((current) => ({ ...current, persons: Number(event.target.value) }))} className={`${inputClass} h-10`} />
                  <input type="hidden" name="vehicles" value={itemDraft.vehicles} />
                  <input type="hidden" name="priceMode" value={itemDraft.priceMode} />
                </label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Date</span><input name="serviceDate" type="date" className={`${inputClass} h-10`} /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Time</span><input name="serviceTime" type="time" className={`${inputClass} h-10`} /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Pick-up</span><input name="pickup" className={`${inputClass} h-10`} placeholder="e.g. DXB Terminal 3 arrivals" /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Drop-off</span><input name="dropoff" className={`${inputClass} h-10`} placeholder="e.g. Hotel lobby" /></label>
                <label className="block sm:col-span-2"><span className="mb-1.5 block text-[10px] font-bold uppercase text-slate-400">Details</span><input name="details" value={itemDraft.details} onChange={(event) => setItemDraft((current) => ({ ...current, details: event.target.value }))} className={`${inputClass} h-10`} placeholder="Ticket type, meeting point, guide…" /></label>
                <div className="flex items-end">
                  <button disabled={saving || itemDraft.catalogId === 0} className="flex h-10 w-full items-center justify-center gap-1.5 rounded-xl bg-[#174e48] px-4 text-xs font-extrabold text-white hover:bg-[#103f3a] disabled:opacity-50">
                    <Plus size={14} /> Add to itinerary
                  </button>
                </div>
              </form>
            </section>

            {/* Pricing */}
            <section className="rounded-2xl border border-teal-200 bg-teal-50/40 p-4">
              <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs font-extrabold text-teal-900">Package pricing</div>
                    <button type="button" disabled={saving} onClick={() => void saveTripPricing()} className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-[#174e48] px-3 text-[11px] font-bold text-white hover:bg-[#103f3a] disabled:opacity-50"><CheckCircle2 size={13} /> Save pricing</button>
                  </div>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">
                    <label className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-teal-200 bg-white px-3 py-2.5 text-xs font-bold text-slate-700">
                      <input type="checkbox" checked={tripPricingEdit?.includeTax ?? true} onChange={(event) => setTripPricingEdit((current) => (current ? { ...current, includeTax: event.target.checked } : current))} className="accent-teal-700" /> Include tourism tax
                    </label>
                    <div className="flex items-center gap-2 rounded-xl border border-teal-200 bg-white px-3 py-2">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Markup</span>
                      <input type="number" min="0" step="0.01" value={tripPricingEdit?.markupValue ?? "0"} onChange={(event) => setTripPricingEdit((current) => (current ? { ...current, markupValue: event.target.value } : current))} className="h-8 w-full rounded-lg border border-slate-200 px-2 text-xs font-bold outline-none focus:border-teal-700" />
                      <div className="flex overflow-hidden rounded-lg border border-slate-200 p-0.5">
                        {(["percent", "amount"] as const).map((mode) => (
                          <button key={mode} type="button" onClick={() => setTripPricingEdit((current) => (current ? { ...current, markupMode: mode } : current))} className={`rounded-md px-1.5 py-1 text-[10px] font-extrabold ${tripPricingEdit?.markupMode === mode ? "bg-teal-700 text-white" : "text-slate-500 hover:bg-slate-100"}`}>{mode === "percent" ? "%" : "AED"}</button>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 space-y-1.5 rounded-xl bg-white p-3 text-xs text-slate-600">
                    <div className="flex justify-between"><span>Hotel stay (net hotel cost):</span><b className="text-slate-900">{formatMoney(viewingTrip.hotelCostTotal)}</b></div>
                    <div className="flex justify-between"><span>Tours, tickets & transfers:</span><b className="text-slate-900">{formatMoney(viewingTrip.extrasCostTotal)}</b></div>
                    <div className="flex justify-between"><span>Our markup:</span><b className="text-teal-700">+ {formatMoney(viewingTrip.markupAmount)}</b></div>
                    <div className="flex justify-between"><span>Tourism tax {viewingTrip.includeTax ? "included" : "excluded (payable at hotel)"}:</span><b>{formatMoney(viewingTrip.tourismTaxAmount)}</b></div>
                  </div>
                </div>
                <div className="rounded-xl bg-[#174e48] p-4 text-white">
                  <div className="text-[10px] uppercase tracking-wider text-teal-100">Package total {viewingTrip.includeTax ? "(incl. tax)" : "(excl. tax)"}</div>
                  <div className="mt-0.5 text-2xl font-extrabold">{formatMoney(viewingTrip.quotedTotal || viewingTrip.totalAmount, viewingTrip.currency)}</div>
                  <div className="mt-3 border-t border-white/10 pt-3 text-[11px] text-teal-100/90">
                    {tripItemsFor(viewingTrip.id).length} itinerary line{tripItemsFor(viewingTrip.id).length === 1 ? "" : "s"}
                    {viewingTrip.quotationId && <> · 1 hotel stay linked</>}
                  </div>
                </div>
              </div>
            </section>
          </div>
        </Modal>
      )}

      {/* EMAIL COMPOSER */}
      {emailTarget && (() => {
        const quote = emailTarget.kind === "quotation" ? data.quotations.find((q) => q.id === emailTarget.id) : null;
        const pkg = emailTarget.kind === "trip" ? data.tripPackages.find((p) => p.id === emailTarget.id) : null;
        const source = quote ?? pkg;
        if (!source) return null;
        const total = formatMoney(source.quotedTotal || source.totalAmount, source.currency);
        const label = emailTarget.kind === "quotation" ? "quotation" : "trip package";
        return (
          <Modal title={`Email ${label}`} subtitle={`${source.reference} · PDF is attached automatically`} onClose={() => setEmailTarget(null)} wide>
            <form onSubmit={handleSendEmail} className="grid gap-4 md:grid-cols-2">
              {!smtp?.active && (
                <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-3.5 py-3 text-xs font-semibold text-amber-800 md:col-span-2">
                  <AlertTriangle size={15} className="mt-px shrink-0" />
                  Email is not configured yet. {can(currentUser, "settings") ? "Add SMTP details in Users & settings first." : "Ask an administrator to set up SMTP."}
                </div>
              )}
              <Field label="To"><input name="to" type="email" required defaultValue={source.clientEmail} className={inputClass} placeholder="client@agency.com" /></Field>
              <Field label="CC (optional)"><input name="cc" type="email" className={inputClass} /></Field>
              <Field label="Subject" className="md:col-span-2">
                <input name="subject" required defaultValue={`${source.title} — proposal ${source.reference}`} className={inputClass} />
              </Field>
              <Field label="Message" className="md:col-span-2">
                <textarea
                  name="message"
                  required
                  defaultValue={`Dear ${source.clientName},\n\nThank you for your enquiry. Please find attached our proposal "${source.title}" (reference ${source.reference}).\n\nTotal proposal cost: ${total}\n\nThe attached PDF contains the full breakdown. This proposal is subject to availability at the time of confirmation.\n\nKind regards,\n${currentUser.name}\nLuxury Attractions`}
                  className="min-h-48 w-full rounded-xl border border-slate-200 p-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10"
                />
              </Field>
              <div className="flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-xs text-slate-600 md:col-span-2">
                <FileText size={15} className="text-[#174e48]" />
                Attachment: <b>{pdfFileName(source.reference, source.title)}</b>
              </div>
              <div className="flex justify-end border-t border-slate-100 pt-4 md:col-span-2">
                <button disabled={emailSending || !smtp?.active} className="flex h-11 min-w-40 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white hover:bg-[#103f3a] disabled:opacity-50">
                  {emailSending ? <Loader2 size={16} className="animate-spin" /> : <SendIcon size={16} />} {emailSending ? "Sending…" : "Send email"}
                </button>
              </div>
            </form>
          </Modal>
        );
      })()}

      {/* USER FORM */}
      {userFormOpen && (
        <Modal
          title={editingUser ? `Edit ${editingUser.name}` : "Add user"}
          subtitle="Roles set a sensible default; tick individual permissions to fine-tune access."
          onClose={() => { setUserFormOpen(false); setEditingUser(null); }}
          wide
        >
          <form onSubmit={saveUser} className="grid gap-4 md:grid-cols-2">
            <Field label="Full name"><input name="name" required defaultValue={editingUser?.name ?? ""} className={inputClass} placeholder="Sarah Ahmed" /></Field>
            {editingUser ? (
              <Field label="Email (cannot be changed)"><input value={editingUser.email} disabled className={`${inputClass} bg-slate-50 text-slate-500`} /></Field>
            ) : (
              <Field label="Email"><input name="email" type="email" required className={inputClass} placeholder="sarah@luxuryattractions.com" /></Field>
            )}
            <Field label="Phone (optional)"><input name="phone" defaultValue={editingUser?.phone ?? ""} className={inputClass} placeholder="+971…" /></Field>
            <Field label={editingUser ? "Reset password (optional)" : "Temporary password"} hint={editingUser ? "Leave blank to keep the current password." : "At least 8 characters. The user is asked to change it."}>
              <input name="password" type="text" required={!editingUser} minLength={8} className={inputClass} placeholder="At least 8 characters" />
            </Field>

            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Role</span>
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                {Object.entries(ROLE_PRESETS).map(([key, preset]) => (
                  <button
                    type="button"
                    key={key}
                    onClick={() => { setUserRole(key); setUserPerms([...preset.permissions]); }}
                    className={`rounded-xl border p-3 text-left transition ${userRole === key ? "border-teal-600 bg-teal-50/60 ring-1 ring-teal-600" : "border-slate-200 hover:bg-slate-50"}`}
                  >
                    <div className="text-xs font-extrabold text-slate-800">{preset.label}</div>
                    <div className="mt-1 text-[10px] leading-4 text-slate-500">{preset.description}</div>
                  </button>
                ))}
              </div>
            </div>

            {userRole !== "admin" && (
              <div className="md:col-span-2">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Permissions</span>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {Array.from(new Set(PERMISSIONS.map((perm) => perm.group))).map((group) => (
                    <div key={group}>
                      <div className="mb-1.5 text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{group}</div>
                      <div className="space-y-1.5">
                        {PERMISSIONS.filter((perm) => perm.group === group).map((perm) => (
                          <label key={perm.key} className="flex cursor-pointer items-start gap-2 text-[11px] font-semibold text-slate-600">
                            <input
                              type="checkbox"
                              checked={userPerms.includes(perm.key)}
                              onChange={(event) => setUserPerms((current) => event.target.checked ? [...current, perm.key] : current.filter((item) => item !== perm.key))}
                              className="mt-0.5 accent-teal-700"
                            />
                            {perm.label}
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                <p className="mt-2 text-[11px] text-slate-400">“See net hotel cost & markup” controls whether this person sees what the hotel charges you and your margin. Client PDFs never show it.</p>
              </div>
            )}

            {editingUser && (
              <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-700 md:col-span-2">
                <input name="active" type="checkbox" defaultChecked={editingUser.active} className="accent-teal-700" /> Account is active (can sign in)
              </label>
            )}

            <SubmitRow saving={saving} label={editingUser ? "Save changes" : "Create user"} />
          </form>
        </Modal>
      )}

      {/* CHANGE PASSWORD */}
      {passwordOpen && (
        <Modal title="Change your password" subtitle={currentUser.email} onClose={() => setPasswordOpen(false)}>
          <form onSubmit={changePassword} className="grid gap-4">
            <Field label="Current password"><input name="currentPassword" type="password" required className={inputClass} autoComplete="current-password" /></Field>
            <Field label="New password" hint="At least 8 characters."><input name="newPassword" type="password" required minLength={8} className={inputClass} autoComplete="new-password" /></Field>
            <SubmitRow saving={saving} label="Update password" />
          </form>
        </Modal>
      )}

      {/* PRINT SHELLS */}
      {printQuote && (
        <PrintShell
          title={`Quotation PDF · ${printQuote.reference}`}
          onClose={() => setPrintQuote(null)}
        >
          <QuotationPrint
            quote={printQuote}
            items={data.quotationItems.filter((item) => item.quotationId === printQuote.id).sort((a, b) => a.sortOrder - b.sortOrder)}
            hotelName={hotelName}
            roomName={(id) => roomName(id)}
            locationName={locationName}
          />
        </PrintShell>
      )}
      {printTrip && (
        <PrintShell
          title={`Trip package PDF · ${printTrip.reference}`}
          onClose={() => setPrintTrip(null)}
        >
          <TripPackagePrint
            pkg={printTrip}
            hotelItems={hotelItemsFor(printTrip.quotationId)}
            items={tripItemsFor(printTrip.id)}
            hotelName={hotelName}
            roomName={(id) => roomName(id)}
          />
        </PrintShell>
      )}

      {/* DETAIL MODAL: VIEW BOOKING BREAKDOWN */}
      {viewingBooking && (
        <Modal
          title={`Booking · ${viewingBooking.reference}`}
          subtitle={`${viewingBooking.guestName} · Confirmed Reservation`}
          onClose={() => setViewingBooking(null)}
          wide
        >
          <div className="space-y-6">
            <div className="grid gap-4 rounded-2xl bg-slate-50 p-5 sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Lead Guest</span>
                <div className="mt-1 font-bold text-slate-900">{viewingBooking.guestName}</div>
                <div className="text-xs text-slate-500">{viewingBooking.guestEmail}</div>
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Dates & Total Stay</span>
                <div className="mt-1 text-xs font-bold text-slate-800">{formatDate(viewingBooking.checkIn)} → {formatDate(viewingBooking.checkOut)}</div>
                <div className="text-xs text-slate-500">{viewingBooking.nights} Nights · {viewingBooking.rooms} Room(s)</div>
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Total Net Amount</span>
                <div className="mt-1 text-lg font-extrabold text-[#174e48]">{formatMoney(viewingBooking.totalAmount, viewingBooking.currency)}</div>
                <div className="text-[10px] text-slate-400">incl. {formatMoney(viewingBooking.tourismTaxAmount)} tax</div>
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Status</span>
                <div className="mt-1">
                  <StatusBadge status={viewingBooking.status} />
                </div>
              </div>
            </div>

            {/* Segments */}
            <div>
              <h3 className="mb-3 text-sm font-extrabold text-slate-900">Stay Segments</h3>
              <div className="space-y-3">
                {data.bookingItems
                  .filter((it) => it.bookingId === viewingBooking.id)
                  .map((it, idx) => {
                    const h = data.hotels.find((hotel) => hotel.id === it.hotelId);
                    const r = data.rooms.find((room) => room.id === it.roomTypeId);

                    return (
                      <div key={it.id} className="rounded-xl border border-slate-200 p-4">
                        <div className="flex items-center justify-between">
                          <div className="font-extrabold text-slate-900">{idx + 1}. {h?.name}</div>
                          <span className="font-extrabold text-[#174e48]">{formatMoney(it.totalAmount, viewingBooking.currency)}</span>
                        </div>
                        <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
                          <span>Room: <b>{r?.name}</b></span>
                          <span>Board: <b>{boardLabel(it.boardType)}</b></span>
                          <span>Dates: <b>{formatDate(it.checkIn)} → {formatDate(it.checkOut)} ({it.nights} nts)</b></span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            <div className="flex justify-end border-t border-slate-100 pt-4">
              <button
                type="button"
                onClick={() => setViewingBooking(null)}
                className="h-10 rounded-xl border border-slate-200 px-5 text-xs font-bold text-slate-600 hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* CONTACT MANAGERS */}
      {managerGroupId !== null && <ContactManager
        data={data}
        mode="group"
        groupId={managerGroupId}
        onClose={() => setManagerGroupId(null)}
        onChanged={(message) => { setToast({ type: "success", message }); router.refresh(); }}
        onAddGroupContact={openGroupContact}
        onAddHotelContact={openHotelContact}
      />}
      {managerHotelId !== null && <ContactManager
        data={data}
        mode="hotel"
        hotelId={managerHotelId}
        onClose={() => setManagerHotelId(null)}
        onChanged={(message) => { setToast({ type: "success", message }); router.refresh(); }}
        onAddGroupContact={openGroupContact}
        onAddHotelContact={openHotelContact}
      />}
    </div>
  );
}
