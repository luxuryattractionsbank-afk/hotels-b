"use client";

import { Copy, Printer, X } from "lucide-react";
import { ReactNode } from "react";

/* ------------------------------------------------------------------ *
 * A4 print shell — use Print → "Save as PDF" in the browser dialog.   *
 * ------------------------------------------------------------------ */
export function PrintShell({
  title,
  onClose,
  children,
  onCopy,
  copyLabel = "Copy as text",
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  onCopy?: () => void;
  copyLabel?: string;
}) {
  return (
    <div className="fixed inset-0 z-[95] overflow-y-auto bg-slate-800/80 p-4 backdrop-blur-sm">
      <div className="no-print sticky top-0 z-10 mx-auto mb-4 flex max-w-[860px] flex-wrap items-center justify-between gap-3 rounded-xl bg-white px-4 py-3 shadow-lg">
        <div>
          <div className="text-sm font-extrabold text-slate-900">{title}</div>
          <div className="text-[11px] text-slate-500">Print or choose “Save as PDF” in the destination dropdown.</div>
        </div>
        <div className="flex items-center gap-2">
          {onCopy && (
            <button onClick={onCopy} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-600 hover:bg-slate-50">
              <Copy size={14} /> {copyLabel}
            </button>
          )}
          <button onClick={() => window.print()} className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white hover:bg-[#103f3a]">
            <Printer size={14} /> Print / Save as PDF
          </button>
          <button onClick={onClose} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-600 hover:bg-slate-50">
            <X size={14} /> Close
          </button>
        </div>
      </div>
      <div id="print-root" className="mx-auto w-[830px] max-w-full bg-white p-10 text-slate-900 shadow-2xl">{children}</div>
    </div>
  );
}

const money = (value: number | string, currency = "AED") =>
  `${currency} ${Number(value).toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtDate = (date: string) =>
  date ? new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(`${date.slice(0, 10)}T00:00:00Z`)) : "";

function DocHeader({ subtitle, reference, date }: { subtitle: string; reference: string; date: string }) {
  return (
    <header className="mb-6 flex items-start justify-between border-b-2 border-[#174e48] pb-4">
      <div>
        <div className="text-lg font-extrabold tracking-tight text-[#174e48]">LUXURY ATTRACTIONS</div>
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#b27a4b]">Hotel contracts · hotels.luxuryattractions.com</div>
        <div className="mt-2 text-xl font-extrabold text-slate-900">{subtitle}</div>
      </div>
      <div className="text-right text-[11px] text-slate-500">
        <div className="font-extrabold text-slate-800">{reference}</div>
        <div>Issued: {fmtDate(date)}</div>
      </div>
    </header>
  );
}

function InfoGrid({ rows }: { rows: [string, string][] }) {
  return (
    <dl className="mb-5 grid grid-cols-2 gap-x-6 gap-y-1.5 text-[11px]">
      {rows.map(([label, value]) => (
        <div key={label} className="flex justify-between border-b border-dotted border-slate-200 pb-1">
          <dt className="font-semibold text-slate-500">{label}</dt>
          <dd className="font-bold text-slate-800">{value || "—"}</dd>
        </div>
      ))}
    </dl>
  );
}

/* ------------------------------------------------------------------ *
 * 1. QUOTATION PDF                                                    *
 * ------------------------------------------------------------------ */
export type QuotePrintItem = {
  id: number;
  hotelId: number;
  roomTypeId: number;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  totalAmount: string;
};

export type QuotePrintData = {
  reference: string;
  title: string;
  clientName: string;
  clientCompany: string;
  clientEmail: string;
  clientPhone: string;
  validUntil: string | null;
  notes: string;
  status: string;
  totalNights: number;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  hotelCostTotal: string;
  markupAmount: string;
  markupValue: string;
  markupMode: string;
  includeTax: boolean;
  quotedTotal: string;
  totalAmount: string;
  currency: string;
  createdAt: string;
};

export function QuotationPrint({
  quote,
  items,
  hotelName,
  roomName,
  locationName,
}: {
  quote: QuotePrintData;
  items: QuotePrintItem[];
  hotelName: (id: number) => string;
  roomName: (id: number) => string;
  locationName: (id: number | null) => string;
}) {
  const hotelCost = Number(quote.hotelCostTotal) || [quote.baseAmount, quote.boardAmount, quote.occupancyAmount, quote.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0);
  const markup = Number(quote.markupAmount) || 0;
  const tax = Number(quote.tourismTaxAmount) || 0;
  const nights = Math.max(1, Number(quote.totalNights) || 1);
  const totalRooms = items.reduce((sum, it) => sum + (it.rooms || 1), 0) || 1;
  const total = Number(quote.quotedTotal) || Number(quote.totalAmount) || 0;
  // Daily rate quoted to client (cost + markup, distributed over nights and rooms; tax kept separate if excluded)
  const clientDailyRate = (hotelCost + markup) / nights / totalRooms;

  return (
    <article className="text-[12px] leading-relaxed">
      <DocHeader subtitle="Hotel Stay Proposal" reference={quote.reference} date={quote.createdAt.slice(0, 10)} />

      <InfoGrid
        rows={[
          ["Client", quote.clientName],
          ["Company / Partner", quote.clientCompany],
          ["Email", quote.clientEmail],
          ["Phone / WhatsApp", quote.clientPhone],
          ["Valid until", quote.validUntil ? fmtDate(quote.validUntil) : "—"],
          ["Total nights", `${nights} nights`],
        ]}
      />

      <h2 className="mb-2 border-l-4 border-[#174e48] pl-2 text-[13px] font-extrabold uppercase tracking-wide text-[#174e48]">Hotel stays</h2>
      <table className="mb-4 w-full border-collapse text-[11px]">
        <thead>
          <tr className="bg-[#174e48] text-white">
            <th className="border border-[#174e48] px-2 py-1.5 text-left">Hotel</th>
            <th className="border border-[#174e48] px-2 py-1.5 text-left">Room / Board</th>
            <th className="border border-[#174e48] px-2 py-1.5 text-left">Dates</th>
            <th className="border border-[#174e48] px-2 py-1.5 text-center">Nts</th>
            <th className="border border-[#174e48] px-2 py-1.5 text-left">Guests</th>
            <th className="border border-[#174e48] px-2 py-1.5 text-right">Quoted rate</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it) => {
            const stayCost = [it.baseAmount, it.boardAmount, it.occupancyAmount, it.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0);
            // Proportional share of the client-facing quoted rate for this stay (includes markup, cleanly blended)
            const stayMarkup = hotelCost > 0 ? (markup * stayCost) / hotelCost : markup / Math.max(1, items.length);
            const stayTotalQuoted = stayCost + stayMarkup;
            return (
              <tr key={it.id} className="align-top">
                <td className="border border-slate-200 px-2 py-1.5">
                  <b>{hotelName(it.hotelId)}</b>
                  <div className="text-[10px] text-slate-500">{data_hotelLocation(it.hotelId)}</div>
                </td>
                <td className="border border-slate-200 px-2 py-1.5">
                  {roomName(it.roomTypeId)}
                  <div className="text-[10px] text-slate-500">Board: {it.boardType.replace("_", " ").replace(/\b\w/g, (c) => c.toUpperCase())}</div>
                </td>
                <td className="border border-slate-200 px-2 py-1.5 whitespace-nowrap">
                  {fmtDate(it.checkIn)}
                  <div className="text-slate-500">→ {fmtDate(it.checkOut)}</div>
                </td>
                <td className="border border-slate-200 px-2 py-1.5 text-center">{it.nights}</td>
                <td className="border border-slate-200 px-2 py-1.5 whitespace-nowrap">
                  {it.adults}A · {it.children}C · {it.infants}I
                  <div className="text-[10px] text-slate-500">{it.rooms} room(s)</div>
                </td>
                <td className="border border-slate-200 px-2 py-1.5 text-right font-bold">{money(stayTotalQuoted)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-[11px]">
        <div className="grid grid-cols-2 gap-x-8 gap-y-1">
          <div className="flex justify-between"><span>Total nights</span><b>{nights} nights</b></div>
          <div className="flex justify-between"><span>Average daily rate</span><b>{money(clientDailyRate)} / room / night</b></div>
          <div className="flex justify-between">
            <span>Tourism tax</span>
            <b>{quote.includeTax ? `Included (${money(tax)})` : `Excluded (${money(tax / nights)} / night)`}</b>
          </div>
          <div className="flex justify-between"><span>Currency</span><b>{quote.currency || "AED"}</b></div>
        </div>
        <div className="mt-3 flex items-center justify-between rounded-md bg-[#174e48] px-3 py-2 text-white">
          <span className="text-[11px] font-bold uppercase tracking-wide">Total proposal cost {quote.includeTax ? "(incl. tourism tax)" : "(excl. tourism tax)"}</span>
          <span className="text-base font-extrabold">{money(total, quote.currency)}</span>
        </div>
        {!quote.includeTax && <div className="mt-1.5 text-[10px] font-semibold text-amber-700">*Excludes daily tourism tax: {money(tax / nights)} per night — payable directly to the hotel at check-in.*</div>}
      </div>

      {quote.notes && (
        <div className="mb-4">
          <h3 className="mb-1 text-[11px] font-extrabold uppercase text-[#174e48]">Terms & notes</h3>
          <p className="whitespace-pre-wrap text-[11px] text-slate-600">{quote.notes}</p>
        </div>
      )}

      <footer className="mt-6 flex items-center justify-between border-t border-slate-200 pt-3 text-[10px] text-slate-400">
        <span>Rates quoted by Luxury Attractions. Subject to availability at time of confirmation.</span>
        <span>{quote.reference} · {quote.status.toUpperCase()}</span>
      </footer>
    </article>
  );
}

// Small helper so the location column can resolve without threading hotel rows.
let HOTEL_LOCATIONS: Record<number, string> = {};
export function setPrintHotelLocations(map: Record<number, string>) {
  HOTEL_LOCATIONS = map;
}
function data_hotelLocation(hotelId: number) {
  return HOTEL_LOCATIONS[hotelId] ?? "";
}

/* ------------------------------------------------------------------ *
 * 2. TRIP PACKAGE PDF — hotel stay + tours/tickets itinerary           *
 * ------------------------------------------------------------------ */
export type TripItemPrint = {
  id: number;
  kind: string;
  name: string;
  priceType: string;
  serviceDate: string | null;
  serviceTime: string;
  pickup: string;
  dropoff: string;
  persons: number;
  vehicles: number;
  unitPrice: string;
  totalAmount: string;
  details: string;
};

export type TripPackagePrintData = {
  reference: string;
  title: string;
  clientName: string;
  clientCompany: string;
  clientEmail: string;
  clientPhone: string;
  status: string;
  startDate: string | null;
  endDate: string | null;
  includesHotels: boolean;
  includeTax: boolean;
  markupValue: string;
  markupMode: string;
  markupAmount: string;
  hotelCostTotal: string;
  extrasCostTotal: string;
  tourismTaxAmount: string;
  quotedTotal: string;
  totalAmount: string;
  currency: string;
  notes: string;
  createdAt: string;
};

const priceTypeLabel = (kind: string, priceType: string) => {
  if (kind === "tour") {
    if (priceType === "ticket_only") return "Ticket only";
    if (priceType === "shared") return "Tour + shared transfer";
    if (priceType === "private") return "Tour + private transfer";
    return "Per person";
  }
  const map: Record<string, string> = {
    shared_one_way: "Shared transfer – one way",
    shared_two_way: "Shared transfer – two way (return)",
    private_one_way: "Private vehicle – one way",
    private_two_way: "Private vehicle – two way (return)",
    per_person: "Per person",
    per_vehicle: "Per vehicle",
  };
  return map[priceType] ?? "Service";
};

export function TripPackagePrint({
  pkg,
  hotelItems,
  items,
  hotelName,
  roomName,
}: {
  pkg: TripPackagePrintData;
  hotelItems: QuotePrintItem[];
  items: TripItemPrint[];
  hotelName: (id: number) => string;
  roomName: (id: number) => string;
}) {
  const hotelCost = Number(pkg.hotelCostTotal) || 0;
  const extras = Number(pkg.extrasCostTotal) || 0;
  const markup = Number(pkg.markupAmount) || 0;
  const tax = Number(pkg.tourismTaxAmount) || 0;
  const total = Number(pkg.quotedTotal) || Number(pkg.totalAmount) || 0;

  const itinerary = [...items].sort((a, b) => (a.serviceDate ?? "").localeCompare(b.serviceDate ?? "") || (a.serviceTime ?? "").localeCompare(b.serviceTime ?? ""));

  return (
    <article className="text-[12px] leading-relaxed">
      <DocHeader subtitle={`Trip Package · ${pkg.title}`} reference={pkg.reference} date={pkg.createdAt.slice(0, 10)} />

      <InfoGrid
        rows={[
          ["Client", pkg.clientName],
          ["Company / Partner", pkg.clientCompany],
          ["Email", pkg.clientEmail],
          ["Phone / WhatsApp", pkg.clientPhone],
          ["Package dates", `${pkg.startDate ? fmtDate(pkg.startDate) : "—"} → ${pkg.endDate ? fmtDate(pkg.endDate) : "—"}`],
          ["Status", pkg.status],
        ]}
      />

      {pkg.includesHotels && hotelItems.length > 0 && (
        <section className="mb-5">
          <h2 className="mb-2 border-l-4 border-[#174e48] pl-2 text-[13px] font-extrabold uppercase tracking-wide text-[#174e48]">Part 1 · Hotels stay</h2>
          <table className="w-full border-collapse text-[11px]">
            <thead>
              <tr className="bg-[#174e48] text-white">
                <th className="border border-[#174e48] px-2 py-1.5 text-left">Hotel</th>
                <th className="border border-[#174e48] px-2 py-1.5 text-left">Room / Board</th>
                <th className="border border-[#174e48] px-2 py-1.5 text-left">Dates</th>
                <th className="border border-[#174e48] px-2 py-1.5 text-center">Nts</th>
                <th className="border border-[#174e48] px-2 py-1.5 text-right">Stay cost</th>
              </tr>
            </thead>
            <tbody>
              {hotelItems.map((it) => {
                const stayCost = [it.baseAmount, it.boardAmount, it.occupancyAmount, it.extraBedAmount].reduce((sum, v) => sum + (Number(v) || 0), 0);
                const subtotalCost = hotelCost + extras;
                const stayMarkup = subtotalCost > 0 ? (markup * stayCost) / subtotalCost : 0;
                const stayQuoted = stayCost + stayMarkup;
                return (
                  <tr key={it.id} className="align-top">
                    <td className="border border-slate-200 px-2 py-1.5"><b>{hotelName(it.hotelId)}</b></td>
                    <td className="border border-slate-200 px-2 py-1.5">
                      {roomName(it.roomTypeId)}
                      <div className="text-[10px] text-slate-500">{it.boardType.replace("_", " ").replace(/\b\w/g, (c) => c.toUpperCase())} · {it.adults}A · {it.children}C · {it.infants}I · {it.rooms} room(s)</div>
                    </td>
                    <td className="border border-slate-200 px-2 py-1.5 whitespace-nowrap">{fmtDate(it.checkIn)}<div className="text-slate-500">→ {fmtDate(it.checkOut)}</div></td>
                    <td className="border border-slate-200 px-2 py-1.5 text-center">{it.nights}</td>
                    <td className="border border-slate-200 px-2 py-1.5 text-right font-bold">{money(stayQuoted)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>
      )}

      <section className="mb-5">
        <h2 className="mb-2 border-l-4 border-[#174e48] pl-2 text-[13px] font-extrabold uppercase tracking-wide text-[#174e48]">
          Part 2 · Tours & tickets itinerary
        </h2>
        {itinerary.length === 0 ? (
          <p className="text-[11px] text-slate-400">No tours, tickets or transfers added yet.</p>
        ) : (
          <div className="space-y-2">
            {itinerary.map((it) => {
              const itemCost = Number(it.totalAmount) || 0;
              const subtotalCost = hotelCost + extras;
              const itemMarkup = subtotalCost > 0 ? (markup * itemCost) / subtotalCost : 0;
              const itemQuoted = itemCost + itemMarkup;
              const isPrivate = it.kind === "service" && (it.priceType.startsWith("private") || it.priceType === "per_vehicle");
              const qty = isPrivate ? Math.max(1, it.vehicles) : Math.max(1, it.persons);
              const quotedUnitPrice = qty > 0 ? itemQuoted / qty : itemQuoted;
              return (
                <div key={it.id} className="rounded-lg border border-slate-200 p-2.5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-extrabold text-slate-900">
                        {it.serviceDate ? fmtDate(it.serviceDate) : "Date TBC"} {it.serviceTime ? `· ${it.serviceTime}` : ""}
                      </div>
                      <div className="text-[12px] font-bold text-[#174e48]">{it.name}</div>
                      <div className="text-[11px] text-slate-500">{priceTypeLabel(it.kind, it.priceType)}</div>
                    </div>
                    <div className="text-right text-[11px]">
                      <div className="font-extrabold text-slate-900">{money(itemQuoted)}</div>
                      <div className="text-slate-500">{isPrivate ? `${it.vehicles} vehicle(s)` : `${it.persons} pax`} × {money(quotedUnitPrice)}</div>
                    </div>
                  </div>
                  {(it.pickup || it.dropoff) && (
                    <div className="mt-1.5 grid grid-cols-2 gap-3 text-[10px] text-slate-500">
                      <div><b className="text-slate-600">Pick-up:</b> {it.pickup || "—"}</div>
                      <div><b className="text-slate-600">Drop-off:</b> {it.dropoff || "—"}</div>
                    </div>
                  )}
                  {it.details && <div className="mt-1 text-[10px] italic text-slate-500">{it.details}</div>}
                </div>
              );
            })}
          </div>
        )}
      </section>

      <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-[11px]">
        <div className="grid grid-cols-2 gap-x-8 gap-y-1">
          {pkg.includesHotels && hotelItems.length > 0 && (
            <div className="flex justify-between"><span>Hotels stay total</span><b>{money(hotelCost + (hotelCost + extras > 0 ? (markup * hotelCost) / (hotelCost + extras) : 0))}</b></div>
          )}
          {itinerary.length > 0 && (
            <div className="flex justify-between"><span>Tours, tickets & transfers total</span><b>{money(extras + (hotelCost + extras > 0 ? (markup * extras) / (hotelCost + extras) : 0))}</b></div>
          )}
          <div className="flex justify-between">
            <span>Tourism tax</span>
            <b>{pkg.includeTax ? `Included (${money(tax)})` : `Excluded (${money(tax)})`}</b>
          </div>
          <div className="flex justify-between"><span>Currency</span><b>{pkg.currency || "AED"}</b></div>
        </div>
        <div className="mt-3 flex items-center justify-between rounded-md bg-[#174e48] px-3 py-2 text-white">
          <span className="text-[11px] font-bold uppercase tracking-wide">Package total {pkg.includeTax ? "(incl. tourism tax)" : "(excl. tourism tax)"}</span>
          <span className="text-base font-extrabold">{money(total, pkg.currency)}</span>
        </div>
        {!pkg.includeTax && Number(tax) > 0 && (
          <div className="mt-1.5 text-[10px] font-semibold text-amber-700">*Excludes tourism tax: {money(tax)} — payable directly to the hotel at check-in.*</div>
        )}
      </div>

      {pkg.notes && (
        <div className="mb-4">
          <h3 className="mb-1 text-[11px] font-extrabold uppercase text-[#174e48]">Package notes</h3>
          <p className="whitespace-pre-wrap text-[11px] text-slate-600">{pkg.notes}</p>
        </div>
      )}

      <footer className="mt-6 flex items-center justify-between border-t border-slate-200 pt-3 text-[10px] text-slate-400">
        <span>All rates quoted by Luxury Attractions. Tours and tickets supplied as listed. Subject to availability.</span>
        <span>{pkg.reference}</span>
      </footer>
    </article>
  );
}
