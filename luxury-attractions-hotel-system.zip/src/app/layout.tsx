import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hotel Contracts | Luxury Attractions",
  description: "B2B hotel contracts, rates, availability, and booking management for Luxury Attractions.",
  applicationName: "Luxury Attractions Hotel Contracts",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
