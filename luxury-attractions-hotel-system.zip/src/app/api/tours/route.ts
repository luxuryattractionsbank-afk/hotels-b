import { db } from "@/db";
import { tours } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function GET() {
  try {
    const list = await db.select().from(tours);
    return Response.json({ tours: list });
  } catch {
    return Response.json({ error: "Failed to load tours." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    if (!name) return Response.json({ error: "Tour / ticket name is required." }, { status: 400 });

    const [tour] = await db
      .insert(tours)
      .values({
        name,
        category: String(body.category) === "ticket" ? "ticket" : "tour",
        ticketOnlyPrice: String(Math.max(0, Number(body.ticketOnlyPrice) || 0)),
        sharedTransferPrice: String(Math.max(0, Number(body.sharedTransferPrice) || 0)),
        privateTransferPrice: String(Math.max(0, Number(body.privateTransferPrice) || 0)),
        details: String(body.details || ""),
      })
      .returning();
    revalidatePath("/");
    return Response.json({ tour }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this tour / ticket." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Tour id required." }, { status: 400 });
    await db.delete(tours).where(eq(tours.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this tour / ticket." }, { status: 400 });
  }
}
