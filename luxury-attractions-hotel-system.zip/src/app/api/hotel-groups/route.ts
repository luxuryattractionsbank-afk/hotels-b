import { db } from "@/db";
import { hotelGroups } from "@/db/schema";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    if (!name) return Response.json({ error: "Enter the group or chain name." }, { status: 400 });

    const [group] = await db
      .insert(hotelGroups)
      .values({ name, website: String(body.website || ""), notes: String(body.notes || "") })
      .onConflictDoUpdate({ target: hotelGroups.name, set: { website: String(body.website || ""), notes: String(body.notes || "") } })
      .returning();
    revalidatePath("/");
    return Response.json({ group }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this group." }, { status: 400 });
  }
}
