import { db } from "@/db";
import { ratePeriods } from "@/db/schema";

import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";

const isDate = (value: unknown) => /^\d{4}-\d{2}-\d{2}$/.test(String(value));

export async function POST(request: Request) {
  const guard = await requirePermission("rates");
  if (guard.error) return guard.error;
  try {
    const body = await request.json();
    const hotelId = Number(body.hotelId);
    const roomTypeId = Number(body.roomTypeId);
    const validFrom = String(body.validFrom || "");
    const validTo = String(body.validTo || "");
    const name = String(body.name ?? "").trim();
    if (!hotelId || !roomTypeId || !name || !validFrom || !validTo || validTo < validFrom) {
      return Response.json({ error: "Hotel, room, rate name, and a valid date range are required." }, { status: 400 });
    }

    const bookingWindowStart = isDate(body.bookingWindowStart) ? String(body.bookingWindowStart) : null;
    const bookingWindowEnd = isDate(body.bookingWindowEnd) ? String(body.bookingWindowEnd) : null;
    if (bookingWindowStart && bookingWindowEnd && bookingWindowEnd < bookingWindowStart) {
      return Response.json({ error: "The booking window end must be after its start." }, { status: 400 });
    }
    const requestedMarket = String(body.market || "all");
    const market = requestedMarket === "all" || /^[a-z0-9_]+$/.test(requestedMarket) ? requestedMarket : "all";
    const exclusionList: unknown[] = Array.isArray(body.marketExclusions) ? body.marketExclusions : [];
    const marketExclusions = Array.from(
      new Set(
        exclusionList
          .map((value) => String(value).trim().toLowerCase())
          .filter((value) => value !== "all" && /^[a-z0-9_]+$/.test(value)),
      ),
    ).join(",");

    const [rate] = await db
      .insert(ratePeriods)
      .values({
        hotelId,
        roomTypeId,
        name,
        boardType: String(body.boardType || "breakfast"),
        validFrom,
        validTo,
        bookingWindowStart,
        bookingWindowEnd,
        market,
        marketExclusions,
        promoCode: String(body.promoCode || "").trim(),
        baseRate: String(Math.max(0, Number(body.baseRate) || 0)),
        rateBasis: String(body.rateBasis || "room_night"),
        boardAdultSupplement: String(Math.max(0, Number(body.boardAdultSupplement) || 0)),
        boardChildSupplement: String(Math.max(0, Number(body.boardChildSupplement) || 0)),
        boardSupplementBasis: String(body.boardSupplementBasis || "person_night"),
        extraAdultRate: String(Math.max(0, Number(body.extraAdultRate) || 0)),
        extraChildRate: String(Math.max(0, Number(body.extraChildRate) || 0)),
        extraBedRate: String(Math.max(0, Number(body.extraBedRate) || 0)),
        extraBedBasis: String(body.extraBedBasis || "bed_night"),
        minimumNights: Math.max(1, Number(body.minimumNights) || 1),
      })
      .returning();
    revalidatePath("/");
    return Response.json({ rate }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this rate plan." }, { status: 400 });
  }
}
