import { db } from "@/db";
import { hotelAmenities } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

/** Replaces the amenity set for one hotel. */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const hotelId = Number(body.hotelId);
    if (!hotelId) return Response.json({ error: "Choose a hotel first." }, { status: 400 });
    const rawIds: unknown[] = Array.isArray(body.amenityIds) ? body.amenityIds : [];
    const ids = rawIds.map((value) => Number(value)).filter((id) => Number.isInteger(id) && id > 0);

    await db.transaction(async (tx) => {
      await tx.delete(hotelAmenities).where(eq(hotelAmenities.hotelId, hotelId));
      if (ids.length > 0) {
        await tx.insert(hotelAmenities).values(ids.map((amenityId) => ({ hotelId, amenityId })));
      }
    });
    revalidatePath("/");
    return Response.json({ hotelId, amenityIds: ids }, { status: 200 });
  } catch {
    return Response.json({ error: "Unable to update the hotel amenities." }, { status: 400 });
  }
}
