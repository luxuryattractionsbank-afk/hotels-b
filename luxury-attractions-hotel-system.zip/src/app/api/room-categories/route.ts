import { db } from "@/db";
import { roomCategories } from "@/db/schema";
import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";

function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
}

export async function POST(request: Request) {
  const guard = await requirePermission("rooms");
  if (guard.error) return guard.error;
  try {
    const body = await request.json();
    const label = String(body.label ?? "").trim();
    if (!label) return Response.json({ error: "Give the category a name, e.g. Triple Room." }, { status: 400 });
    const slug = String(body.slug || slugify(label));
    if (!slug) return Response.json({ error: "Could not build a code for that category name." }, { status: 400 });

    const [category] = await db
      .insert(roomCategories)
      .values({ slug, label, sortOrder: Math.max(0, Number(body.sortOrder) || 500) })
      .onConflictDoUpdate({ target: roomCategories.slug, set: { label } })
      .returning();
    revalidatePath("/");
    return Response.json({ category }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this room category." }, { status: 400 });
  }
}
