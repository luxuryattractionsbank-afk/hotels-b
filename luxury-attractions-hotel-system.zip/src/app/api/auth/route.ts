import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, destroySession, ensureSeedAdmin, getSessionUser, hashPassword, SESSION_COOKIE, verifyPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    await ensureSeedAdmin();
    const body = (await request.json()) as Record<string, unknown>;
    const action = String(body.action || "login");
    const store = await cookies();

    if (action === "logout") {
      const token = store.get(SESSION_COOKIE)?.value;
      if (token) await destroySession(token);
      store.delete(SESSION_COOKIE);
      return Response.json({ ok: true });
    }

    if (action === "change-password") {
      const current = await getSessionUser();
      if (!current) return Response.json({ error: "Please sign in first." }, { status: 401 });
      const currentPassword = String(body.currentPassword || "");
      const newPassword = String(body.newPassword || "");
      if (newPassword.length < 8) return Response.json({ error: "New password must be at least 8 characters." }, { status: 400 });

      const [row] = await db.select().from(users).where(eq(users.id, current.id)).limit(1);
      if (!row || !(await verifyPassword(currentPassword, row.passwordHash))) {
        return Response.json({ error: "Your current password is incorrect." }, { status: 400 });
      }
      await db.update(users).set({ passwordHash: await hashPassword(newPassword), mustChangePassword: false }).where(eq(users.id, current.id));
      revalidatePath("/");
      return Response.json({ ok: true });
    }

    // Default: login
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!email || !password) return Response.json({ error: "Enter your email and password." }, { status: 400 });

    const [row] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!row || !row.active || !(await verifyPassword(password, row.passwordHash))) {
      return Response.json({ error: "Incorrect email or password." }, { status: 401 });
    }

    const token = await createSession(row.id);
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, row.id));
    store.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 14 * 24 * 60 * 60,
    });
    return Response.json({ ok: true, mustChangePassword: row.mustChangePassword });
  } catch {
    return Response.json({ error: "Sign in failed. Please try again." }, { status: 500 });
  }
}
