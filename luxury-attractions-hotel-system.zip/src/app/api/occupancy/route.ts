import { db } from "@/db";
import { occupancyRules, roomTypes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";

export async function POST(request: Request) {
  const guard = await requirePermission("rooms");
  if (guard.error) return guard.error;
  try {
    const body = await request.json();
    const roomTypeId = Number(body.roomTypeId);
    const adults = Math.max(1, Math.floor(Number(body.adults) || 1));
    const children = Math.max(0, Math.floor(Number(body.children) || 0));
    const infants = Math.max(0, Math.floor(Number(body.infants) || 0));
    const extraBeds = Math.max(0, Math.floor(Number(body.extraBeds) || 0));
    if (!roomTypeId) return Response.json({ error: "Choose a room type." }, { status: 400 });
    const [room] = await db.select({ id: roomTypes.id }).from(roomTypes).where(eq(roomTypes.id, roomTypeId)).limit(1);
    if (!room) return Response.json({ error: "Room type not found." }, { status: 404 });
    const label = String(body.label ?? "").trim() || `${adults}A${children ? ` + ${children}C` : ""}${infants ? ` + ${infants}I` : ""}${extraBeds ? ` + extra bed` : ""}`;
    const [rule] = await db.insert(occupancyRules).values({ roomTypeId, adults, children, infants, extraBeds, label }).returning();
    revalidatePath("/");
    return Response.json({ occupancy: rule }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this occupancy combination." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const guard = await requirePermission("rooms");
  if (guard.error) return guard.error;
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Occupancy id is required." }, { status: 400 });
    await db.delete(occupancyRules).where(eq(occupancyRules.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this occupancy combination." }, { status: 400 });
  }
}
