import { db } from "@/db";
import { tripPackageItems, tripPackages } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";

function round(value: number) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

/** Recalculate the package headline totals after items change (uses stored markup/tax settings). */
async function repricePackage(packageId: number) {
  const [pkg] = await db.select().from(tripPackages).where(eq(tripPackages.id, packageId)).limit(1);
  if (!pkg) return;
  const items = await db.select().from(tripPackageItems).where(eq(tripPackageItems.packageId, packageId));
  const extras = items.reduce((sum, item) => sum + (Number(item.totalAmount) || 0), 0);
  const hotelCost = pkg.includesHotels ? Number(pkg.hotelCostTotal) || 0 : 0;
  const tax = pkg.includesHotels ? Number(pkg.tourismTaxAmount) || 0 : 0;
  const { computeQuotationPricing } = await import("@/lib/quotation-pricing");
  const pricing = computeQuotationPricing({
    hotelCostTotal: hotelCost + extras,
    tourismTaxAmount: tax,
    includeTax: pkg.includeTax !== false,
    markupMode: pkg.markupMode === "amount" ? "amount" : "percent",
    markupValue: Number(pkg.markupValue) || 0,
    totalNights: 1,
    totalRooms: 1,
  });
  await db
    .update(tripPackages)
    .set({
      extrasCostTotal: extras.toFixed(2),
      markupAmount: String(pricing.markupAmount),
      quotedTotal: String(pricing.quotedTotal),
      totalAmount: String(pricing.quotedTotal),
      updatedAt: new Date(),
    })
    .where(eq(tripPackages.id, packageId));
}

export async function POST(request: Request) {
  const guard = await requirePermission("trips");
  if (guard.error) return guard.error;
  try {
    const body = await request.json();
    const packageId = Number(body.packageId);
    if (!packageId) return Response.json({ error: "Package id required." }, { status: 400 });
    const [pkg] = await db.select().from(tripPackages).where(eq(tripPackages.id, packageId)).limit(1);
    if (!pkg) return Response.json({ error: "Trip package not found." }, { status: 404 });

    const kind = String(body.kind) === "tour" ? "tour" : "service";
    const name = String(body.name ?? "").trim();
    if (!name) return Response.json({ error: "Choose a service or tour to add." }, { status: 400 });

    const persons = Math.max(1, Number(body.persons) || 1);
    const vehicles = Math.max(1, Number(body.vehicles) || 1);
    const unitPrice = Math.max(0, Number(body.unitPrice) || 0);
    const priceMode = kind === "service" && String(body.priceMode) === "per_vehicle" ? "per_vehicle" : "per_person";
    const qty = priceMode === "per_vehicle" ? vehicles : persons;
    const total = round(unitPrice * qty);

    const [last] = await db
      .select({ sortOrder: tripPackageItems.sortOrder })
      .from(tripPackageItems)
      .where(eq(tripPackageItems.packageId, packageId))
      .orderBy(desc(tripPackageItems.sortOrder))
      .limit(1);

    const [item] = await db
      .insert(tripPackageItems)
      .values({
        packageId,
        sortOrder: (last?.sortOrder ?? -1) + 1,
        kind,
        serviceId: body.serviceId ? Number(body.serviceId) : null,
        tourId: body.tourId ? Number(body.tourId) : null,
        name,
        priceType: String(body.priceType || (kind === "tour" ? "ticket_only" : "shared_one_way")),
        serviceDate: body.serviceDate ? String(body.serviceDate) : null,
        serviceTime: String(body.serviceTime || ""),
        pickup: String(body.pickup || ""),
        dropoff: String(body.dropoff || ""),
        persons,
        vehicles,
        unitPrice: unitPrice.toFixed(2),
        totalAmount: total.toFixed(2),
        details: String(body.details || ""),
      })
      .returning();

    await repricePackage(packageId);
    revalidatePath("/");
    return Response.json({ item }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to add this line." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const guard = await requirePermission("trips");
  if (guard.error) return guard.error;
  try {
    const params = new URL(request.url).searchParams;
    const id = Number(params.get("id"));
    if (!id) return Response.json({ error: "Item id required." }, { status: 400 });
    const [item] = await db.select().from(tripPackageItems).where(eq(tripPackageItems.id, id)).limit(1);
    if (!item) return Response.json({ error: "Item not found." }, { status: 404 });
    await db.delete(tripPackageItems).where(eq(tripPackageItems.id, id));
    await repricePackage(item.packageId);
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this line." }, { status: 400 });
  }
}
