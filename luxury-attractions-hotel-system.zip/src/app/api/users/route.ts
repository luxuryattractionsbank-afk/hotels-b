import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, requirePermission } from "@/lib/auth";
import { ROLE_PRESETS, serialisePermissions } from "@/lib/permissions";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  const { user, error } = await requirePermission("users");
  if (error) return error;

  try {
    const body = (await request.json()) as Record<string, unknown>;
    const email = String(body.email || "").trim().toLowerCase();
    const name = String(body.name || "").trim();
    const password = String(body.password || "");
    const role = String(body.role || "agent");

    if (!email || !name) return Response.json({ error: "Name and email are required." }, { status: 400 });
    if (password.length < 8) return Response.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    if (!ROLE_PRESETS[role]) return Response.json({ error: "Choose a valid role." }, { status: 400 });

    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return Response.json({ error: "A user with that email already exists." }, { status: 409 });

    const permissionList = Array.isArray(body.permissions) && body.permissions.length > 0
      ? (body.permissions as string[])
      : [...ROLE_PRESETS[role].permissions];

    const [created] = await db
      .insert(users)
      .values({
        email,
        name,
        passwordHash: await hashPassword(password),
        role,
        permissions: serialisePermissions(permissionList),
        phone: String(body.phone || ""),
        active: true,
        mustChangePassword: body.mustChangePassword !== false,
      })
      .returning({ id: users.id, email: users.email, name: users.name, role: users.role });

    revalidatePath("/");
    return Response.json({ user: created }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to create this user." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const { user, error } = await requirePermission("users");
  if (error) return error;

  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "User id is required." }, { status: 400 });

    const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!target) return Response.json({ error: "User not found." }, { status: 404 });

    const patch: Partial<typeof users.$inferInsert> = {};
    if (body.name !== undefined) patch.name = String(body.name).trim();
    if (body.phone !== undefined) patch.phone = String(body.phone);
    if (body.role !== undefined && ROLE_PRESETS[String(body.role)]) patch.role = String(body.role);
    if (Array.isArray(body.permissions)) patch.permissions = serialisePermissions(body.permissions as string[]);
    if (body.active !== undefined) {
      // Never let the last active administrator be disabled.
      if (!body.active && target.role === "admin") {
        const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin"));
        const activeAdmins = admins.length;
        if (activeAdmins <= 1) return Response.json({ error: "You cannot disable the last administrator." }, { status: 400 });
      }
      patch.active = Boolean(body.active);
    }
    if (body.password !== undefined && String(body.password).length > 0) {
      const password = String(body.password);
      if (password.length < 8) return Response.json({ error: "Password must be at least 8 characters." }, { status: 400 });
      patch.passwordHash = await hashPassword(password);
      patch.mustChangePassword = true;
    }

    const [updated] = await db.update(users).set(patch).where(eq(users.id, id)).returning({ id: users.id, name: users.name, role: users.role });
    revalidatePath("/");
    return Response.json({ user: updated });
  } catch {
    return Response.json({ error: "Unable to update this user." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const { user, error } = await requirePermission("users");
  if (error) return error;

  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "User id is required." }, { status: 400 });
    if (user && id === user.id) return Response.json({ error: "You cannot delete your own account." }, { status: 400 });

    const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!target) return Response.json({ error: "User not found." }, { status: 404 });
    if (target.role === "admin") {
      const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin"));
      if (admins.length <= 1) return Response.json({ error: "You cannot delete the last administrator." }, { status: 400 });
    }

    await db.delete(users).where(eq(users.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this user." }, { status: 400 });
  }
}
