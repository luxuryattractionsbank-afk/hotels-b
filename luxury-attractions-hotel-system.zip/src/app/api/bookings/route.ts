import { db } from "@/db";
import { bookingItems, bookings, quotationItems, quotations } from "@/db/schema";
import { loadSearchContext } from "@/lib/search-data";
import { boardLabel, evaluateAvailability, parseCoreCriteria, todayIso } from "@/lib/search-engine";
import { eq, inArray } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;

    // Case 1: Converting a quotation directly into a booking
    if (body.convertQuotationId) {
      const quoteId = Number(body.convertQuotationId);
      const [quote] = await db.select().from(quotations).where(eq(quotations.id, quoteId)).limit(1);
      if (!quote) return Response.json({ error: "Quotation not found." }, { status: 404 });

      const items = await db.select().from(quotationItems).where(eq(quotationItems.quotationId, quoteId)).orderBy(quotationItems.sortOrder);
      if (items.length === 0) return Response.json({ error: "Quotation has no stay segments." }, { status: 400 });

      const guestName = String(body.guestName || quote.clientName || "").trim();
      const guestEmail = String(body.guestEmail || quote.clientEmail || "").trim();
      const guestPhone = String(body.guestPhone || quote.clientPhone || "").trim();
      const notes = String(body.notes || quote.notes || "").trim();
      if (!guestName || !guestEmail) {
        return Response.json({ error: "Guest name and email are required to confirm booking." }, { status: 400 });
      }

      // Earliest check in and latest check out
      const firstItem = items[0];
      const lastItem = items[items.length - 1];
      const reference = `LAH-${Date.now().toString().slice(-7)}-${Math.floor(Math.random() * 90 + 10)}`;

      const result = await db.transaction(async (tx) => {
        const [booking] = await tx
          .insert(bookings)
          .values({
            reference,
            hotelId: firstItem.hotelId,
            roomTypeId: firstItem.roomTypeId,
            ratePeriodId: firstItem.ratePeriodId,
            boardType: firstItem.boardType,
            guestName,
            guestEmail,
            guestPhone,
            checkIn: firstItem.checkIn,
            checkOut: lastItem.checkOut,
            adults: firstItem.adults,
            children: firstItem.children,
            infants: firstItem.infants,
            rooms: firstItem.rooms,
            extraBeds: items.reduce((sum, it) => sum + it.extraBeds, 0),
            sofaBeds: items.reduce((sum, it) => sum + it.sofaBeds, 0),
            babyCots: items.reduce((sum, it) => sum + it.babyCots, 0),
            nights: quote.totalNights,
            baseAmount: quote.baseAmount,
            boardAmount: quote.boardAmount,
            occupancyAmount: quote.occupancyAmount,
            extraBedAmount: quote.extraBedAmount,
            tourismTaxAmount: quote.tourismTaxAmount,
            totalAmount: quote.totalAmount,
            currency: quote.currency,
            status: "confirmed",
            notes: notes ? `${notes} (Converted from Quote ${quote.reference})` : `Converted from Quote ${quote.reference}`,
            quotationId: quote.id,
          })
          .returning();

        const bItems = items.map((it, idx) => ({
          bookingId: booking.id,
          sortOrder: idx,
          hotelId: it.hotelId,
          roomTypeId: it.roomTypeId,
          ratePeriodId: it.ratePeriodId,
          boardType: it.boardType,
          checkIn: it.checkIn,
          checkOut: it.checkOut,
          nights: it.nights,
          adults: it.adults,
          children: it.children,
          infants: it.infants,
          rooms: it.rooms,
          extraBeds: it.extraBeds,
          sofaBeds: it.sofaBeds,
          babyCots: it.babyCots,
          baseAmount: it.baseAmount,
          boardAmount: it.boardAmount,
          occupancyAmount: it.occupancyAmount,
          extraBedAmount: it.extraBedAmount,
          tourismTaxAmount: it.tourismTaxAmount,
          totalAmount: it.totalAmount,
          rateNames: it.rateNames,
          promoCodes: it.promoCodes,
          notes: it.notes,
        }));

        await tx.insert(bookingItems).values(bItems);

        // Update quotation as converted
        await tx
          .update(quotations)
          .set({ status: "converted", convertedBookingId: booking.id, updatedAt: new Date() })
          .where(eq(quotations.id, quote.id));

        return booking;
      });

      revalidatePath("/");
      return Response.json({ booking: result, quotationConverted: true }, { status: 201 });
    }

    // Case 2: Multi-stay booking directly submitted (e.g. from itinerary / combined stays)
    if (Array.isArray(body.items) && body.items.length > 0) {
      const rawItems = body.items as Record<string, unknown>[];
      const guestName = String(body.guestName ?? "").trim();
      const guestEmail = String(body.guestEmail ?? "").trim();
      const guestPhone = String(body.guestPhone ?? "").trim();
      if (!guestName || !guestEmail) {
        return Response.json({ error: "Guest name and email are required." }, { status: 400 });
      }

      let totalSum = 0;
      let baseSum = 0;
      let boardSum = 0;
      let occSum = 0;
      let bedSum = 0;
      let taxSum = 0;
      let nightsSum = 0;

      const validated = rawItems.map((it, idx) => {
        const hotelId = Number(it.hotelId);
        const roomTypeId = Number(it.roomTypeId);
        const checkIn = String(it.checkIn || "");
        const checkOut = String(it.checkOut || "");
        const nights = Number(it.nights) || Math.round((new Date(`${checkOut}T00:00:00Z`).getTime() - new Date(`${checkIn}T00:00:00Z`).getTime()) / 86400000);
        const baseAmount = Number(it.baseAmount) || 0;
        const boardAmount = Number(it.boardAmount) || 0;
        const occupancyAmount = Number(it.occupancyAmount) || 0;
        const extraBedAmount = Number(it.extraBedAmount) || 0;
        const tourismTaxAmount = Number(it.tourismTaxAmount) || 0;
        const totalAmount = Number(it.totalAmount) || (baseAmount + boardAmount + occupancyAmount + extraBedAmount + tourismTaxAmount);

        baseSum += baseAmount;
        boardSum += boardAmount;
        occSum += occupancyAmount;
        bedSum += extraBedAmount;
        taxSum += tourismTaxAmount;
        totalSum += totalAmount;
        nightsSum += nights;

        return {
          sortOrder: idx,
          hotelId,
          roomTypeId,
          ratePeriodId: it.ratePeriodId ? Number(it.ratePeriodId) : null,
          boardType: String(it.boardType || "breakfast"),
          checkIn,
          checkOut,
          nights,
          adults: Math.max(1, Number(it.adults) || 2),
          children: Math.max(0, Number(it.children) || 0),
          infants: Math.max(0, Number(it.infants) || 0),
          rooms: Math.max(1, Number(it.rooms) || 1),
          extraBeds: Math.max(0, Number(it.extraBeds) || 0),
          sofaBeds: Math.max(0, Number(it.sofaBeds) || 0),
          babyCots: Math.max(0, Number(it.babyCots) || 0),
          baseAmount: baseAmount.toFixed(2),
          boardAmount: boardAmount.toFixed(2),
          occupancyAmount: occupancyAmount.toFixed(2),
          extraBedAmount: extraBedAmount.toFixed(2),
          tourismTaxAmount: tourismTaxAmount.toFixed(2),
          totalAmount: totalAmount.toFixed(2),
          rateNames: String(it.rateNames || ""),
          promoCodes: String(it.promoCodes || ""),
          notes: String(it.notes || ""),
        };
      });

      const first = validated[0];
      const last = validated[validated.length - 1];
      const reference = `LAH-${Date.now().toString().slice(-7)}-${Math.floor(Math.random() * 90 + 10)}`;

      const result = await db.transaction(async (tx) => {
        const [booking] = await tx
          .insert(bookings)
          .values({
            reference,
            hotelId: first.hotelId,
            roomTypeId: first.roomTypeId,
            ratePeriodId: first.ratePeriodId,
            boardType: first.boardType,
            guestName,
            guestEmail,
            guestPhone,
            checkIn: first.checkIn,
            checkOut: last.checkOut,
            adults: first.adults,
            children: first.children,
            infants: first.infants,
            rooms: first.rooms,
            extraBeds: validated.reduce((s, it) => s + it.extraBeds, 0),
            sofaBeds: validated.reduce((s, it) => s + it.sofaBeds, 0),
            babyCots: validated.reduce((s, it) => s + it.babyCots, 0),
            nights: nightsSum,
            baseAmount: baseSum.toFixed(2),
            boardAmount: boardSum.toFixed(2),
            occupancyAmount: occSum.toFixed(2),
            extraBedAmount: bedSum.toFixed(2),
            tourismTaxAmount: taxSum.toFixed(2),
            totalAmount: totalSum.toFixed(2),
            currency: String(body.currency || "AED"),
            status: "confirmed",
            notes: String(body.notes || (validated.length > 1 ? `Multi-hotel booking (${validated.length} stays)` : "")),
          })
          .returning();

        const bItems = validated.map((it) => ({ ...it, bookingId: booking.id }));
        await tx.insert(bookingItems).values(bItems);
        return booking;
      });

      revalidatePath("/");
      return Response.json({ booking: result }, { status: 201 });
    }

    // Case 3: Single-stay booking from search
    const criteria = { ...parseCoreCriteria(body), category: "any", bookingDate: todayIso() };
    const boardType = String(body.boardType || "");
    if (!criteria.hotelId || !criteria.roomTypeId || !boardType) {
      return Response.json({ error: "Select a hotel, room and board option from the search results." }, { status: 400 });
    }
    const guestName = String(body.guestName ?? "").trim();
    const guestEmail = String(body.guestEmail ?? "").trim();
    if (!guestName || !guestEmail) return Response.json({ error: "Guest name and email are required." }, { status: 400 });

    const context = await loadSearchContext(criteria.checkIn, criteria.checkOut);
    const availability = evaluateAvailability(context, criteria);
    if (availability.error) return Response.json({ error: availability.error }, { status: 400 });
    const result = availability.results[0];
    if (!result) {
      const reason = availability.excluded[0]?.reason ?? "This room is no longer available.";
      return Response.json({ error: `Unavailable: ${reason}` }, { status: 409 });
    }
    const offer = result.offers.find((item) => item.boardType === boardType);
    if (!offer) return Response.json({ error: `${boardLabel(boardType)} is not contracted for every night of this stay.` }, { status: 409 });

    const reference = `LAH-${Date.now().toString().slice(-7)}-${Math.floor(Math.random() * 90 + 10)}`;
    const bookingResult = await db.transaction(async (tx) => {
      const [b] = await tx
        .insert(bookings)
        .values({
          reference,
          hotelId: result.hotel.id,
          roomTypeId: result.room.id,
          ratePeriodId: offer.primaryRatePeriodId,
          boardType,
          guestName,
          guestEmail,
          guestPhone: String(body.guestPhone || ""),
          checkIn: criteria.checkIn,
          checkOut: criteria.checkOut,
          adults: criteria.adults,
          children: criteria.children,
          infants: criteria.infants,
          rooms: criteria.rooms,
          extraBeds: offer.extraBeds,
          sofaBeds: offer.sofaBeds,
          babyCots: offer.babyCots,
          nights: offer.nights,
          baseAmount: String(offer.baseAmount),
          boardAmount: String(offer.boardAmount),
          occupancyAmount: String(offer.occupancyAmount),
          extraBedAmount: String(offer.extraBedAmount),
          tourismTaxAmount: String(offer.tourismTaxAmount),
          totalAmount: String(offer.totalAmount),
          currency: result.hotel.currency,
          notes: String(body.notes || ""),
          status: "confirmed",
        })
        .returning();

      await tx.insert(bookingItems).values({
        bookingId: b.id,
        sortOrder: 0,
        hotelId: result.hotel.id,
        roomTypeId: result.room.id,
        ratePeriodId: offer.primaryRatePeriodId,
        boardType,
        checkIn: criteria.checkIn,
        checkOut: criteria.checkOut,
        nights: offer.nights,
        adults: criteria.adults,
        children: criteria.children,
        infants: criteria.infants,
        rooms: criteria.rooms,
        extraBeds: offer.extraBeds,
        sofaBeds: offer.sofaBeds,
        babyCots: offer.babyCots,
        baseAmount: String(offer.baseAmount),
        boardAmount: String(offer.boardAmount),
        occupancyAmount: String(offer.occupancyAmount),
        extraBedAmount: String(offer.extraBedAmount),
        tourismTaxAmount: String(offer.tourismTaxAmount),
        totalAmount: String(offer.totalAmount),
        rateNames: offer.rateNames.join(", "),
        promoCodes: offer.promoCodes.join(", "),
        notes: String(body.notes || ""),
      });

      return b;
    });

    revalidatePath("/");
    return Response.json({ booking: bookingResult, offer }, { status: 201 });
  } catch (error) {
    const msg = error instanceof Error ? error.message : "Unable to process booking.";
    return Response.json({ error: msg }, { status: 400 });
  }
}
