import { db } from "@/db";
import { services } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";

export async function GET() {
  try {
    const list = await db.select().from(services);
    return Response.json({ services: list });
  } catch {
    return Response.json({ error: "Failed to load services." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const guard = await requirePermission("catalog");
  if (guard.error) return guard.error;
  try {
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    if (!name) return Response.json({ error: "Service name is required." }, { status: 400 });

    const [service] = await db
      .insert(services)
      .values({
        name,
        kind: ["shared_transfer", "private_transfer", "other"].includes(String(body.kind)) ? String(body.kind) : "shared_transfer",
        vehicleType: String(body.vehicleType || ""),
        priceMode: body.priceMode === "per_vehicle" ? "per_vehicle" : "per_person",
        oneWayPrice: String(Math.max(0, Number(body.oneWayPrice) || 0)),
        twoWayPrice: String(Math.max(0, Number(body.twoWayPrice) || 0)),
        details: String(body.details || ""),
      })
      .returning();
    revalidatePath("/");
    return Response.json({ service }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this service." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const guard = await requirePermission("catalog");
  if (guard.error) return guard.error;
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Service id required." }, { status: 400 });
    await db.delete(services).where(eq(services.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this service." }, { status: 400 });
  }
}
