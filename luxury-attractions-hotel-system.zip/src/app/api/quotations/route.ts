import { db } from "@/db";
import { bookingItems, bookings, quotationItems, quotations } from "@/db/schema";
import { eq, inArray, desc, asc } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { computeQuotationPricing, readQuotationCommercial } from "@/lib/quotation-pricing";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = Number(searchParams.get("id"));

    if (id) {
      const [quote] = await db.select().from(quotations).where(eq(quotations.id, id)).limit(1);
      if (!quote) return Response.json({ error: "Quotation not found." }, { status: 404 });
      const items = await db
        .select()
        .from(quotationItems)
        .where(eq(quotationItems.quotationId, id))
        .orderBy(asc(quotationItems.sortOrder), asc(quotationItems.checkIn));
      return Response.json({ quotation: quote, items });
    }

    const quotes = await db.select().from(quotations).orderBy(desc(quotations.createdAt));
    const items = await db.select().from(quotationItems).orderBy(asc(quotationItems.sortOrder));
    return Response.json({ quotations: quotes, items });
  } catch {
    return Response.json({ error: "Failed to load quotations." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;

    // Case 1: Combine two or more existing quotations into one multi-stay quotation
    if (Array.isArray(body.combineQuotationIds) && body.combineQuotationIds.length >= 2) {
      const quoteIds = body.combineQuotationIds.map(Number).filter((id) => id > 0);
      const sourceQuotes = await db.select().from(quotations).where(inArray(quotations.id, quoteIds));
      const sourceItems = await db
        .select()
        .from(quotationItems)
        .where(inArray(quotationItems.quotationId, quoteIds))
        .orderBy(asc(quotationItems.checkIn));

      if (sourceQuotes.length < 2 || sourceItems.length === 0) {
        return Response.json({ error: "Select at least 2 valid quotations to combine." }, { status: 400 });
      }

      const clientName = String(body.clientName || sourceQuotes[0].clientName || "Combined Itinerary Client").trim();
      const clientEmail = String(body.clientEmail || sourceQuotes[0].clientEmail || "").trim();
      const clientPhone = String(body.clientPhone || sourceQuotes[0].clientPhone || "").trim();
      const clientCompany = String(body.clientCompany || sourceQuotes[0].clientCompany || "").trim();
      const title = String(body.title || `Combined Itinerary (${sourceItems.length} stays)`).trim();

      let baseSum = 0;
      let boardSum = 0;
      let occSum = 0;
      let bedSum = 0;
      let taxSum = 0;
      let totalSum = 0;
      let nightsSum = 0;

      for (const it of sourceItems) {
        baseSum += Number(it.baseAmount) || 0;
        boardSum += Number(it.boardAmount) || 0;
        occSum += Number(it.occupancyAmount) || 0;
        bedSum += Number(it.extraBedAmount) || 0;
        taxSum += Number(it.tourismTaxAmount) || 0;
        totalSum += Number(it.totalAmount) || 0;
        nightsSum += it.nights || 0;
      }

      const commercial = readQuotationCommercial(body);
      const roomsSum = sourceItems.reduce((sum, it) => sum + (it.rooms || 1), 0);
      const pricing = computeQuotationPricing({
        hotelCostTotal: baseSum + boardSum + occSum + bedSum,
        tourismTaxAmount: taxSum,
        includeTax: commercial.includeTax,
        markupMode: commercial.markupMode,
        markupValue: commercial.markupValue,
        totalNights: nightsSum,
        totalRooms: roomsSum || 1,
      });
      void totalSum;

      const reference = `LAQ-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 90 + 10)}`;
      const result = await db.transaction(async (tx) => {
        const [quote] = await tx
          .insert(quotations)
          .values({
            reference,
            title,
            clientName,
            clientEmail,
            clientPhone,
            clientCompany,
            market: sourceQuotes[0].market || "all",
            status: "draft",
            totalNights: nightsSum,
            totalGuests: `${sourceItems[0]?.adults || 2} Adults`,
            baseAmount: baseSum.toFixed(2),
            boardAmount: boardSum.toFixed(2),
            occupancyAmount: occSum.toFixed(2),
            extraBedAmount: bedSum.toFixed(2),
            tourismTaxAmount: taxSum.toFixed(2),
            includeTax: pricing.includeTax,
            markupMode: pricing.markupMode,
            markupValue: String(pricing.markupValue),
            hotelCostTotal: String(pricing.hotelCostTotal),
            markupAmount: String(pricing.markupAmount),
            quotedTotal: String(pricing.quotedTotal),
            totalAmount: String(pricing.quotedTotal),
            currency: sourceQuotes[0].currency || "AED",
            notes: String(body.notes || `Combined from quotations: ${sourceQuotes.map((q) => q.reference).join(", ")}`),
          })
          .returning();

        const itemsToInsert = sourceItems.map((it, idx) => ({
          quotationId: quote.id,
          sortOrder: idx,
          hotelId: it.hotelId,
          roomTypeId: it.roomTypeId,
          ratePeriodId: it.ratePeriodId,
          boardType: it.boardType,
          checkIn: it.checkIn,
          checkOut: it.checkOut,
          nights: it.nights,
          adults: it.adults,
          children: it.children,
          infants: it.infants,
          rooms: it.rooms,
          extraBeds: it.extraBeds,
          sofaBeds: it.sofaBeds,
          babyCots: it.babyCots,
          baseAmount: it.baseAmount,
          boardAmount: it.boardAmount,
          occupancyAmount: it.occupancyAmount,
          extraBedAmount: it.extraBedAmount,
          tourismTaxAmount: it.tourismTaxAmount,
          totalAmount: it.totalAmount,
          rateNames: it.rateNames,
          promoCodes: it.promoCodes,
          notes: it.notes,
        }));

        const insertedItems = await tx.insert(quotationItems).values(itemsToInsert).returning();
        return { quote, items: insertedItems };
      });

      revalidatePath("/");
      return Response.json({ quotation: result.quote, items: result.items }, { status: 201 });
    }

    // Case 2: Create a new quotation with 1 or multiple stay items
    const rawItems = Array.isArray(body.items) ? (body.items as Record<string, unknown>[]) : [];
    if (rawItems.length === 0) {
      return Response.json({ error: "Quotation must have at least one hotel stay." }, { status: 400 });
    }

    const clientName = String(body.clientName ?? "").trim() || "Guest / Partner";
    const clientEmail = String(body.clientEmail ?? "").trim();
    const clientPhone = String(body.clientPhone ?? "").trim();
    const clientCompany = String(body.clientCompany ?? "").trim();
    const title = String(body.title ?? "").trim() || (rawItems.length > 1 ? `Multi-Stay Itinerary (${rawItems.length} hotels)` : "Hotel Stay Quotation");
    const market = String(body.market || "all");
    const currency = String(body.currency || "AED");

    let baseSum = 0;
    let boardSum = 0;
    let occSum = 0;
    let bedSum = 0;
    let taxSum = 0;
    let totalSum = 0;
    let nightsSum = 0;

    const validatedItems = rawItems.map((it, idx) => {
      const hotelId = Number(it.hotelId);
      const roomTypeId = Number(it.roomTypeId);
      if (!hotelId || !roomTypeId) throw new Error("Each stay item requires a valid hotel and room type.");
      const checkIn = String(it.checkIn || "");
      const checkOut = String(it.checkOut || "");
      if (!checkIn || !checkOut || checkOut <= checkIn) throw new Error("Invalid check-in/check-out dates for stay item.");

      const nights = Number(it.nights) || Math.round((new Date(`${checkOut}T00:00:00Z`).getTime() - new Date(`${checkIn}T00:00:00Z`).getTime()) / 86400000);
      const adults = Math.max(1, Number(it.adults) || 2);
      const children = Math.max(0, Number(it.children) || 0);
      const infants = Math.max(0, Number(it.infants) || 0);
      const rooms = Math.max(1, Number(it.rooms) || 1);
      const extraBeds = Math.max(0, Number(it.extraBeds) || 0);
      const sofaBeds = Math.max(0, Number(it.sofaBeds) || 0);
      const babyCots = Math.max(0, Number(it.babyCots) || 0);

      const baseAmount = Number(it.baseAmount) || 0;
      const boardAmount = Number(it.boardAmount) || 0;
      const occupancyAmount = Number(it.occupancyAmount) || 0;
      const extraBedAmount = Number(it.extraBedAmount) || 0;
      const tourismTaxAmount = Number(it.tourismTaxAmount) || 0;
      const totalAmount = Number(it.totalAmount) || (baseAmount + boardAmount + occupancyAmount + extraBedAmount + tourismTaxAmount);

      baseSum += baseAmount;
      boardSum += boardAmount;
      occSum += occupancyAmount;
      bedSum += extraBedAmount;
      taxSum += tourismTaxAmount;
      totalSum += totalAmount;
      nightsSum += nights;

      return {
        sortOrder: idx,
        hotelId,
        roomTypeId,
        ratePeriodId: it.ratePeriodId ? Number(it.ratePeriodId) : null,
        boardType: String(it.boardType || "breakfast"),
        checkIn,
        checkOut,
        nights,
        adults,
        children,
        infants,
        rooms,
        extraBeds,
        sofaBeds,
        babyCots,
        baseAmount: baseAmount.toFixed(2),
        boardAmount: boardAmount.toFixed(2),
        occupancyAmount: occupancyAmount.toFixed(2),
        extraBedAmount: extraBedAmount.toFixed(2),
        tourismTaxAmount: tourismTaxAmount.toFixed(2),
        totalAmount: totalAmount.toFixed(2),
        rateNames: String(it.rateNames || ""),
        promoCodes: String(it.promoCodes || ""),
        notes: String(it.notes || ""),
      };
    });

    void totalSum;
    const commercial = readQuotationCommercial(body);
    const roomsSum = validatedItems.reduce((sum, it) => sum + (it.rooms || 1), 0);
    const pricing = computeQuotationPricing({
      hotelCostTotal: baseSum + boardSum + occSum + bedSum,
      tourismTaxAmount: taxSum,
      includeTax: commercial.includeTax,
      markupMode: commercial.markupMode,
      markupValue: commercial.markupValue,
      totalNights: nightsSum,
      totalRooms: roomsSum || 1,
    });

    const reference = `LAQ-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 90 + 10)}`;
    const result = await db.transaction(async (tx) => {
      const [quote] = await tx
        .insert(quotations)
        .values({
          reference,
          title,
          clientName,
          clientEmail,
          clientPhone,
          clientCompany,
          market,
          status: "draft",
          validUntil: body.validUntil ? String(body.validUntil) : null,
          totalNights: nightsSum,
          totalGuests: `${validatedItems[0]?.adults || 2} Adults${validatedItems[0]?.children ? ` + ${validatedItems[0].children} Children` : ""}`,
          baseAmount: baseSum.toFixed(2),
          boardAmount: boardSum.toFixed(2),
          occupancyAmount: occSum.toFixed(2),
          extraBedAmount: bedSum.toFixed(2),
          tourismTaxAmount: taxSum.toFixed(2),
          includeTax: pricing.includeTax,
          markupMode: pricing.markupMode,
          markupValue: String(pricing.markupValue),
          hotelCostTotal: String(pricing.hotelCostTotal),
          markupAmount: String(pricing.markupAmount),
          quotedTotal: String(pricing.quotedTotal),
          totalAmount: String(pricing.quotedTotal),
          currency,
          notes: String(body.notes || ""),
        })
        .returning();

      const itemsWithQuoteId = validatedItems.map((it) => ({ ...it, quotationId: quote.id }));
      const insertedItems = await tx.insert(quotationItems).values(itemsWithQuoteId).returning();
      return { quote, items: insertedItems };
    });

    revalidatePath("/");
    return Response.json({ quotation: result.quote, items: result.items }, { status: 201 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unable to save quotation.";
    return Response.json({ error: msg }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "Quotation ID required." }, { status: 400 });

    const patch: Partial<typeof quotations.$inferInsert> = {};
    if (body.status !== undefined) patch.status = String(body.status);
    if (body.title !== undefined) patch.title = String(body.title).trim();
    if (body.clientName !== undefined) patch.clientName = String(body.clientName).trim();
    if (body.clientEmail !== undefined) patch.clientEmail = String(body.clientEmail).trim();
    if (body.clientPhone !== undefined) patch.clientPhone = String(body.clientPhone).trim();
    if (body.clientCompany !== undefined) patch.clientCompany = String(body.clientCompany).trim();
    if (body.validUntil !== undefined) patch.validUntil = body.validUntil ? String(body.validUntil) : null;
    if (body.notes !== undefined) patch.notes = String(body.notes);
    patch.updatedAt = new Date();

    // Recompute the client-facing totals whenever tax inclusion or markup changes.
    if (body.includeTax !== undefined || body.markupMode !== undefined || body.markupValue !== undefined) {
      const [current] = await db.select().from(quotations).where(eq(quotations.id, id)).limit(1);
      if (!current) return Response.json({ error: "Quotation not found." }, { status: 404 });

      const commercial = readQuotationCommercial({
        includeTax: body.includeTax ?? current.includeTax,
        markupMode: body.markupMode ?? current.markupMode,
        markupValue: body.markupValue ?? Number(current.markupValue),
      });
      const hotelCost = [current.baseAmount, current.boardAmount, current.occupancyAmount, current.extraBedAmount]
        .reduce((sum, value) => sum + (Number(value) || 0), 0);
      const quoteItems = await db
        .select({ rooms: quotationItems.rooms })
        .from(quotationItems)
        .where(eq(quotationItems.quotationId, id));
      const pricing = computeQuotationPricing({
        hotelCostTotal: hotelCost,
        tourismTaxAmount: Number(current.tourismTaxAmount) || 0,
        includeTax: commercial.includeTax,
        markupMode: commercial.markupMode,
        markupValue: commercial.markupValue,
        totalNights: current.totalNights,
        totalRooms: quoteItems.reduce((sum, item) => sum + (item.rooms || 1), 0) || 1,
      });
      patch.includeTax = pricing.includeTax;
      patch.markupMode = pricing.markupMode;
      patch.markupValue = String(pricing.markupValue);
      patch.hotelCostTotal = String(pricing.hotelCostTotal);
      patch.markupAmount = String(pricing.markupAmount);
      patch.quotedTotal = String(pricing.quotedTotal);
      patch.totalAmount = String(pricing.quotedTotal);
    }

    const [updated] = await db.update(quotations).set(patch).where(eq(quotations.id, id)).returning();
    revalidatePath("/");
    return Response.json({ quotation: updated });
  } catch {
    return Response.json({ error: "Failed to update quotation." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = Number(searchParams.get("id"));
    if (!id) return Response.json({ error: "Quotation ID required." }, { status: 400 });

    await db.delete(quotations).where(eq(quotations.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Failed to delete quotation." }, { status: 400 });
  }
}
