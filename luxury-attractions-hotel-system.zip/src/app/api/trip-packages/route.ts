import { db } from "@/db";
import {
  quotationItems,
  quotations,
  services,
  tripPackageItems,
  tripPackages,
  tours,
} from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { computeQuotationPricing, readQuotationCommercial } from "@/lib/quotation-pricing";

export function round(value: number) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

/** Unit price for a service line: shared = per person, private = per vehicle, one-way or return. */
function serviceTotal(unitPrice: number, priceType: string, persons: number, vehicles: number, priceMode: string) {
  const qty = priceMode === "per_vehicle" ? Math.max(1, vehicles) : Math.max(1, persons);
  return round(unitPrice * qty);
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = Number(searchParams.get("id"));
    const [serviceList, tourList] = await Promise.all([db.select().from(services), db.select().from(tours)]);

    if (id) {
      const [pkg] = await db.select().from(tripPackages).where(eq(tripPackages.id, id)).limit(1);
      if (!pkg) return Response.json({ error: "Trip package not found." }, { status: 404 });
      const items = await db
        .select()
        .from(tripPackageItems)
        .where(eq(tripPackageItems.packageId, id))
        .orderBy(asc(tripPackageItems.serviceDate), asc(tripPackageItems.serviceTime), asc(tripPackageItems.sortOrder));
      let quote = null;
      let hotelItems: (typeof quotationItems.$inferSelect)[] = [];
      if (pkg.quotationId) {
        [quote] = await db.select().from(quotations).where(eq(quotations.id, pkg.quotationId)).limit(1);
        hotelItems = await db
          .select()
          .from(quotationItems)
          .where(eq(quotationItems.quotationId, pkg.quotationId))
          .orderBy(asc(quotationItems.sortOrder));
      }
      return Response.json({ tripPackage: pkg, items, quotation: quote, hotelItems, services: serviceList, tours: tourList });
    }

    const packages = await db.select().from(tripPackages).orderBy(desc(tripPackages.createdAt));
    const items = await db.select().from(tripPackageItems).orderBy(asc(tripPackageItems.sortOrder));
    return Response.json({ tripPackages: packages, items, services: serviceList, tours: tourList });
  } catch {
    return Response.json({ error: "Failed to load trip packages." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const title = String(body.title ?? "").trim() || "Trip Package";
    const clientName = String(body.clientName ?? "").trim() || "Valued Guest";
    const quotationId = Number(body.quotationId) > 0 ? Number(body.quotationId) : null;
    const includesHotels = body.includesHotels === false ? false : Boolean(body.includesHotels ?? true);

    const rawItems = Array.isArray(body.items) ? (body.items as Record<string, unknown>[]) : [];

    const validated: (typeof tripPackageItems.$inferInsert)[] = [];
    let extrasCost = 0;

    for (const [idx, raw] of rawItems.entries()) {
      const kind = String(raw.kind) === "tour" ? "tour" : "service";
      const name = String(raw.name ?? "").trim();
      if (!name) continue;

      const persons = Math.max(1, Number(raw.persons) || 1);
      const vehicles = Math.max(1, Number(raw.vehicles) || 1);
      const unitPrice = Math.max(0, Number(raw.unitPrice) || 0);
      const priceType = String(raw.priceType || (kind === "tour" ? "ticket_only" : "shared_one_way"));
      const priceMode = kind === "service" && String(raw.priceMode) === "per_vehicle" ? "per_vehicle" : "per_person";
      const total = serviceTotal(unitPrice, priceType, persons, vehicles, priceMode);
      extrasCost += total;

      validated.push({
        packageId: 0,
        sortOrder: idx,
        kind,
        serviceId: raw.serviceId ? Number(raw.serviceId) : null,
        tourId: raw.tourId ? Number(raw.tourId) : null,
        name,
        priceType,
        serviceDate: raw.serviceDate ? String(raw.serviceDate) : null,
        serviceTime: String(raw.serviceTime || ""),
        pickup: String(raw.pickup || ""),
        dropoff: String(raw.dropoff || ""),
        persons,
        vehicles,
        unitPrice: unitPrice.toFixed(2),
        totalAmount: total.toFixed(2),
        details: String(raw.details || ""),
      });
    }

    // Drafts can start empty — lines are added in the itinerary editor.

    // Hotel stay cost comes from the linked quotation (what the hotel charges us).
    let hotelCost = 0;
    let taxAmount = 0;
    let quote: (typeof quotations.$inferSelect) | null = null;
    if (quotationId) {
      [quote] = await db.select().from(quotations).where(eq(quotations.id, quotationId)).limit(1);
      if (!quote) return Response.json({ error: "Linked quotation not found." }, { status: 404 });
      hotelCost = Number(quote.hotelCostTotal) || [quote.baseAmount, quote.boardAmount, quote.occupancyAmount, quote.extraBedAmount].reduce((sum, value) => sum + (Number(value) || 0), 0);
      taxAmount = Number(quote.tourismTaxAmount) || 0;
    }

    const commercial = readQuotationCommercial({
      includeTax: body.includeTax ?? quote?.includeTax ?? true,
      markupMode: body.markupMode ?? quote?.markupMode ?? "percent",
      markupValue: body.markupValue ?? quote?.markupValue ?? 0,
    });
    const pricing = computeQuotationPricing({
      hotelCostTotal: hotelCost + extrasCost,
      tourismTaxAmount: taxAmount,
      includeTax: commercial.includeTax,
      markupMode: commercial.markupMode,
      markupValue: commercial.markupValue,
      totalNights: quote?.totalNights || 1,
      totalRooms: 1,
    });

    const reference = `TRP-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 90 + 10)}`;
    const result = await db.transaction(async (tx) => {
      const [pkg] = await tx
        .insert(tripPackages)
        .values({
          reference,
          quotationId,
          title,
          clientName,
          clientEmail: String(body.clientEmail || quote?.clientEmail || ""),
          clientPhone: String(body.clientPhone || quote?.clientPhone || ""),
          clientCompany: String(body.clientCompany || quote?.clientCompany || ""),
          status: "draft",
          startDate: body.startDate ? String(body.startDate) : null,
          endDate: body.endDate ? String(body.endDate) : null,
          includesHotels,
          includeTax: pricing.includeTax,
          markupMode: pricing.markupMode,
          markupValue: String(pricing.markupValue),
          hotelCostTotal: includesHotels ? hotelCost.toFixed(2) : "0.00",
          extrasCostTotal: extrasCost.toFixed(2),
          tourismTaxAmount: includesHotels ? taxAmount.toFixed(2) : "0.00",
          markupAmount: String(pricing.markupAmount),
          quotedTotal: String(pricing.quotedTotal),
          totalAmount: String(pricing.quotedTotal),
          currency: quote?.currency || "AED",
          notes: String(body.notes || ""),
        })
        .returning();

      if (validated.length > 0) {
        const withPkg = validated.map((it) => ({ ...it, packageId: pkg.id }));
        await tx.insert(tripPackageItems).values(withPkg);
      }
      return pkg;
    });

    revalidatePath("/");
    return Response.json({ tripPackage: result }, { status: 201 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unable to save trip package.";
    return Response.json({ error: msg }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "Trip package id required." }, { status: 400 });

    const [current] = await db.select().from(tripPackages).where(eq(tripPackages.id, id)).limit(1);
    if (!current) return Response.json({ error: "Trip package not found." }, { status: 404 });

    const patch: Partial<typeof tripPackages.$inferInsert> = { updatedAt: new Date() };
    if (body.status !== undefined) patch.status = String(body.status);
    if (body.title !== undefined) patch.title = String(body.title).trim();
    if (body.clientName !== undefined) patch.clientName = String(body.clientName).trim();
    if (body.clientEmail !== undefined) patch.clientEmail = String(body.clientEmail);
    if (body.clientPhone !== undefined) patch.clientPhone = String(body.clientPhone);
    if (body.clientCompany !== undefined) patch.clientCompany = String(body.clientCompany);
    if (body.notes !== undefined) patch.notes = String(body.notes);
    if (body.includesHotels !== undefined) patch.includesHotels = Boolean(body.includesHotels);

    // Recompute pricing when tax/markup change or when requested explicitly.
    if (body.includeTax !== undefined || body.markupMode !== undefined || body.markupValue !== undefined || body.reprice) {
      const items = await db.select().from(tripPackageItems).where(eq(tripPackageItems.packageId, id));
      const extras = items.reduce((sum, item) => sum + (Number(item.totalAmount) || 0), 0);
      const commercial = readQuotationCommercial({
        includeTax: body.includeTax ?? current.includeTax,
        markupMode: body.markupMode ?? current.markupMode,
        markupValue: body.markupValue ?? Number(current.markupValue),
      });
      const hotelCost = current.includesHotels ? Number(current.hotelCostTotal) || 0 : 0;
      const tax = current.includesHotels ? Number(current.tourismTaxAmount) || 0 : 0;
      const pricing = computeQuotationPricing({
        hotelCostTotal: hotelCost + extras,
        tourismTaxAmount: tax,
        includeTax: commercial.includeTax,
        markupMode: commercial.markupMode,
        markupValue: commercial.markupValue,
        totalNights: 1,
        totalRooms: 1,
      });
      patch.includeTax = pricing.includeTax;
      patch.markupMode = pricing.markupMode;
      patch.markupValue = String(pricing.markupValue);
      patch.extrasCostTotal = extras.toFixed(2);
      patch.markupAmount = String(pricing.markupAmount);
      patch.quotedTotal = String(pricing.quotedTotal);
      patch.totalAmount = String(pricing.quotedTotal);
    }

    const [updated] = await db.update(tripPackages).set(patch).where(eq(tripPackages.id, id)).returning();
    revalidatePath("/");
    return Response.json({ tripPackage: updated });
  } catch {
    return Response.json({ error: "Failed to update trip package." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Trip package id required." }, { status: 400 });
    await db.delete(tripPackages).where(eq(tripPackages.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Failed to delete trip package." }, { status: 400 });
  }
}
