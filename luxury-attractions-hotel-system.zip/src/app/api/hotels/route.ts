import { db } from "@/db";
import {
  amenities,
  hotelAmenities,
  hotelContactAssignments,
  hotelContacts,
  hotelGroups,
  hotels,
  locations,
} from "@/db/schema";
import { ensureContactAssignments, parseContactIds, readContact } from "@/lib/contact-data";
import { groupContactCandidates } from "@/lib/contact-sharing";
import { eq, ilike, inArray } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";

class InputError extends Error {}

export async function POST(request: Request) {
  const guard = await requirePermission("hotels");
  if (guard.error) return guard.error;
  try {
    await ensureContactAssignments();
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const city = String(body.city ?? "").trim();
    const supplierCode = String(body.supplierCode ?? "").trim().toUpperCase();
    if (!name || !city || !supplierCode) {
      return Response.json({ error: "Hotel name, city, and supplier code are required." }, { status: 400 });
    }

    const rawAmenityIds = body.amenityIds === undefined ? [] : parseContactIds(body.amenityIds);
    const selectedIds = body.includedContactIds === undefined ? undefined : parseContactIds(body.includedContactIds);
    if (rawAmenityIds === null || selectedIds === null) {
      return Response.json({ error: "Invalid amenity or shared contact selection." }, { status: 400 });
    }
    const requestedGroupId = body.groupId ? Number(body.groupId) : null;
    if (requestedGroupId !== null && (!Number.isSafeInteger(requestedGroupId) || requestedGroupId < 1)) {
      return Response.json({ error: "Choose a valid umbrella company." }, { status: 400 });
    }
    const newGroup = body.newGroup && typeof body.newGroup === "object" ? (body.newGroup as Record<string, unknown>) : null;
    const groupName = String(newGroup?.name ?? "").trim();
    if (requestedGroupId && groupName) {
      return Response.json({ error: "Choose an existing group or create a new one, not both." }, { status: 400 });
    }
    if (newGroup && !groupName) {
      return Response.json({ error: "Enter the new umbrella company name." }, { status: 400 });
    }

    const rawContacts = Array.isArray(body.contacts) ? body.contacts : [];
    const newContacts = rawContacts
      .map((value) => ({ ...readContact(value), addToGroup: value && typeof value === "object" && (value as Record<string, unknown>).addToGroup === true }))
      .filter((contact) => contact.name.length > 0);
    if (newContacts.some((contact) => contact.addToGroup) && !requestedGroupId && !groupName) {
      return Response.json({ error: "Choose an umbrella company before adding a contact to it." }, { status: 400 });
    }

    const result = await db.transaction(async (tx) => {
      let groupId = requestedGroupId;
      if (groupName) {
        const [duplicate] = await tx.select({ id: hotelGroups.id }).from(hotelGroups).where(ilike(hotelGroups.name, groupName)).limit(1);
        if (duplicate) throw new InputError("That umbrella company already exists. Select it from the list instead.");
        const [created] = await tx.insert(hotelGroups).values({
          name: groupName.slice(0, 160),
          website: String(newGroup?.website ?? "").trim().slice(0, 1000),
          notes: String(newGroup?.notes ?? "").trim().slice(0, 1000),
        }).returning();
        groupId = created.id;
      } else if (groupId) {
        const [group] = await tx.select({ id: hotelGroups.id }).from(hotelGroups).where(eq(hotelGroups.id, groupId)).limit(1);
        if (!group) throw new InputError("The selected umbrella company no longer exists.");
      }

      if (rawAmenityIds && rawAmenityIds.length > 0) {
        const valid = await tx.select({ id: amenities.id }).from(amenities).where(inArray(amenities.id, rawAmenityIds));
        if (valid.length !== rawAmenityIds.length) throw new InputError("One or more selected amenities are no longer available.");
      }

      let inheritedIds: number[] = [];
      if (groupId && !groupName) {
        const [allContacts, allAssignments, allHotels] = await Promise.all([
          tx.select().from(hotelContacts),
          tx.select({ hotelId: hotelContactAssignments.hotelId, contactId: hotelContactAssignments.contactId }).from(hotelContactAssignments),
          tx.select({ id: hotels.id, groupId: hotels.groupId }).from(hotels),
        ]);
        const candidates = groupContactCandidates(groupId, allContacts, allAssignments, allHotels);
        const allowedIds = new Set(candidates.map((contact) => contact.id));
        inheritedIds = selectedIds ?? candidates.map((contact) => contact.id);
        if (inheritedIds.some((id) => !allowedIds.has(id))) {
          throw new InputError("A selected shared contact does not belong to this umbrella company.");
        }
      } else if (selectedIds && selectedIds.length > 0) {
        throw new InputError("Shared contacts can only be selected for an existing umbrella company.");
      }

      // Location is a district inside the city/emirate; it can be picked or typed in.
      let locationId = Number(body.locationId) > 0 ? Number(body.locationId) : null;
      const newLocationName = String(body.newLocationName ?? "").trim();
      if (locationId) {
        const [existing] = await tx.select().from(locations).where(eq(locations.id, locationId)).limit(1);
        if (!existing) throw new InputError("The selected location no longer exists.");
        if (existing.city.toLowerCase() !== city.toLowerCase()) throw new InputError("That location belongs to a different city/emirate.");
      } else if (newLocationName) {
        const [created] = await tx
          .insert(locations)
          .values({ city, name: newLocationName.slice(0, 120) })
          .onConflictDoUpdate({ target: [locations.city, locations.name], set: { active: true } })
          .returning();
        locationId = created.id;
      }

      const [hotel] = await tx.insert(hotels).values({
        name,
        city,
        locationId,
        supplierCode,
        country: String(body.country || "United Arab Emirates"),
        address: String(body.address || ""),
        businessType: String(body.businessType || "Hotel"),
        groupId,
        website: String(body.website || ""),
        contractsFolderLink: String(body.contractsFolderLink || ""),
        mediaLink: String(body.mediaLink || ""),
        starRating: Math.max(1, Math.min(5, Number(body.starRating) || 5)),
        contactEmail: String(body.contactEmail || ""),
        contactPhone: String(body.contactPhone || ""),
        checkInTime: String(body.checkInTime || "15:00"),
        checkOutTime: String(body.checkOutTime || "12:00"),
        tourismTax: String(Math.max(0, Number(body.tourismTax) || 0)),
        tourismTaxBasis: String(body.tourismTaxBasis || "room_night"),
      }).returning();

      if (rawAmenityIds && rawAmenityIds.length > 0) {
        await tx.insert(hotelAmenities).values(rawAmenityIds.map((amenityId) => ({ hotelId: hotel.id, amenityId })));
      }
      if (inheritedIds.length > 0) {
        await tx.insert(hotelContactAssignments).values(inheritedIds.map((contactId) => ({ hotelId: hotel.id, contactId })));
      }

      for (const contact of newContacts) {
        const { addToGroup, ...values } = contact;
        const [created] = await tx.insert(hotelContacts).values({ ...values, groupId: addToGroup ? groupId : null }).returning();
        await tx.insert(hotelContactAssignments).values({ hotelId: hotel.id, contactId: created.id });
      }
      return { hotel, inheritedCount: inheritedIds.length, contactsCreated: newContacts.length, groupId };
    });

    revalidatePath("/");
    return Response.json(result, { status: 201 });
  } catch (error) {
    const message = error instanceof InputError
      ? error.message
      : error instanceof Error && error.message.includes("unique")
        ? "That supplier code or umbrella company name is already in use."
        : "Unable to save this hotel.";
    return Response.json({ error: message }, { status: error instanceof InputError ? 400 : 409 });
  }
}
