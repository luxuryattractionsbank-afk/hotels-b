import { db } from "@/db";
import { smtpSettings } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import nodemailer from "nodemailer";

async function loadSettings() {
  const [row] = await db.select().from(smtpSettings).limit(1);
  return row ?? null;
}

function buildTransport(settings: NonNullable<Awaited<ReturnType<typeof loadSettings>>>) {
  return nodemailer.createTransport({
    host: settings.host,
    port: settings.port,
    secure: settings.secure,
    auth: settings.username ? { user: settings.username, pass: settings.password } : undefined,
  });
}

/** Save or test the SMTP configuration. */
export async function PUT(request: Request) {
  const { error } = await requirePermission("settings");
  if (error) return error;

  try {
    const body = (await request.json()) as Record<string, unknown>;
    const existing = await loadSettings();

    const values = {
      host: String(body.host || "").trim(),
      port: Math.max(1, Number(body.port) || 587),
      secure: Boolean(body.secure),
      username: String(body.username || "").trim(),
      // Keep the stored password when the field is left blank on edit.
      password: String(body.password || "") || existing?.password || "",
      fromName: String(body.fromName || "Luxury Attractions").trim(),
      fromEmail: String(body.fromEmail || "").trim(),
      replyTo: String(body.replyTo || "").trim(),
      bccSelf: Boolean(body.bccSelf),
      active: Boolean(body.active),
      updatedAt: new Date(),
    };

    if (!values.host || !values.fromEmail) {
      return Response.json({ error: "SMTP host and the from-address are required." }, { status: 400 });
    }

    const saved = existing
      ? (await db.update(smtpSettings).set(values).where(eq(smtpSettings.id, existing.id)).returning())[0]
      : (await db.insert(smtpSettings).values(values).returning())[0];

    revalidatePath("/");
    return Response.json({ settings: { ...saved, password: saved.password ? "********" : "" } });
  } catch {
    return Response.json({ error: "Unable to save SMTP settings." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  const { user, error } = await requirePermission("send_email");
  if (error) return error;

  try {
    const body = (await request.json()) as Record<string, unknown>;
    const settings = await loadSettings();
    if (!settings || !settings.active || !settings.host) {
      return Response.json({ error: "Email is not configured yet. Add SMTP details in Settings first." }, { status: 400 });
    }

    const transport = buildTransport(settings);

    if (body.action === "test") {
      const to = String(body.to || user?.email || settings.fromEmail);
      await transport.sendMail({
        from: `"${settings.fromName}" <${settings.fromEmail}>`,
        to,
        subject: "Luxury Attractions — SMTP test",
        text: "Your SMTP settings are working. Quotations and trip packages can now be emailed from the system.",
      });
      return Response.json({ ok: true, message: `Test email sent to ${to}.` });
    }

    const to = String(body.to || "").trim();
    const subject = String(body.subject || "").trim();
    const message = String(body.message || "").trim();
    if (!to || !subject) return Response.json({ error: "Recipient and subject are required." }, { status: 400 });

    const attachments: { filename: string; content: Buffer; contentType: string }[] = [];
    if (body.pdfBase64 && body.fileName) {
      const base64 = String(body.pdfBase64).replace(/^data:application\/pdf;base64,/, "");
      attachments.push({
        filename: String(body.fileName),
        content: Buffer.from(base64, "base64"),
        contentType: "application/pdf",
      });
    }

    const html = `<div style="font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:14px;color:#1e293b;line-height:1.6">
      ${message.split("\n").map((line) => `<p style="margin:0 0 10px">${line || "&nbsp;"}</p>`).join("")}
      <hr style="border:none;border-top:1px solid #e2e8f0;margin:18px 0" />
      <p style="margin:0;font-size:12px;color:#64748b"><b style="color:#174e48">Luxury Attractions</b><br/>hotels.luxuryattractions.com</p>
    </div>`;

    await transport.sendMail({
      from: `"${settings.fromName}" <${settings.fromEmail}>`,
      to,
      cc: String(body.cc || "") || undefined,
      bcc: settings.bccSelf ? settings.fromEmail : undefined,
      replyTo: settings.replyTo || undefined,
      subject,
      text: message,
      html,
      attachments,
    });

    return Response.json({ ok: true, message: `Email sent to ${to}.` });
  } catch (err) {
    const detail = err instanceof Error ? err.message : "Unknown error";
    return Response.json({ error: `Email failed: ${detail}` }, { status: 502 });
  }
}
