import { db } from "@/db";
import {
  amenities,
  blackoutDates,
  bookingItems,
  bookings,
  services,
  tripPackageItems,
  tripPackages,
  tours,
  hotelAmenities,
  hotelContacts,
  hotelContactAssignments,
  hotelGroups,
  hotels,
  locations,
  markets,
  occupancyRules,
  quotationItems,
  quotations,
  ratePeriods,
  roomBedding,
  roomCategories,
  roomTypes,
} from "@/db/schema";
import { asc, desc, sql } from "drizzle-orm";
import { addDays, evaluateAvailability, EngineBooking, MARKETS, ROOM_CATEGORIES } from "./search-engine";
import { ensureContactAssignments } from "./contact-data";
import { ensureSampleQuotations } from "./quotation-data";
import { ensureSampleTripPackage, ensureTripCatalog } from "./trip-data";

type RoomSeed = { name: string; code: string; category: string; factor: number; inventory: number };

type HotelSeed = {
  name: string;
  city: string;
  address: string;
  stars: 3 | 4 | 5;
  code: string;
  email: string;
  phone: string;
  checkIn: string;
  checkOut: string;
  tax: number;
  summer: number;
  winter: number;
  breakfastPerRoom?: boolean;
  website: string;
  contractsFolderLink?: string;
  mediaLink?: string;
  group?: string;
  businessType?: string;
  contacts: { name: string; position: string; email: string; phone: string; businessCardLink?: string; whatsapp?: boolean; telegram?: boolean; viber?: boolean }[];
  amenitySlugs: string[];
  rooms: RoomSeed[];
};

const AMENITY_SEEDS = [
  { slug: "swimming_pool", label: "Swimming pool", icon: "waves", sortOrder: 10 },
  { slug: "beach", label: "Beach", icon: "umbrella", sortOrder: 20 },
  { slug: "gym", label: "Gym", icon: "dumbbell", sortOrder: 30 },
  { slug: "metro", label: "Metro nearby", icon: "train", sortOrder: 40 },
];

const threeStarRooms = (king = "Deluxe King Room", kingInventory = 10): RoomSeed[] => [
  { name: king, code: "DLX-KING", category: "deluxe_king", factor: 1, inventory: kingInventory },
  { name: "Triple Room", code: "TRIPLE", category: "triple", factor: 1.18, inventory: 6 },
  { name: "Family Room", code: "FAMILY", category: "family", factor: 1.4, inventory: 4 },
];

const fourStarRooms = (king = "Deluxe King Room"): RoomSeed[] => [
  { name: king, code: "DLX-KING", category: "deluxe_king", factor: 1, inventory: 8 },
  { name: "Triple Room", code: "TRIPLE", category: "triple", factor: 1.15, inventory: 5 },
  { name: "Junior Suite", code: "JR-SUITE", category: "suite", factor: 1.7, inventory: 3 },
];

const fiveStarRooms = (king: string, top: RoomSeed = { name: "One Bedroom Suite", code: "ONE-SUITE", category: "suite", factor: 2, inventory: 3 }): RoomSeed[] => [
  { name: king, code: "DLX-KING", category: "deluxe_king", factor: 1, inventory: 6 },
  top,
];

const POOL_GYM = ["swimming_pool", "gym"];
const CITY_FULL = ["swimming_pool", "gym", "metro"];
const BEACH_RESORT = ["swimming_pool", "beach", "gym"];

const DRIVE = "https://drive.google.com/drive/folders/luxury-attractions-contracts";
const card = (name: string) => `${DRIVE}/business-cards/${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;

/** Compact contact builder: name, position, email, phone, plus messaging flags and a card link. */
const c = (name: string, position: string, email: string, phone: string, flags: { whatsapp?: boolean; telegram?: boolean; viber?: boolean } = {}) => ({
  name,
  position,
  email,
  phone,
  businessCardLink: card(name),
  whatsapp: flags.whatsapp ?? true,
  telegram: flags.telegram ?? false,
  viber: flags.viber ?? false,
});

const HOTEL_SEEDS: HotelSeed[] = [
  { name: "Al Khoory Executive Hotel", city: "Dubai", address: "Al Barsha 1, Dubai", stars: 4, code: "AKE-DXB", email: "sales@alkhoory.example", phone: "+971 4 321 7777", checkIn: "14:00", checkOut: "12:00", tax: 15, summer: 165, winter: 330, group: "Al Khoory Hotels", website: "https://alkhooryhotels.com", contractsFolderLink: DRIVE, amenitySlugs: CITY_FULL, contacts: [c("Rania Haddad", "Director of Sales & Marketing", "rania@alkhoory.example", "+971504421180", { whatsapp: true, telegram: true }), c("Omar Farouk", "Cluster Revenue Manager", "omar@alkhoory.example", "+971504421181")], rooms: fourStarRooms("Deluxe King Room") },
  { name: "Al Khoory Sky Garden Hotel", city: "Dubai", address: "Al Barsha South, Dubai", stars: 4, code: "AKS-DXB", email: "skygarden@alkhoory.example", phone: "+971 4 321 8888", checkIn: "14:00", checkOut: "12:00", tax: 15, summer: 155, winter: 315, group: "Al Khoory Hotels", website: "https://alkhooryhotels.com", contractsFolderLink: DRIVE, amenitySlugs: CITY_FULL, contacts: [c("Rania Haddad", "Director of Sales & Marketing", "rania@alkhoory.example", "+971504421180", { whatsapp: true, telegram: true })], rooms: fourStarRooms("Deluxe King Room") },
  { name: "Rove Downtown", city: "Dubai", address: "Al Mustaqbal Street, Downtown Dubai", stars: 3, code: "RDT-DXB", email: "groups@rove.example", phone: "+971 4 561 9000", checkIn: "15:00", checkOut: "12:00", tax: 10, summer: 135, winter: 265, website: "https://rovehotels.com", contractsFolderLink: DRIVE, amenitySlugs: CITY_FULL, contacts: [c("Farah Cadinouche", "Assistant Director of Sales", "farah.cadinouche@rove.example", "+971509340811"), c("Ali Ibrahim", "Cluster Reservation Manager", "ali.ibrahim@rove.example", "+971546474491", { whatsapp: true, viber: true })], rooms: threeStarRooms() },
  { name: "Citymax Hotel Al Barsha", city: "Dubai", address: "Al Barsha 1, near Mall of the Emirates", stars: 3, code: "CMB-DXB", email: "sales@citymax.example", phone: "+971 4 409 8000", checkIn: "14:00", checkOut: "12:00", tax: 10, summer: 110, winter: 210, breakfastPerRoom: true, website: "https://citymaxhotels.com", contractsFolderLink: DRIVE, amenitySlugs: CITY_FULL, contacts: [c("Samer Khalil", "Group Commercial Director", "samer.khalil@citymax.example", "+971576474493")], rooms: threeStarRooms("Standard King Room") },
  { name: "Premier Inn Dubai Silicon Oasis", city: "Dubai", address: "Dubai Silicon Oasis", stars: 3, code: "PIS-DXB", email: "b2b@premierinn.example", phone: "+971 4 372 2222", checkIn: "14:00", checkOut: "12:00", tax: 10, summer: 105, winter: 190, website: "https://premierinn.com", contractsFolderLink: DRIVE, amenitySlugs: POOL_GYM, contacts: [c("Shady Shohdy Shawky", "Director of Sales & Marketing", "dos@premierinn.example", "+971516090243", { whatsapp: true })], rooms: threeStarRooms("Deluxe King Room") },
  { name: "Hampton by Hilton Marjan Island", city: "Ras Al Khaimah", address: "Marjan Island Boulevard", stars: 3, code: "HMI-RAK", email: "reservations@hampton.example", phone: "+971 7 204 7000", checkIn: "15:00", checkOut: "12:00", tax: 10, summer: 125, winter: 235, website: "https://hilton.com", contractsFolderLink: DRIVE, amenitySlugs: BEACH_RESORT, contacts: [c("Laila Alaoui", "Sales Manager", "laila@hampton.example", "+971550841732", { whatsapp: true, telegram: true })], rooms: threeStarRooms("King Room Sea View", 3) },
  { name: "Novotel Dubai Al Barsha", city: "Dubai", address: "Sheikh Zayed Road, Al Barsha", stars: 4, code: "NAB-DXB", email: "contracts@novotel.example", phone: "+971 4 304 9000", checkIn: "14:00", checkOut: "12:00", tax: 15, summer: 175, winter: 360, website: "https://all.accor.com", contractsFolderLink: DRIVE, amenitySlugs: CITY_FULL, contacts: [c("Tamer Askander", "Sales Manager", "tamer.askander@novotel.example", "+971526032186", { whatsapp: true }), c("Irish Malaya", "Sales Coordinator", "irish.malaya@novotel.example", "+971566406308")], rooms: fourStarRooms("Superior King Room") },
  { name: "Holiday Inn Abu Dhabi Downtown", city: "Abu Dhabi", address: "Hamdan Bin Mohammed Street", stars: 4, code: "HID-AUH", email: "sales@holidayinn.example", phone: "+971 2 657 4888", checkIn: "15:00", checkOut: "12:00", tax: 15, summer: 150, winter: 285, website: "https://ihg.com", contractsFolderLink: DRIVE, amenitySlugs: POOL_GYM, contacts: [c("Hadi Abbas Jalbani", "Director of Sales & Marketing", "hadi.jalbani@holidayinn.example", "+971506322880", { whatsapp: true })], rooms: fourStarRooms() },
  { name: "Address Sky View", city: "Dubai", address: "Sheikh Mohammed bin Rashid Boulevard", stars: 5, code: "ASV-DXB", email: "reservations@address.example", phone: "+971 4 873 8888", checkIn: "15:00", checkOut: "12:00", tax: 20, summer: 690, winter: 1250, group: "Emaar Hospitality", website: "https://addresshotels.com", contractsFolderLink: DRIVE, amenitySlugs: CITY_FULL, contacts: [c("Alina Dolcos", "Director of Sales", "alina.dolcos@address.example", "+971515107899", { whatsapp: true, telegram: true })], rooms: fiveStarRooms("Deluxe King Burj View") },
  { name: "Jumeirah Beach Hotel", city: "Dubai", address: "Jumeirah Beach Road, Umm Suqeim", stars: 5, code: "JBH-DXB", email: "contracts@jumeirah.example", phone: "+971 4 348 0000", checkIn: "15:00", checkOut: "12:00", tax: 20, summer: 780, winter: 1450, group: "Jumeirah Group", website: "https://jumeirah.com", contractsFolderLink: DRIVE, amenitySlugs: BEACH_RESORT, contacts: [c("Mohamed Ali Ibrahim", "Cluster Revenue & Reservation Manager", "contracts@jumeirah.example", "+971564744916"), c("Anwar Kudlill Abdul Khader", "Sales & Revenue Manager", "anwar@jumeirah.example", "+971506440947", { whatsapp: true })], rooms: fiveStarRooms("Deluxe King Sea View") },
  { name: "Rixos Premium Saadiyat", city: "Abu Dhabi", address: "Saadiyat Island", stars: 5, code: "RPS-AUH", email: "sales@rixos.example", phone: "+971 2 492 2222", checkIn: "15:00", checkOut: "12:00", tax: 20, summer: 720, winter: 1180, website: "https://rixos.com", contractsFolderLink: DRIVE, amenitySlugs: BEACH_RESORT, contacts: [c("Anwar Siddique", "Assistant Director of Sales", "anwar.siddique@rixos.example", "+971561155848", { whatsapp: true, viber: true })], rooms: fiveStarRooms("Deluxe King Room") },
  { name: "Atlantis The Royal", city: "Dubai", address: "Crescent Road, Palm Jumeirah", stars: 5, code: "ATR-DXB", email: "trade@atlantis.example", phone: "+971 4 426 3000", checkIn: "15:00", checkOut: "11:00", tax: 20, summer: 1650, winter: 2900, group: "Kerzner International", website: "https://atlantis.com", contractsFolderLink: DRIVE, amenitySlugs: BEACH_RESORT, contacts: [c("Sarah Cadınouche", "Senior Sales Manager", "trade@atlantis.example", "+971502228844", { whatsapp: true })], rooms: fiveStarRooms("Royal Deluxe King") },
  { name: "The Ritz-Carlton Al Wadi Desert", city: "Ras Al Khaimah", address: "Al Mazraa, Ras Al Khaimah", stars: 5, code: "RCW-RAK", email: "wholesale@ritzcarlton.example", phone: "+971 7 206 7777", checkIn: "15:00", checkOut: "12:00", tax: 20, summer: 1150, winter: 1900, group: "Marriott International", website: "https://marriott.com", contractsFolderLink: DRIVE, amenitySlugs: POOL_GYM, contacts: [c("Irene Odhiambo", "Travel Manager", "irene@ritzcarlton.example", "+254719333334", { whatsapp: true, telegram: true })], rooms: fiveStarRooms("Deluxe King Tented Room", { name: "Al Khaimah Pool Villa", code: "POOL-VILLA", category: "villa", factor: 2.2, inventory: 4 }) },
  { name: "Anantara Qasr Al Sarab", city: "Abu Dhabi", address: "Liwa Desert, Qasr Al Sarab Road", stars: 5, code: "QAS-AUH", email: "partners@anantara.example", phone: "+971 2 886 2088", checkIn: "15:00", checkOut: "12:00", tax: 20, summer: 890, winter: 1350, website: "https://anantara.com", contractsFolderLink: DRIVE, amenitySlugs: POOL_GYM, contacts: [c("Hadi Jalbani", "Commercial Director", "partners@anantara.example", "+971506322880")], rooms: fiveStarRooms("Deluxe Garden King") },
];

const OCCUPANCY_BY_CATEGORY: Record<string, { limits: [number, number, number]; baseSleeps: number; rules: [number, number, number, number, string][] }> = {
  deluxe_king: { limits: [3, 2, 1], baseSleeps: 2, rules: [[1, 0, 0, 0, "Single use"], [2, 0, 0, 0, "Double"], [1, 2, 0, 0, "1 adult + 2 children"], [2, 1, 1, 0, "2 adults + 1 child + 1 infant"], [3, 0, 0, 1, "3 adults (extra bed)"]] },
  deluxe_twin: { limits: [3, 2, 1], baseSleeps: 2, rules: [[1, 0, 0, 0, "Single use"], [2, 0, 0, 0, "Twin"], [1, 2, 0, 0, "1 adult + 2 children"], [2, 1, 1, 0, "2 adults + 1 child + 1 infant"], [3, 0, 0, 1, "3 adults (extra bed)"]] },
  standard: { limits: [3, 2, 1], baseSleeps: 2, rules: [[1, 0, 0, 0, "Single use"], [2, 0, 0, 0, "Double"], [1, 2, 0, 0, "1 adult + 2 children"], [3, 0, 0, 1, "3 adults (extra bed)"]] },
  triple: { limits: [3, 2, 1], baseSleeps: 3, rules: [[1, 0, 0, 0, "Single use"], [2, 0, 0, 0, "Double"], [3, 0, 0, 0, "Triple (3 adults)"], [2, 1, 0, 0, "2 adults + 1 child"], [1, 2, 0, 0, "1 adult + 2 children"], [3, 1, 1, 0, "3 adults + 1 child + 1 infant"]] },
  family: { limits: [3, 3, 1], baseSleeps: 4, rules: [[2, 2, 1, 0, "2 adults + 2 children + 1 infant"], [3, 1, 1, 0, "3 adults + 1 child"], [2, 3, 0, 1, "2 adults + 3 children (extra bed)"]] },
  suite: { limits: [3, 2, 2], baseSleeps: 3, rules: [[2, 2, 2, 0, "2 adults + 2 children"], [3, 0, 1, 0, "3 adults"], [3, 1, 1, 1, "3 adults + 1 child (extra bed)"]] },
  villa: { limits: [4, 2, 2], baseSleeps: 4, rules: [[4, 0, 1, 0, "4 adults"], [2, 2, 2, 0, "2 adults + 2 children"], [3, 2, 1, 1, "3 adults + 2 children (extra bed)"]] },
};

/** Extra bedding offered by each room category: how many, and what it costs (baby cot is usually free). */
const BEDDING_BY_CATEGORY: Record<string, { kind: string; label: string; maxPerRoom: number; free: boolean; ratePerNight: number; perStay: boolean }[]> = {
  deluxe_king: [
    { kind: "extra_bed", label: "Extra bed", maxPerRoom: 1, free: false, ratePerNight: 60, perStay: false },
    { kind: "baby_cot", label: "Baby cot", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false },
  ],
  deluxe_twin: [
    { kind: "extra_bed", label: "Extra bed", maxPerRoom: 1, free: false, ratePerNight: 60, perStay: false },
    { kind: "baby_cot", label: "Baby cot", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false },
  ],
  standard: [{ kind: "baby_cot", label: "Baby cot", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false }],
  triple: [{ kind: "baby_cot", label: "Baby cot", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false }],
  family: [
    { kind: "sofa_bed", label: "Sofa bed", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false },
    { kind: "baby_cot", label: "Baby cot", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false },
  ],
  suite: [
    { kind: "sofa_bed", label: "Sofa bed", maxPerRoom: 1, free: false, ratePerNight: 120, perStay: false },
    { kind: "baby_cot", label: "Baby cot", maxPerRoom: 1, free: true, ratePerNight: 0, perStay: false },
  ],
  villa: [
    { kind: "extra_bed", label: "Extra bed", maxPerRoom: 2, free: false, ratePerNight: 190, perStay: false },
    { kind: "baby_cot", label: "Baby cot", maxPerRoom: 2, free: true, ratePerNight: 0, perStay: false },
  ],
};

const STAR_TERMS = {
  3: { hb: 60, fb: 0, extraAdult: 75, extraChild: 0, extraBed: 60 },
  4: { hb: 105, fb: 175, extraAdult: 140, extraChild: 0, extraBed: 110 },
  5: { hb: 195, fb: 340, extraAdult: 280, extraChild: 95, extraBed: 190 },
} as const;

const roundTo5 = (value: number) => Math.round(value / 5) * 5;

export async function seedHotelData() {
  const existing = await db.select({ id: hotels.id }).from(hotels).limit(1);
  if (existing.length > 0) return;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(771204)`);
    const again = await tx.select({ id: hotels.id }).from(hotels).limit(1);
    if (again.length > 0) return;

    const today = new Date().toISOString().slice(0, 10);
    const year = Number(today.slice(0, 4));
    const seasons = [
      { label: `Winter ${year}`, from: `${year}-01-01`, to: `${year}-04-30`, key: "winter" as const },
      { label: `Summer ${year}`, from: `${year}-05-01`, to: `${year}-09-30`, key: "summer" as const },
      { label: `Winter ${year}/${String(year + 1).slice(2)}`, from: `${year}-10-01`, to: `${year + 1}-04-30`, key: "winter" as const },
      { label: `Summer ${year + 1}`, from: `${year + 1}-05-01`, to: `${year + 1}-09-30`, key: "summer" as const },
      { label: `Winter ${year + 1}`, from: `${year + 1}-10-01`, to: `${year + 1}-12-31`, key: "winter" as const },
    ];

    await tx.insert(markets).values(
      [...MARKETS, { value: "drc_nationals", label: "DRC Nationals" }].map((market, index) => ({
        slug: market.value,
        label: market.label,
        sortOrder: (index + 1) * 10,
      })),
    );

    const locationSeeds: { city: string; name: string }[] = [
      { city: "Dubai", name: "Deira" },
      { city: "Dubai", name: "Downtown Dubai" },
      { city: "Dubai", name: "Al Barsha" },
      { city: "Dubai", name: "Palm Jumeirah" },
      { city: "Dubai", name: "Jumeirah" },
      { city: "Dubai", name: "Dubai Silicon Oasis" },
      { city: "Abu Dhabi", name: "Saadiyat Island" },
      { city: "Abu Dhabi", name: "Corniche" },
      { city: "Abu Dhabi", name: "Liwa Desert" },
      { city: "Ras Al Khaimah", name: "Marjan Island" },
      { city: "Ras Al Khaimah", name: "Al Wadi Desert" },
    ];
    const locationRows = await tx.insert(locations).values(locationSeeds).returning();
    const locationByKey = new Map(locationRows.map((row) => [`${row.city}:${row.name}`, row.id]));
    const HOTEL_LOCATIONS: Record<string, string> = {
      "AKE-DXB": "Al Barsha",
      "AKS-DXB": "Al Barsha",
      "RDT-DXB": "Downtown Dubai",
      "CMB-DXB": "Al Barsha",
      "PIS-DXB": "Dubai Silicon Oasis",
      "HMI-RAK": "Marjan Island",
      "NAB-DXB": "Al Barsha",
      "HID-AUH": "Corniche",
      "ASV-DXB": "Downtown Dubai",
      "JBH-DXB": "Jumeirah",
      "RPS-AUH": "Saadiyat Island",
      "ATR-DXB": "Palm Jumeirah",
      "RCW-RAK": "Al Wadi Desert",
      "QAS-AUH": "Liwa Desert",
    };

    const groupRows = await tx
      .insert(hotelGroups)
      .values(
        Array.from(new Set(HOTEL_SEEDS.map((seed) => seed.group).filter((name): name is string => Boolean(name)))).map((name) => ({
          name,
          website: `https://www.${name.toLowerCase().replace(/[^a-z0-9]+/g, "")}.example`,
          notes: "One sales team covers all properties in this group.",
        })),
      )
      .returning();
    const groupByName = new Map(groupRows.map((group) => [group.name, group]));

    const hotelRows = await tx
      .insert(hotels)
      .values(
        HOTEL_SEEDS.map((seed) => ({
          name: seed.name,
          city: seed.city,
          locationId: locationByKey.get(`${seed.city}:${HOTEL_LOCATIONS[seed.code] ?? ""}`) ?? null,
          address: seed.address,
          starRating: seed.stars,
          supplierCode: seed.code,
          groupId: seed.group ? groupByName.get(seed.group)!.id : null,
          businessType: seed.businessType ?? "Hotel",
          website: seed.website,
          contractsFolderLink: seed.contractsFolderLink ?? "",
          mediaLink: seed.mediaLink ?? `${DRIVE}/media/${seed.code.toLowerCase()}`,
          contactEmail: seed.email,
          contactPhone: seed.phone,
          checkInTime: seed.checkIn,
          checkOutTime: seed.checkOut,
          tourismTax: String(seed.tax),
          tourismTaxBasis: "room_night",
        })),
      )
      .returning();
    const hotelByCode = new Map(hotelRows.map((hotel) => [hotel.supplierCode, hotel]));

    await tx.insert(hotelContacts).values(
      HOTEL_SEEDS.flatMap((seed) =>
        seed.contacts.map((contact) => ({
          hotelId: hotelByCode.get(seed.code)!.id,
          name: contact.name,
          position: contact.position,
          email: contact.email,
          phone: contact.phone,
          businessCardLink: contact.businessCardLink ?? "",
          whatsapp: contact.whatsapp ?? false,
          telegram: contact.telegram ?? false,
          viber: contact.viber ?? false,
          otherContact: "",
        })),
      ),
    );

    const amenityRows = await tx.insert(amenities).values(AMENITY_SEEDS).returning();
    const amenityBySlug = new Map(amenityRows.map((amenity) => [amenity.slug, amenity]));
    await tx.insert(hotelAmenities).values(
      HOTEL_SEEDS.flatMap((seed) =>
        seed.amenitySlugs
          .map((slug) => amenityBySlug.get(slug))
          .filter((amenity): amenity is (typeof amenityRows)[number] => Boolean(amenity))
          .map((amenity) => ({ hotelId: hotelByCode.get(seed.code)!.id, amenityId: amenity.id })),
      ),
    );

    const roomRows = await tx
      .insert(roomTypes)
      .values(
        HOTEL_SEEDS.flatMap((seed) =>
          seed.rooms.map((room) => {
            const occupancy = OCCUPANCY_BY_CATEGORY[room.category];
            return {
              hotelId: hotelByCode.get(seed.code)!.id,
              name: room.name,
              code: room.code,
              category: room.category,
              description: `${room.name} at ${seed.name}.`,
              maxAdults: occupancy.limits[0],
              maxChildren: occupancy.limits[1],
              maxInfants: occupancy.limits[2],
              includedAdults: 2,
              baseSleeps: occupancy.baseSleeps,
              defaultInventory: room.inventory,
              extraBedAllowed: (BEDDING_BY_CATEGORY[room.category] ?? []).some((item) => item.kind === "extra_bed"),
              mediaLink: `${DRIVE}/rooms/${seed.code.toLowerCase()}-${room.code.toLowerCase()}`,
            };
          }),
        ),
      )
      .returning();
    const roomByKey = new Map(roomRows.map((room) => [`${room.hotelId}:${room.code}`, room]));

    await tx.insert(roomCategories).values(
      ROOM_CATEGORIES.map((category, index) => ({ slug: category.value, label: category.label, sortOrder: (index + 1) * 10 })),
    );

    const beddingRows = await tx
      .insert(roomBedding)
      .values(
        roomRows.flatMap((room) =>
          (BEDDING_BY_CATEGORY[room.category] ?? []).map((option, index) => ({
            roomTypeId: room.id,
            kind: option.kind,
            label: option.label,
            maxPerRoom: option.maxPerRoom,
            free: option.free,
            ratePerNight: String(option.ratePerNight),
            perStay: option.perStay,
            sortOrder: (index + 1) * 10,
          })),
        ),
      )
      .returning();

    const occupancyRows = await tx
      .insert(occupancyRules)
      .values(
        roomRows.flatMap((room) =>
          OCCUPANCY_BY_CATEGORY[room.category].rules.map(([adults, children, infants, extraBeds, label]) => ({
            roomTypeId: room.id,
            adults,
            children,
            infants,
            extraBeds,
            label,
          })),
        ),
      )
      .returning();

    const rateValues: (typeof ratePeriods.$inferInsert)[] = [];
    for (const seed of HOTEL_SEEDS) {
      const hotel = hotelByCode.get(seed.code)!;
      const terms = STAR_TERMS[seed.stars];
      for (const roomSeed of seed.rooms) {
        const room = roomByKey.get(`${hotel.id}:${roomSeed.code}`)!;
        const periods = seasons.map((season) => ({ ...season, bb: roundTo5(seed[season.key] * roomSeed.factor), minimumNights: 1 }));
        if (seed.stars >= 4) {
          periods.push({ label: `Festive Peak ${year}/${String(year + 1).slice(2)}`, from: `${year}-12-27`, to: `${year + 1}-01-03`, key: "winter", bb: roundTo5(seed.winter * roomSeed.factor * 1.5), minimumNights: 3 });
        }
        for (const period of periods) {
          const common = {
            hotelId: hotel.id,
            roomTypeId: room.id,
            validFrom: period.from,
            validTo: period.to,
            rateBasis: "room_night",
            extraAdultRate: String(terms.extraAdult),
            extraChildRate: String(terms.extraChild),
            extraBedRate: String(terms.extraBed),
            extraBedBasis: "bed_night",
            minimumNights: period.minimumNights,
          };
          const roomOnly = roundTo5(period.bb * 0.88);
          rateValues.push({ ...common, name: `${period.label} RO`, boardType: "room_only", baseRate: String(roomOnly) });
          rateValues.push(
            seed.breakfastPerRoom
              ? { ...common, name: `${period.label} BB`, boardType: "breakfast", baseRate: String(roomOnly), boardAdultSupplement: "45", boardSupplementBasis: "room_night" }
              : { ...common, name: `${period.label} BB`, boardType: "breakfast", baseRate: String(period.bb) },
          );
          rateValues.push({ ...common, name: `${period.label} HB`, boardType: "half_board", baseRate: String(period.bb), boardAdultSupplement: String(terms.hb), boardChildSupplement: String(terms.hb / 2), boardSupplementBasis: "person_night" });
          if (terms.fb) {
            rateValues.push({ ...common, name: `${period.label} FB`, boardType: "full_board", baseRate: String(period.bb), boardAdultSupplement: String(terms.fb), boardChildSupplement: String(terms.fb / 2), boardSupplementBasis: "person_night" });
          }
        }

        // Promo flash sale: bookable now for the next 10 days, staying within 60 days, all markets except UAE.
        const promoBase = roundTo5(seed.summer * roomSeed.factor * 0.8);
        rateValues.push({
          hotelId: hotel.id,
          roomTypeId: room.id,
          name: "Ramadan Flash Sale",
          boardType: "breakfast",
          validFrom: today,
          validTo: addDays(today, 60),
          bookingWindowStart: today,
          bookingWindowEnd: addDays(today, 10),
          market: "all",
          marketExclusions: "uae",
          promoCode: "RAMADAN-FLASH-4",
          baseRate: String(promoBase),
          rateBasis: "room_night",
          extraAdultRate: String(terms.extraAdult),
          extraChildRate: String(terms.extraChild),
          extraBedRate: String(terms.extraBed),
          extraBedBasis: "bed_night",
          minimumNights: 1,
        });
      }
    }
    const rateRows = await tx.insert(ratePeriods).values(rateValues).returning();

    const roomOf = (code: string, roomCode: string) => roomByKey.get(`${hotelByCode.get(code)!.id}:${roomCode}`)!;
    const blackoutValues = [
      { hotelId: hotelByCode.get("RDT-DXB")!.id, roomTypeId: roomOf("RDT-DXB", "DLX-KING").id, startDate: addDays(today, 13), endDate: addDays(today, 16), reason: "Hotel fully booked – conference group" },
      { hotelId: hotelByCode.get("ATR-DXB")!.id, roomTypeId: null, startDate: addDays(today, 10), endDate: addDays(today, 20), reason: "Stop sale – hotel sold out" },
      { hotelId: hotelByCode.get("CMB-DXB")!.id, roomTypeId: roomOf("CMB-DXB", "FAMILY").id, startDate: addDays(today, 30), endDate: addDays(today, 33), reason: "Allocation released back to hotel" },
      { hotelId: hotelByCode.get("RPS-AUH")!.id, roomTypeId: roomOf("RPS-AUH", "ONE-SUITE").id, startDate: `${year}-12-29`, endDate: `${year + 1}-01-02`, reason: "New Year – suites fully booked" },
    ];
    const blackoutRows = await tx.insert(blackoutDates).values(blackoutValues).returning();

    const contextHotels = hotelRows.map((hotel) => ({
      ...hotel,
      location: locationRows.find((row) => row.id === hotel.locationId)?.name ?? "",
      amenities: HOTEL_SEEDS.find((seed) => seed.code === hotel.supplierCode)?.amenitySlugs ?? [],
    }));
    const context = { hotels: contextHotels, rooms: roomRows, occupancies: occupancyRows, bedding: beddingRows, rates: rateRows, blackouts: blackoutRows, bookings: [] as EngineBooking[] };
    const sampleBookings = [
      { code: "HMI-RAK", room: "DLX-KING", board: "breakfast", offset: 12, nights: 6, adults: 4, children: 0, rooms: 2, guest: "Mehmet Yilmaz", status: "confirmed" },
      { code: "PIS-DXB", room: "DLX-KING", board: "breakfast", offset: 3, nights: 3, adults: 2, children: 0, rooms: 1, guest: "Olivia Martin", status: "confirmed" },
      { code: "NAB-DXB", room: "DLX-KING", board: "half_board", offset: 5, nights: 4, adults: 2, children: 1, rooms: 1, guest: "Nabil Rahman", status: "confirmed" },
      { code: "JBH-DXB", room: "ONE-SUITE", board: "half_board", offset: 21, nights: 5, adults: 2, children: 2, rooms: 1, guest: "Sophia Turner", status: "confirmed" },
      { code: "ASV-DXB", room: "DLX-KING", board: "breakfast", offset: 8, nights: 2, adults: 2, children: 0, rooms: 1, guest: "James Wilson", status: "pending" },
      { code: "HID-AUH", room: "TRIPLE", board: "room_only", offset: 16, nights: 3, adults: 3, children: 0, rooms: 1, guest: "Maya Kapoor", status: "confirmed" },
      { code: "RCW-RAK", room: "POOL-VILLA", board: "full_board", offset: 40, nights: 3, adults: 2, children: 2, rooms: 1, guest: "Luca Bianchi", status: "confirmed" },
      { code: "CMB-DXB", room: "FAMILY", board: "breakfast", offset: 26, nights: 4, adults: 2, children: 2, rooms: 1, guest: "Amira Haddad", status: "confirmed" },
    ];

    let sequence = 1048;
    for (const sample of sampleBookings) {
      const hotel = hotelByCode.get(sample.code)!;
      const room = roomOf(sample.code, sample.room);
      const checkIn = addDays(today, sample.offset);
      const checkOut = addDays(checkIn, sample.nights);
      const availability = evaluateAvailability(context, {
        checkIn,
        checkOut,
        adults: sample.adults,
        children: sample.children,
        infants: 0,
        rooms: sample.rooms,
        extraBeds: 0,
        sofaBeds: 0,
        babyCots: 0,
        category: "any",
        market: "all",
        bookingDate: today,
        hotelId: hotel.id,
        roomTypeId: room.id,
      });
      const offer = availability.results[0]?.offers.find((item) => item.boardType === sample.board);
      if (!offer) continue;
      const [b] = await tx
        .insert(bookings)
        .values({
          reference: `LAH-${String(sequence).padStart(5, "0")}`,
          hotelId: hotel.id,
          roomTypeId: room.id,
          ratePeriodId: offer.primaryRatePeriodId,
          boardType: sample.board,
          guestName: sample.guest,
          guestEmail: `${sample.guest.split(" ")[0].toLowerCase()}@example.com`,
          guestPhone: "+971 50 000 0000",
          checkIn,
          checkOut,
          adults: sample.adults,
          children: sample.children,
          infants: 0,
          rooms: sample.rooms,
          extraBeds: offer.extraBeds,
          sofaBeds: offer.sofaBeds,
          babyCots: offer.babyCots,
          nights: offer.nights,
          baseAmount: String(offer.baseAmount),
          boardAmount: String(offer.boardAmount),
          occupancyAmount: String(offer.occupancyAmount),
          extraBedAmount: String(offer.extraBedAmount),
          tourismTaxAmount: String(offer.tourismTaxAmount),
          totalAmount: String(offer.totalAmount),
          currency: "AED",
          status: sample.status,
        })
        .returning();

      await tx.insert(bookingItems).values({
        bookingId: b.id,
        sortOrder: 0,
        hotelId: hotel.id,
        roomTypeId: room.id,
        ratePeriodId: offer.primaryRatePeriodId,
        boardType: sample.board,
        checkIn,
        checkOut,
        nights: offer.nights,
        adults: sample.adults,
        children: sample.children,
        infants: 0,
        rooms: sample.rooms,
        extraBeds: offer.extraBeds,
        sofaBeds: offer.sofaBeds,
        babyCots: offer.babyCots,
        baseAmount: String(offer.baseAmount),
        boardAmount: String(offer.boardAmount),
        occupancyAmount: String(offer.occupancyAmount),
        extraBedAmount: String(offer.extraBedAmount),
        tourismTaxAmount: String(offer.tourismTaxAmount),
        totalAmount: String(offer.totalAmount),
        rateNames: offer.rateNames.join(", "),
        promoCodes: offer.promoCodes.join(", "),
        notes: "Contract booking segment",
      });

      context.bookings.push({ roomTypeId: room.id, checkIn, checkOut, rooms: sample.rooms, status: sample.status });
      sequence += 1;
    }

    // Seed sample multi-stay quotation (2 nights Al Khoory Executive + 2 nights Al Khoory Sky Garden)
    const execHotel = hotelByCode.get("AKE-DXB")!;
    const skyHotel = hotelByCode.get("AKS-DXB")!;
    const execRoom = roomOf("AKE-DXB", "DLX-KING");
    const skyRoom = roomOf("AKS-DXB", "DLX-KING");

    const stay1In = addDays(today, 18);
    const stay1Out = addDays(stay1In, 2);
    const stay2In = stay1Out;
    const stay2Out = addDays(stay2In, 2);

    const q1Avail = evaluateAvailability(context, {
      checkIn: stay1In,
      checkOut: stay1Out,
      adults: 2,
      children: 0,
      infants: 0,
      rooms: 1,
      extraBeds: 0,
      sofaBeds: 0,
      babyCots: 0,
      category: "any",
      market: "all",
      bookingDate: today,
      hotelId: execHotel.id,
      roomTypeId: execRoom.id,
    });
    const q1Offer = q1Avail.results[0]?.offers.find((o) => o.boardType === "breakfast") || q1Avail.results[0]?.best;

    const q2Avail = evaluateAvailability(context, {
      checkIn: stay2In,
      checkOut: stay2Out,
      adults: 2,
      children: 0,
      infants: 0,
      rooms: 1,
      extraBeds: 0,
      sofaBeds: 0,
      babyCots: 0,
      category: "any",
      market: "all",
      bookingDate: today,
      hotelId: skyHotel.id,
      roomTypeId: skyRoom.id,
    });
    const q2Offer = q2Avail.results[0]?.offers.find((o) => o.boardType === "breakfast") || q2Avail.results[0]?.best;

    if (q1Offer && q2Offer) {
      const qTotal = (Number(q1Offer.totalAmount) + Number(q2Offer.totalAmount)).toFixed(2);
      const qBase = (Number(q1Offer.baseAmount) + Number(q2Offer.baseAmount)).toFixed(2);
      const qTax = (Number(q1Offer.tourismTaxAmount) + Number(q2Offer.tourismTaxAmount)).toFixed(2);

      const [sampleQuote] = await tx
        .insert(quotations)
        .values({
          reference: "LAQ-10024",
          title: "Al Khoory Twin Stay Itinerary (Executive + Sky Garden)",
          clientName: "David Henderson",
          clientEmail: "david.henderson@travelcorp.example",
          clientPhone: "+44 20 7946 0912",
          clientCompany: "Apex Global Travel UK",
          market: "uk",
          status: "sent",
          validUntil: addDays(today, 14),
          totalNights: 4,
          totalGuests: "2 Adults",
          baseAmount: qBase,
          boardAmount: "0.00",
          occupancyAmount: "0.00",
          extraBedAmount: "0.00",
          tourismTaxAmount: qTax,
          totalAmount: qTotal,
          currency: "AED",
          notes: "Combined 4-night itinerary: 2 nights in Al Barsha at Executive Hotel followed by 2 nights at Sky Garden.",
        })
        .returning();

      await tx.insert(quotationItems).values([
        {
          quotationId: sampleQuote.id,
          sortOrder: 0,
          hotelId: execHotel.id,
          roomTypeId: execRoom.id,
          ratePeriodId: q1Offer.primaryRatePeriodId,
          boardType: q1Offer.boardType,
          checkIn: stay1In,
          checkOut: stay1Out,
          nights: 2,
          adults: 2,
          children: 0,
          infants: 0,
          rooms: 1,
          baseAmount: String(q1Offer.baseAmount),
          boardAmount: String(q1Offer.boardAmount),
          occupancyAmount: String(q1Offer.occupancyAmount),
          extraBedAmount: String(q1Offer.extraBedAmount),
          tourismTaxAmount: String(q1Offer.tourismTaxAmount),
          totalAmount: String(q1Offer.totalAmount),
          rateNames: q1Offer.rateNames.join(", "),
          promoCodes: q1Offer.promoCodes.join(", "),
          notes: "Stay 1 - Al Khoory Executive",
        },
        {
          quotationId: sampleQuote.id,
          sortOrder: 1,
          hotelId: skyHotel.id,
          roomTypeId: skyRoom.id,
          ratePeriodId: q2Offer.primaryRatePeriodId,
          boardType: q2Offer.boardType,
          checkIn: stay2In,
          checkOut: stay2Out,
          nights: 2,
          adults: 2,
          children: 0,
          infants: 0,
          rooms: 1,
          baseAmount: String(q2Offer.baseAmount),
          boardAmount: String(q2Offer.boardAmount),
          occupancyAmount: String(q2Offer.occupancyAmount),
          extraBedAmount: String(q2Offer.extraBedAmount),
          tourismTaxAmount: String(q2Offer.tourismTaxAmount),
          totalAmount: String(q2Offer.totalAmount),
          rateNames: q2Offer.rateNames.join(", "),
          promoCodes: q2Offer.promoCodes.join(", "),
          notes: "Stay 2 - Al Khoory Sky Garden",
        },
      ]);
    }
  });
}

export async function getHotelDashboardData() {
  await seedHotelData();
  await ensureContactAssignments();
  await ensureSampleQuotations();
  await ensureTripCatalog();
  await ensureSampleTripPackage();

  const [
    hotelList,
    marketList,
    locationList,
    groupList,
    contactList,
    contactAssignmentList,
    amenityList,
    hotelAmenityList,
    categoryList,
    roomList,
    beddingList,
    occupancyList,
    rateList,
    blackoutList,
    bookingList,
    bookingItemList,
    quotationList,
    quotationItemList,
    serviceList,
    tourList,
    tripPackageList,
    tripPackageItemList,
  ] = await Promise.all([
    db.select().from(hotels).orderBy(asc(hotels.name)),
    db.select().from(markets).orderBy(asc(markets.sortOrder), asc(markets.label)),
    db.select().from(locations).orderBy(asc(locations.city), asc(locations.name)),
    db.select().from(hotelGroups).orderBy(asc(hotelGroups.name)),
    db.select().from(hotelContacts).orderBy(asc(hotelContacts.name), asc(hotelContacts.id)),
    db.select().from(hotelContactAssignments).orderBy(asc(hotelContactAssignments.hotelId), asc(hotelContactAssignments.contactId)),
    db.select().from(amenities).orderBy(asc(amenities.sortOrder), asc(amenities.label)),
    db.select().from(hotelAmenities).orderBy(asc(hotelAmenities.hotelId)),
    db.select().from(roomCategories).orderBy(asc(roomCategories.sortOrder), asc(roomCategories.label)),
    db.select().from(roomTypes).orderBy(asc(roomTypes.hotelId), asc(roomTypes.name)),
    db.select().from(roomBedding).orderBy(asc(roomBedding.sortOrder)),
    db.select().from(occupancyRules).orderBy(asc(occupancyRules.roomTypeId), asc(occupancyRules.adults)),
    db.select().from(ratePeriods).orderBy(asc(ratePeriods.hotelId), asc(ratePeriods.roomTypeId), asc(ratePeriods.validFrom)),
    db.select().from(blackoutDates).orderBy(asc(blackoutDates.startDate)),
    db.select().from(bookings).orderBy(desc(bookings.createdAt), desc(bookings.id)),
    db.select().from(bookingItems).orderBy(asc(bookingItems.sortOrder), asc(bookingItems.id)),
    db.select().from(quotations).orderBy(desc(quotations.createdAt), desc(quotations.id)),
    db.select().from(quotationItems).orderBy(asc(quotationItems.sortOrder), asc(quotationItems.id)),
    db.select().from(services).orderBy(asc(services.name)),
    db.select().from(tours).orderBy(asc(tours.name)),
    db.select().from(tripPackages).orderBy(desc(tripPackages.createdAt)),
    db.select().from(tripPackageItems).orderBy(asc(tripPackageItems.sortOrder), asc(tripPackageItems.id)),
  ]);

  return {
    hotels: hotelList,
    markets: marketList,
    locations: locationList,
    hotelGroups: groupList,
    contacts: contactList,
    contactAssignments: contactAssignmentList,
    amenities: amenityList,
    hotelAmenities: hotelAmenityList,
    roomCategories: categoryList,
    rooms: roomList,
    bedding: beddingList,
    occupancies: occupancyList,
    rates: rateList,
    blackouts: blackoutList,
    bookings: bookingList,
    bookingItems: bookingItemList,
    quotations: quotationList,
    quotationItems: quotationItemList,
    services: serviceList,
    tours: tourList,
    tripPackages: tripPackageList,
    tripPackageItems: tripPackageItemList,
  };
}
