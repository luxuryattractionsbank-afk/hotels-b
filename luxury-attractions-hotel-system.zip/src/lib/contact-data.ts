import { db } from "@/db";
import { hotelContactAssignments, hotelContacts } from "@/db/schema";
import { isNotNull, sql } from "drizzle-orm";

/**
 * Migrate the previous one-contact-one-hotel records without discarding any details.
 * Clearing hotelId after linking is important: removing a hotel assignment must not
 * cause the legacy record to get re-attached on the next page load.
 */
export async function ensureContactAssignments() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(921450)`);
    const legacy = await tx
      .select({ id: hotelContacts.id, hotelId: hotelContacts.hotelId })
      .from(hotelContacts)
      .where(isNotNull(hotelContacts.hotelId));

    if (legacy.length === 0) return;
    await tx
      .insert(hotelContactAssignments)
      .values(legacy.filter((row): row is { id: number; hotelId: number } => row.hotelId !== null).map((row) => ({
        contactId: row.id,
        hotelId: row.hotelId,
      })))
      .onConflictDoNothing({ target: [hotelContactAssignments.hotelId, hotelContactAssignments.contactId] });
    await tx.update(hotelContacts).set({ hotelId: null }).where(isNotNull(hotelContacts.hotelId));
  });
}

export type ContactInput = {
  name: string;
  position: string;
  email: string;
  phone: string;
  businessCardLink: string;
  whatsapp: boolean;
  telegram: boolean;
  viber: boolean;
  otherContact: string;
};

export function readContact(value: unknown): ContactInput {
  const raw = value && typeof value === "object" ? (value as Record<string, unknown>) : {};
  return {
    name: String(raw.name ?? "").trim().slice(0, 160),
    position: String(raw.position ?? "").trim().slice(0, 160),
    email: String(raw.email ?? "").trim().slice(0, 240),
    phone: String(raw.phone ?? "").trim().slice(0, 64),
    businessCardLink: String(raw.businessCardLink ?? "").trim().slice(0, 1000),
    whatsapp: raw.whatsapp === true,
    telegram: raw.telegram === true,
    viber: raw.viber === true,
    otherContact: String(raw.otherContact ?? "").trim().slice(0, 300),
  };
}

export function parseContactIds(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  const ids = value.map(Number);
  if (!ids.every((id) => Number.isSafeInteger(id) && id > 0)) return null;
  return [...new Set(ids)];
}
