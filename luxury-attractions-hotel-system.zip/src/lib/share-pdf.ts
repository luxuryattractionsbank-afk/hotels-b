import type { jsPDF } from "jspdf";

export type ShareOutcome = "shared" | "downloaded" | "cancelled";

type NavigatorWithShare = Navigator & {
  canShare?: (data: { files?: File[] }) => boolean;
  share?: (data: { files?: File[]; title?: string; text?: string }) => Promise<void>;
};

export function pdfToFile(pdf: jsPDF, fileName: string): File {
  const blob = pdf.output("blob");
  return new File([blob], fileName, { type: "application/pdf" });
}

export function downloadPdf(pdf: jsPDF, fileName: string) {
  const url = URL.createObjectURL(pdf.output("blob"));
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/**
 * Shares the real PDF file through the device share sheet (WhatsApp, Telegram, Mail…).
 * Falls back to downloading the file when the browser cannot share files.
 */
export async function sharePdfFile(pdf: jsPDF, fileName: string, title: string, text: string): Promise<ShareOutcome> {
  const file = pdfToFile(pdf, fileName);
  const nav = navigator as NavigatorWithShare;

  if (typeof nav.share === "function" && typeof nav.canShare === "function" && nav.canShare({ files: [file] })) {
    try {
      await nav.share({ files: [file], title, text });
      return "shared";
    } catch (error) {
      // User dismissed the native sheet — do not fall through to a download.
      if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
    }
  }

  downloadPdf(pdf, fileName);
  return "downloaded";
}

/** Opens WhatsApp / Telegram with the caption ready; the PDF is attached from the downloaded file. */
export function openMessenger(app: "whatsapp" | "telegram", text: string, phone?: string) {
  const encoded = encodeURIComponent(text);
  const digits = (phone || "").replace(/\D/g, "");
  const url =
    app === "whatsapp"
      ? digits
        ? `https://wa.me/${digits}?text=${encoded}`
        : `https://wa.me/?text=${encoded}`
      : `https://t.me/share/url?url=${encodeURIComponent("hotels.luxuryattractions.com")}&text=${encoded}`;
  window.open(url, "_blank", "noopener,noreferrer");
}

export const canShareFiles = () => {
  if (typeof navigator === "undefined") return false;
  const nav = navigator as NavigatorWithShare;
  if (typeof nav.share !== "function" || typeof nav.canShare !== "function") return false;
  try {
    return nav.canShare({ files: [new File([new Blob(["x"], { type: "application/pdf" })], "t.pdf", { type: "application/pdf" })] });
  } catch {
    return false;
  }
};
