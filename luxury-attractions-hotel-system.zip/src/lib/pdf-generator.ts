import { jsPDF } from "jspdf";

/* ------------------------------------------------------------------ *
 * Vector PDF builder (no HTML rasterising) — small, sharp, shareable. *
 * ------------------------------------------------------------------ */

const BRAND: [number, number, number] = [23, 78, 72];
const GOLD: [number, number, number] = [178, 122, 75];
const SLATE: [number, number, number] = [71, 85, 105];
const LIGHT: [number, number, number] = [148, 163, 184];
const BORDER: [number, number, number] = [226, 232, 240];
const BG: [number, number, number] = [248, 250, 252];

const PAGE_W = 210;
const MARGIN = 14;
const CONTENT_W = PAGE_W - MARGIN * 2;

const money = (value: number | string, currency = "AED") =>
  `${currency} ${Number(value || 0).toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtDate = (date?: string | null) => {
  if (!date) return "—";
  const parsed = new Date(`${String(date).slice(0, 10)}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return "—";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(parsed);
};

const titleCase = (value: string) => value.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

type Doc = { pdf: jsPDF; y: number };

function newPageIfNeeded(doc: Doc, needed: number) {
  if (doc.y + needed > 280) {
    doc.pdf.addPage();
    doc.y = MARGIN + 4;
  }
}

function header(doc: Doc, subtitle: string, reference: string, issued: string) {
  const { pdf } = doc;
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(15);
  pdf.setTextColor(...BRAND);
  pdf.text("LUXURY ATTRACTIONS", MARGIN, doc.y);

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(7.5);
  pdf.setTextColor(...GOLD);
  pdf.text("HOTEL CONTRACTS  ·  hotels.luxuryattractions.com", MARGIN, doc.y + 4.6);

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(9);
  pdf.setTextColor(...BRAND);
  pdf.text(reference, PAGE_W - MARGIN, doc.y, { align: "right" });
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(...LIGHT);
  pdf.text(`Issued: ${fmtDate(issued)}`, PAGE_W - MARGIN, doc.y + 4.6, { align: "right" });

  doc.y += 9;
  pdf.setDrawColor(...BRAND);
  pdf.setLineWidth(0.8);
  pdf.line(MARGIN, doc.y, PAGE_W - MARGIN, doc.y);

  doc.y += 7;
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(13);
  pdf.setTextColor(15, 23, 42);
  pdf.text(subtitle, MARGIN, doc.y);
  doc.y += 7;
}

function infoBlock(doc: Doc, rows: [string, string][]) {
  const { pdf } = doc;
  const colW = CONTENT_W / 2;
  let row = 0;
  for (let i = 0; i < rows.length; i += 2) {
    const y = doc.y + row * 5.6;
    for (let col = 0; col < 2; col += 1) {
      const entry = rows[i + col];
      if (!entry) continue;
      const x = MARGIN + col * colW;
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(8);
      pdf.setTextColor(...LIGHT);
      pdf.text(entry[0], x, y);
      pdf.setFont("helvetica", "bold");
      pdf.setTextColor(...SLATE);
      pdf.text(pdf.splitTextToSize(entry[1] || "—", colW - 34)[0] ?? "—", x + colW - 4, y, { align: "right" });
    }
    row += 1;
  }
  doc.y += row * 5.6 + 3;
}

function sectionTitle(doc: Doc, text: string) {
  newPageIfNeeded(doc, 14);
  const { pdf } = doc;
  pdf.setFillColor(...BRAND);
  pdf.rect(MARGIN, doc.y - 3.4, 1.4, 5, "F");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(10);
  pdf.setTextColor(...BRAND);
  pdf.text(text.toUpperCase(), MARGIN + 4, doc.y);
  doc.y += 6;
}

function tableHeader(doc: Doc, cols: { label: string; w: number; align?: "left" | "right" | "center" }[]) {
  const { pdf } = doc;
  pdf.setFillColor(...BRAND);
  pdf.rect(MARGIN, doc.y, CONTENT_W, 7, "F");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(7.5);
  pdf.setTextColor(255, 255, 255);
  let x = MARGIN;
  for (const col of cols) {
    const tx = col.align === "right" ? x + col.w - 2 : col.align === "center" ? x + col.w / 2 : x + 2;
    pdf.text(col.label, tx, doc.y + 4.7, { align: col.align ?? "left" });
    x += col.w;
  }
  doc.y += 7;
}

function tableRow(doc: Doc, cols: { w: number; align?: "left" | "right" | "center" }[], cells: string[][]) {
  const lineH = 3.8;
  const rowH = Math.max(...cells.map((lines) => lines.length)) * lineH + 3;
  newPageIfNeeded(doc, rowH + 4);

  const { pdf } = doc;
  pdf.setDrawColor(...BORDER);
  pdf.setLineWidth(0.15);
  pdf.rect(MARGIN, doc.y, CONTENT_W, rowH);

  let x = MARGIN;
  cells.forEach((lines, index) => {
    const col = cols[index];
    lines.forEach((line, lineIndex) => {
      const isFirst = lineIndex === 0;
      pdf.setFont("helvetica", isFirst ? "bold" : "normal");
      pdf.setFontSize(isFirst ? 8 : 7);
      pdf.setTextColor(...(isFirst ? [30, 41, 59] : LIGHT) as [number, number, number]);
      const tx = col.align === "right" ? x + col.w - 2 : col.align === "center" ? x + col.w / 2 : x + 2;
      pdf.text(line, tx, doc.y + 4.4 + lineIndex * lineH, { align: col.align ?? "left" });
    });
    x += col.w;
  });
  doc.y += rowH;
}

function summaryBox(doc: Doc, rows: [string, string][], totalLabel: string, totalValue: string, footNote?: string) {
  const boxH = Math.ceil(rows.length / 2) * 5.4 + 20 + (footNote ? 5 : 0);
  newPageIfNeeded(doc, boxH + 6);
  const { pdf } = doc;

  doc.y += 4;
  pdf.setFillColor(...BG);
  pdf.setDrawColor(...BORDER);
  pdf.roundedRect(MARGIN, doc.y, CONTENT_W, boxH, 2, 2, "FD");

  const colW = CONTENT_W / 2;
  let line = 0;
  for (let i = 0; i < rows.length; i += 2) {
    const y = doc.y + 6 + line * 5.4;
    for (let col = 0; col < 2; col += 1) {
      const entry = rows[i + col];
      if (!entry) continue;
      const x = MARGIN + 4 + col * colW;
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(8);
      pdf.setTextColor(...SLATE);
      pdf.text(entry[0], x, y);
      pdf.setFont("helvetica", "bold");
      pdf.setTextColor(30, 41, 59);
      pdf.text(entry[1], x + colW - 8, y, { align: "right" });
    }
    line += 1;
  }

  const barY = doc.y + 8 + line * 5.4;
  pdf.setFillColor(...BRAND);
  pdf.roundedRect(MARGIN + 3, barY, CONTENT_W - 6, 10, 1.5, 1.5, "F");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(8.5);
  pdf.setTextColor(255, 255, 255);
  pdf.text(totalLabel.toUpperCase(), MARGIN + 7, barY + 6.4);
  pdf.setFontSize(11.5);
  pdf.text(totalValue, PAGE_W - MARGIN - 7, barY + 6.8, { align: "right" });

  if (footNote) {
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(7.2);
    pdf.setTextColor(180, 83, 9);
    pdf.text(footNote, MARGIN + 4, barY + 15.5);
  }

  doc.y += boxH + 5;
}

function notesBlock(doc: Doc, title: string, body: string) {
  if (!body) return;
  const { pdf } = doc;
  const lines = pdf.splitTextToSize(body, CONTENT_W - 4);
  newPageIfNeeded(doc, lines.length * 4 + 10);
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(8);
  pdf.setTextColor(...BRAND);
  pdf.text(title.toUpperCase(), MARGIN, doc.y);
  doc.y += 4.5;
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(...SLATE);
  pdf.text(lines, MARGIN, doc.y);
  doc.y += lines.length * 4 + 4;
}

function footer(pdf: jsPDF, note: string, reference: string) {
  const pages = pdf.getNumberOfPages();
  for (let page = 1; page <= pages; page += 1) {
    pdf.setPage(page);
    pdf.setDrawColor(...BORDER);
    pdf.setLineWidth(0.2);
    pdf.line(MARGIN, 286, PAGE_W - MARGIN, 286);
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(6.8);
    pdf.setTextColor(...LIGHT);
    pdf.text(note, MARGIN, 290);
    pdf.text(`${reference}  ·  Page ${page} of ${pages}`, PAGE_W - MARGIN, 290, { align: "right" });
  }
}

/* ------------------------------ types ------------------------------ */

export type PdfStay = {
  id: number;
  hotelName: string;
  location: string;
  roomName: string;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  /** Client-facing amount for this stay (markup already blended in). */
  quotedAmount: number;
};

export type PdfQuotation = {
  reference: string;
  title: string;
  clientName: string;
  clientCompany: string;
  clientEmail: string;
  clientPhone: string;
  validUntil: string | null;
  notes: string;
  status: string;
  totalNights: number;
  tourismTaxAmount: number;
  includeTax: boolean;
  quotedTotal: number;
  currency: string;
  createdAt: string;
};

export type PdfTripItem = {
  id: number;
  kind: string;
  name: string;
  priceType: string;
  serviceDate: string | null;
  serviceTime: string;
  pickup: string;
  dropoff: string;
  persons: number;
  vehicles: number;
  details: string;
  /** Client-facing amount for this line (markup already blended in). */
  quotedAmount: number;
};

export type PdfTripPackage = {
  reference: string;
  title: string;
  clientName: string;
  clientCompany: string;
  clientEmail: string;
  clientPhone: string;
  status: string;
  startDate: string | null;
  endDate: string | null;
  includesHotels: boolean;
  includeTax: boolean;
  tourismTaxAmount: number;
  hotelQuotedTotal: number;
  extrasQuotedTotal: number;
  quotedTotal: number;
  currency: string;
  notes: string;
  createdAt: string;
};

const priceTypeLabel = (kind: string, priceType: string) => {
  if (kind === "tour") {
    const map: Record<string, string> = { ticket_only: "Ticket only", shared: "Tour + shared transfer", private: "Tour + private transfer" };
    return map[priceType] ?? titleCase(priceType);
  }
  const map: Record<string, string> = {
    shared_one_way: "Shared transfer - one way",
    shared_two_way: "Shared transfer - two way (return)",
    private_one_way: "Private vehicle - one way",
    private_two_way: "Private vehicle - two way (return)",
  };
  return map[priceType] ?? titleCase(priceType);
};

/* --------------------------- quotation PDF -------------------------- */

export function buildQuotationPdf(quote: PdfQuotation, stays: PdfStay[]): jsPDF {
  const pdf = new jsPDF({ unit: "mm", format: "a4" });
  const doc: Doc = { pdf, y: MARGIN + 4 };

  header(doc, "Hotel Stay Proposal", quote.reference, quote.createdAt);

  const nights = Math.max(1, quote.totalNights || 1);
  const totalRooms = stays.reduce((sum, stay) => sum + (stay.rooms || 1), 0) || 1;
  const dailyTax = (quote.tourismTaxAmount || 0) / nights;

  infoBlock(doc, [
    ["Client", quote.clientName],
    ["Company / Partner", quote.clientCompany],
    ["Email", quote.clientEmail],
    ["Phone / WhatsApp", quote.clientPhone],
    ["Valid until", quote.validUntil ? fmtDate(quote.validUntil) : "—"],
    ["Total nights", `${nights} nights`],
  ]);

  sectionTitle(doc, "Hotel stays");
  const cols = [
    { label: "Hotel", w: 52, align: "left" as const },
    { label: "Room / Board", w: 45, align: "left" as const },
    { label: "Dates", w: 36, align: "left" as const },
    { label: "Nts", w: 10, align: "center" as const },
    { label: "Guests", w: 24, align: "left" as const },
    { label: "Rate", w: 15, align: "right" as const },
  ];
  tableHeader(doc, cols);
  for (const stay of stays) {
    tableRow(doc, cols, [
      [stay.hotelName, stay.location].filter(Boolean),
      [stay.roomName, titleCase(stay.boardType)],
      [fmtDate(stay.checkIn), `to ${fmtDate(stay.checkOut)}`],
      [String(stay.nights)],
      [`${stay.adults}A ${stay.children}C ${stay.infants}I`, `${stay.rooms} room(s)`],
      [money(stay.quotedAmount, "").trim()],
    ]);
  }

  const avgDaily = stays.reduce((sum, stay) => sum + stay.quotedAmount, 0) / nights / totalRooms;
  summaryBox(
    doc,
    [
      ["Total nights", `${nights} nights`],
      ["Average daily rate", `${money(avgDaily, quote.currency)} / room / night`],
      ["Tourism tax", quote.includeTax ? `Included (${money(quote.tourismTaxAmount, quote.currency)})` : `Excluded (${money(dailyTax, quote.currency)} / night)`],
      ["Currency", quote.currency || "AED"],
    ],
    `Total proposal cost ${quote.includeTax ? "(incl. tourism tax)" : "(excl. tourism tax)"}`,
    money(quote.quotedTotal, quote.currency),
    quote.includeTax ? undefined : `* Excludes daily tourism tax: ${money(dailyTax, quote.currency)} per night - payable directly to the hotel at check-in.`,
  );

  notesBlock(doc, "Terms & notes", quote.notes);
  footer(pdf, "Rates quoted by Luxury Attractions. Subject to availability at time of confirmation.", quote.reference);
  return pdf;
}

/* ------------------------- trip package PDF ------------------------- */

export function buildTripPackagePdf(pkg: PdfTripPackage, stays: PdfStay[], items: PdfTripItem[]): jsPDF {
  const pdf = new jsPDF({ unit: "mm", format: "a4" });
  const doc: Doc = { pdf, y: MARGIN + 4 };

  header(doc, `Trip Package - ${pkg.title}`, pkg.reference, pkg.createdAt);

  infoBlock(doc, [
    ["Client", pkg.clientName],
    ["Company / Partner", pkg.clientCompany],
    ["Email", pkg.clientEmail],
    ["Phone / WhatsApp", pkg.clientPhone],
    ["Package dates", `${fmtDate(pkg.startDate)} to ${fmtDate(pkg.endDate)}`],
    ["Status", titleCase(pkg.status)],
  ]);

  if (pkg.includesHotels && stays.length > 0) {
    sectionTitle(doc, "Part 1 · Hotels stay");
    const cols = [
      { label: "Hotel", w: 52, align: "left" as const },
      { label: "Room / Board", w: 55, align: "left" as const },
      { label: "Dates", w: 40, align: "left" as const },
      { label: "Nts", w: 10, align: "center" as const },
      { label: "Rate", w: 25, align: "right" as const },
    ];
    tableHeader(doc, cols);
    for (const stay of stays) {
      tableRow(doc, cols, [
        [stay.hotelName, stay.location].filter(Boolean),
        [stay.roomName, `${titleCase(stay.boardType)} · ${stay.adults}A ${stay.children}C ${stay.infants}I · ${stay.rooms} room(s)`],
        [fmtDate(stay.checkIn), `to ${fmtDate(stay.checkOut)}`],
        [String(stay.nights)],
        [money(stay.quotedAmount, "").trim()],
      ]);
    }
    doc.y += 3;
  }

  sectionTitle(doc, "Part 2 · Tours, tickets & transfers itinerary");
  if (items.length === 0) {
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8);
    pdf.setTextColor(...LIGHT);
    pdf.text("No tours, tickets or transfers added yet.", MARGIN, doc.y);
    doc.y += 6;
  } else {
    for (const item of items) {
      const isPrivate = item.kind === "service" && (item.priceType.startsWith("private") || item.priceType === "per_vehicle");
      const qty = isPrivate ? Math.max(1, item.vehicles) : Math.max(1, item.persons);
      const detailLines = item.details ? pdf.splitTextToSize(item.details, CONTENT_W - 50) : [];
      const blockH = 17 + (item.pickup || item.dropoff ? 4.5 : 0) + detailLines.length * 3.4;
      newPageIfNeeded(doc, blockH + 4);

      pdf.setDrawColor(...BORDER);
      pdf.setLineWidth(0.2);
      pdf.roundedRect(MARGIN, doc.y, CONTENT_W, blockH, 1.5, 1.5, "S");

      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(8);
      pdf.setTextColor(30, 41, 59);
      pdf.text(`${fmtDate(item.serviceDate)}${item.serviceTime ? `  ·  ${item.serviceTime}` : ""}`, MARGIN + 3, doc.y + 5);

      pdf.setFontSize(9.5);
      pdf.setTextColor(...BRAND);
      pdf.text(pdf.splitTextToSize(item.name, CONTENT_W - 50)[0], MARGIN + 3, doc.y + 10);

      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(7.5);
      pdf.setTextColor(...SLATE);
      pdf.text(priceTypeLabel(item.kind, item.priceType), MARGIN + 3, doc.y + 14.5);

      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(9.5);
      pdf.setTextColor(30, 41, 59);
      pdf.text(money(item.quotedAmount, "").trim(), PAGE_W - MARGIN - 3, doc.y + 6.5, { align: "right" });
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(7);
      pdf.setTextColor(...LIGHT);
      pdf.text(`${isPrivate ? `${item.vehicles} vehicle(s)` : `${item.persons} pax`} x ${money(item.quotedAmount / qty, "").trim()}`, PAGE_W - MARGIN - 3, doc.y + 11, { align: "right" });

      let extraY = doc.y + 19;
      if (item.pickup || item.dropoff) {
        pdf.setFontSize(7);
        pdf.setTextColor(...SLATE);
        pdf.text(`Pick-up: ${item.pickup || "—"}`, MARGIN + 3, extraY);
        pdf.text(`Drop-off: ${item.dropoff || "—"}`, MARGIN + CONTENT_W / 2, extraY);
        extraY += 4;
      }
      if (detailLines.length) {
        pdf.setFontSize(6.8);
        pdf.setTextColor(...LIGHT);
        pdf.text(detailLines, MARGIN + 3, extraY);
      }
      doc.y += blockH + 2.5;
    }
  }

  const summaryRows: [string, string][] = [];
  if (pkg.includesHotels && stays.length > 0) summaryRows.push(["Hotels stay total", money(pkg.hotelQuotedTotal, pkg.currency)]);
  if (items.length > 0) summaryRows.push(["Tours, tickets & transfers", money(pkg.extrasQuotedTotal, pkg.currency)]);
  summaryRows.push(["Tourism tax", pkg.includeTax ? `Included (${money(pkg.tourismTaxAmount, pkg.currency)})` : `Excluded (${money(pkg.tourismTaxAmount, pkg.currency)})`]);
  summaryRows.push(["Currency", pkg.currency || "AED"]);

  summaryBox(
    doc,
    summaryRows,
    `Package total ${pkg.includeTax ? "(incl. tourism tax)" : "(excl. tourism tax)"}`,
    money(pkg.quotedTotal, pkg.currency),
    pkg.includeTax || !pkg.tourismTaxAmount ? undefined : `* Excludes tourism tax: ${money(pkg.tourismTaxAmount, pkg.currency)} - payable directly to the hotel at check-in.`,
  );

  notesBlock(doc, "Package notes", pkg.notes);
  footer(pdf, "All rates quoted by Luxury Attractions. Tours and tickets supplied as listed. Subject to availability.", pkg.reference);
  return pdf;
}

export const pdfFileName = (reference: string, title: string) =>
  `${reference}-${(title || "proposal").replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 48)}.pdf`.toLowerCase();
