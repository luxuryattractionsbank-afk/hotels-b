import { db } from "@/db";
import { amenities, blackoutDates, bookings, hotelAmenities, hotels, locations, occupancyRules, ratePeriods, roomBedding, roomTypes } from "@/db/schema";
import { and, eq, gt, gte, lt, lte, ne } from "drizzle-orm";
import {
  addDays,
  applyFilters,
  CoreCriteria,
  DEFAULT_FILTERS,
  evaluateAvailability,
  ResultFilters,
  SearchContext,
  validateCore,
} from "./search-engine";

export async function loadSearchContext(checkIn: string, checkOut: string): Promise<SearchContext> {
  const lastNight = addDays(checkOut, -1);
  const [hotelRows, amenityLinkRows, roomRows, beddingRows, occupancyRows, rateRows, blackoutRows, bookingRows] = await Promise.all([
    db
      .select({ hotel: hotels, locationName: locations.name })
      .from(hotels)
      .leftJoin(locations, eq(locations.id, hotels.locationId))
      .where(eq(hotels.active, true)),
    db
      .select({ hotelId: hotelAmenities.hotelId, slug: amenities.slug })
      .from(hotelAmenities)
      .innerJoin(amenities, eq(amenities.id, hotelAmenities.amenityId))
      .where(eq(amenities.active, true)),
    db.select().from(roomTypes).where(eq(roomTypes.active, true)),
    db.select().from(roomBedding),
    db.select().from(occupancyRules),
    db
      .select()
      .from(ratePeriods)
      .where(and(eq(ratePeriods.active, true), lte(ratePeriods.validFrom, lastNight), gte(ratePeriods.validTo, checkIn))),
    db
      .select()
      .from(blackoutDates)
      .where(and(lte(blackoutDates.startDate, lastNight), gte(blackoutDates.endDate, checkIn))),
    db
      .select({ roomTypeId: bookings.roomTypeId, checkIn: bookings.checkIn, checkOut: bookings.checkOut, rooms: bookings.rooms, status: bookings.status })
      .from(bookings)
      .where(and(ne(bookings.status, "cancelled"), lt(bookings.checkIn, checkOut), gt(bookings.checkOut, checkIn))),
  ]);

  const amenitiesByHotel = new Map<number, string[]>();
  for (const link of amenityLinkRows) {
    const current = amenitiesByHotel.get(link.hotelId) ?? [];
    current.push(link.slug);
    amenitiesByHotel.set(link.hotelId, current);
  }

  return {
    hotels: hotelRows.map((row) => ({ ...row.hotel, location: row.locationName ?? "", amenities: amenitiesByHotel.get(row.hotel.id) ?? [] })),
    rooms: roomRows,
    occupancies: occupancyRows,
    bedding: beddingRows,
    rates: rateRows,
    blackouts: blackoutRows,
    bookings: bookingRows,
  };
}

export async function searchAllHotels(criteria: CoreCriteria, filters: ResultFilters = DEFAULT_FILTERS) {
  const error = validateCore(criteria);
  if (error) {
    return { error, nights: 0, checkedHotels: 0, checkedRooms: 0, results: [], excluded: [], outsidePriceRange: 0 };
  }
  const context = await loadSearchContext(criteria.checkIn, criteria.checkOut);
  const availability = evaluateAvailability(context, criteria);
  const filtered = applyFilters(availability.results, filters);
  return { ...availability, results: filtered.results, outsidePriceRange: filtered.outsidePriceRange };
}
