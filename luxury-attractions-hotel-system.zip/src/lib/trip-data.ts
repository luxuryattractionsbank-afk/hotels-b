import { db } from "@/db";
import { quotationItems, quotations, services, tripPackageItems, tripPackages, tours } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { computeQuotationPricing } from "@/lib/quotation-pricing";

/** Seed the transfer service and tour/ticket catalogue once. */
export async function ensureTripCatalog() {
  const existing = await db.select({ id: services.id }).from(services).limit(1);
  if (existing.length > 0) return;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(914771)`);
    const again = await tx.select({ id: services.id }).from(services).limit(1);
    if (again.length > 0) return;

    await tx.insert(services).values([
      { name: "DXB Airport → Hotel (shared)", kind: "shared_transfer", vehicleType: "Shared shuttle", priceMode: "per_person", oneWayPrice: "95.00", twoWayPrice: "170.00", details: "Shared airport transfer, per person." },
      { name: "Hotel → DXB Airport (shared return)", kind: "shared_transfer", vehicleType: "Shared shuttle", priceMode: "per_person", oneWayPrice: "95.00", twoWayPrice: "170.00", details: "Return shared transfer included in two-way price." },
      { name: "Private transfer – 7 Seater", kind: "private_transfer", vehicleType: "7 Seater", priceMode: "per_vehicle", oneWayPrice: "500.00", twoWayPrice: "850.00", details: "Private vehicle, up to 6 guests + driver." },
      { name: "Private transfer – 12 Seater", kind: "private_transfer", vehicleType: "12 Seater", priceMode: "per_vehicle", oneWayPrice: "800.00", twoWayPrice: "1400.00", details: "Private vehicle, up to 11 guests + driver." },
      { name: "Limousine transfer – Private Sedan", kind: "private_transfer", vehicleType: "Sedan", priceMode: "per_vehicle", oneWayPrice: "650.00", twoWayPrice: "1150.00", details: "Premium sedan one way / return." },
    ]);

    await tx.insert(tours).values([
      { name: "Burj Khalifa – At The Top (124 + 148)", category: "ticket", ticketOnlyPrice: "545.00", sharedTransferPrice: "645.00", privateTransferPrice: "1050.00", details: "Entry ticket with optional shared or private transfer." },
      { name: "Dubai City Tour – Old & New", category: "tour", ticketOnlyPrice: "0.00", sharedTransferPrice: "175.00", privateTransferPrice: "620.00", details: "Half day guided tour; private rate is per vehicle." },
      { name: "Desert Safari with BBQ Dinner", category: "tour", ticketOnlyPrice: "190.00", sharedTransferPrice: "235.00", privateTransferPrice: "780.00", details: "Evening safari, dune bashing, dinner & live shows." },
      { name: "Museum of the Future", category: "ticket", ticketOnlyPrice: "169.00", sharedTransferPrice: "245.00", privateTransferPrice: "760.00", details: "Timed entry ticket with optional transfers." },
      { name: "Global Village Entry Ticket", category: "ticket", ticketOnlyPrice: "25.00", sharedTransferPrice: "115.00", privateTransferPrice: "560.00", details: "Entry ticket with optional transfers." },
    ]);
  });
}

/** One ready-made trip package so the section is immediately understandable. */
export async function ensureSampleTripPackage() {
  const existing = await db.select({ id: tripPackages.id }).from(tripPackages).limit(1);
  if (existing.length > 0) return;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(914772)`);
    const again = await tx.select({ id: tripPackages.id }).from(tripPackages).limit(1);
    if (again.length > 0) return;

    const [quote] = await tx.select().from(quotations).orderBy(quotations.id).limit(1);
    const [private7] = await tx.select().from(services).where(eq(services.vehicleType, "7 Seater")).limit(1);
    const [desert] = await tx.select().from(tours).where(eq(tours.category, "tour")).limit(1);
    const [burj] = await tx.select().from(tours).where(eq(tours.category, "ticket")).limit(1);
    if (!quote || !private7 || !desert || !burj) return;

    const hotelItems = await tx.select().from(quotationItems).where(eq(quotationItems.quotationId, quote.id));
    const hotelCost = Number(quote.hotelCostTotal) || 0;
    const tax = Number(quote.tourismTaxAmount) || 0;

    const start = hotelItems[0]?.checkIn ?? new Date().toISOString().slice(0, 10);
    const end = hotelItems[0]?.checkOut ?? start;

    // Airport arrival: private 7 seater, one way
    const arrivalTotal = Number(private7.oneWayPrice);
    // Desert safari, shared transfer, for the party
    const persons = hotelItems[0]?.adults ?? 2;
    const desertTotal = Number(desert.sharedTransferPrice) * persons;
    // Burj Khalifa tickets
    const burjTotal = Number(burj.ticketOnlyPrice) * persons;

    const extras = arrivalTotal + desertTotal + burjTotal;
    const pricing = computeQuotationPricing({
      hotelCostTotal: hotelCost + extras,
      tourismTaxAmount: tax,
      includeTax: quote.includeTax !== false,
      markupMode: quote.markupMode === "amount" ? "amount" : "percent",
      markupValue: Number(quote.markupValue) || 0,
      totalNights: quote.totalNights || 1,
      totalRooms: 1,
    });

    const [pkg] = await tx
      .insert(tripPackages)
      .values({
        reference: "TRP-10031",
        quotationId: quote.id,
        title: `${quote.title || "Dubai Stay"} + Tours & Transfers`,
        clientName: quote.clientName,
        clientEmail: quote.clientEmail,
        clientPhone: quote.clientPhone,
        clientCompany: quote.clientCompany,
        status: "draft",
        startDate: start,
        endDate: end,
        includesHotels: true,
        includeTax: pricing.includeTax,
        markupMode: pricing.markupMode,
        markupValue: String(pricing.markupValue),
        hotelCostTotal: hotelCost.toFixed(2),
        extrasCostTotal: extras.toFixed(2),
        tourismTaxAmount: tax.toFixed(2),
        markupAmount: String(pricing.markupAmount),
        quotedTotal: String(pricing.quotedTotal),
        totalAmount: String(pricing.quotedTotal),
        currency: quote.currency,
        notes: "Hotels stay carried from the linked quotation; tours and transfers billed as added services.",
      })
      .returning();

    await tx.insert(tripPackageItems).values([
      {
        packageId: pkg.id,
        sortOrder: 0,
        kind: "service",
        serviceId: private7.id,
        name: private7.name,
        priceType: "private_one_way",
        serviceDate: start,
        serviceTime: "14:30",
        pickup: "Dubai International Airport (DXB) – Terminal 3 arrivals",
        dropoff: `${quote.title || "Hotel"} – Dubai`,
        persons,
        vehicles: 1,
        unitPrice: private7.oneWayPrice,
        totalAmount: arrivalTotal.toFixed(2),
        details: "Meet & greet at arrivals, private 7 seater to the hotel.",
      },
      {
        packageId: pkg.id,
        sortOrder: 1,
        kind: "tour",
        tourId: desert.id,
        name: desert.name,
        priceType: "shared",
        serviceDate: start,
        serviceTime: "16:00",
        pickup: "Hotel lobby",
        dropoff: "Hotel lobby",
        persons,
        vehicles: 1,
        unitPrice: desert.sharedTransferPrice,
        totalAmount: desertTotal.toFixed(2),
        details: desert.details,
      },
      {
        packageId: pkg.id,
        sortOrder: 2,
        kind: "tour",
        tourId: burj.id,
        name: burj.name,
        priceType: "ticket_only",
        serviceDate: end,
        serviceTime: "17:45",
        pickup: "Own arrangement (ticket only)",
        dropoff: "—",
        persons,
        vehicles: 1,
        unitPrice: burj.ticketOnlyPrice,
        totalAmount: burjTotal.toFixed(2),
        details: burj.details,
      },
    ]);

    await tx
      .update(quotations)
      .set({ updatedAt: new Date() })
      .where(eq(quotations.id, quote.id));  });
}
