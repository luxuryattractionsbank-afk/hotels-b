import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, gt, sql } from "drizzle-orm";
import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { parsePermissions, ROLE_PRESETS, serialisePermissions, type SessionUser } from "./permissions";

const scrypt = promisify(scryptCallback) as (password: string, salt: string, keylen: number) => Promise<Buffer>;

export const SESSION_COOKIE = "la_session";
const SESSION_DAYS = 14;

/** scrypt with a random salt — no external dependency needed. */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [scheme, salt, hash] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const derived = await scrypt(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(derived, expected);
}

/** Creates the first administrator so the system is never locked out. */
export async function ensureSeedAdmin() {
  const [existing] = await db.select({ id: users.id }).from(users).limit(1);
  if (existing) return;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(553311)`);
    const [again] = await tx.select({ id: users.id }).from(users).limit(1);
    if (again) return;

    const email = (process.env.ADMIN_EMAIL || "admin@luxuryattractions.com").toLowerCase();
    const password = process.env.ADMIN_PASSWORD || "Admin@12345";
    await tx.insert(users).values({
      email,
      name: "System Administrator",
      passwordHash: await hashPassword(password),
      role: "admin",
      permissions: serialisePermissions([...ROLE_PRESETS.admin.permissions]),
      active: true,
      mustChangePassword: true,
    });

    // A reservations agent so permission differences are visible immediately.
    await tx.insert(users).values({
      email: "agent@luxuryattractions.com",
      name: "Reservations Agent",
      passwordHash: await hashPassword("Agent@12345"),
      role: "agent",
      permissions: serialisePermissions([...ROLE_PRESETS.agent.permissions]),
      active: true,
      mustChangePassword: false,
    });
  });
}

export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  return token;
}

export async function destroySession(token: string) {
  await db.delete(sessions).where(eq(sessions.token, token));
}

/** Reads the session cookie and returns the signed-in user, or null. */
export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (!token) return null;

    const [row] = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        permissions: users.permissions,
        active: users.active,
      })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);

    if (!row || !row.active) return null;
    return {
      id: row.id,
      name: row.name,
      email: row.email,
      role: row.role,
      permissions: parsePermissions(row.permissions),
    };
  } catch {
    return null;
  }
}

/** Guard for API routes: returns the user or a 401/403 Response. */
export async function requirePermission(permission: Parameters<typeof canUser>[1]) {
  const user = await getSessionUser();
  if (!user) return { user: null, error: Response.json({ error: "Please sign in to continue." }, { status: 401 }) };
  if (!canUser(user, permission)) {
    return { user, error: Response.json({ error: "You do not have permission to do that." }, { status: 403 }) };
  }
  return { user, error: null };
}

import { can as canUser } from "./permissions";
export { canUser };
