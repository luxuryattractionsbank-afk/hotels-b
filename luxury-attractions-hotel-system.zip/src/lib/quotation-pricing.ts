/**
 * Quotation pricing maths shared by the API, the search panel (save modal)
 * and the Quotations detail view, so the client-facing numbers always agree.
 *
 * The hotel rates are what the hotel charges us. We add our own markup and
 * optionally carry the daily tourism tax through to the client.
 */
export type MarkupMode = "percent" | "amount";

export type QuotationPricing = {
  includeTax: boolean;
  markupMode: MarkupMode;
  markupValue: number;
  hotelCostTotal: number; // what the hotel charges us (room + meals + occupancy + bedding), excl. tax
  markupAmount: number;
  tourismTaxAmount: number; // daily tourism tax total as charged by the hotel
  quotedTotal: number; // hotel cost + markup (+ tax when included)
  totalNights: number;
  totalRooms: number;
  dailyTax: number; // tourism tax per night (for the "excludes daily tourism tax" line)
  dailyRate: number; // client-facing daily rate after markup (per room / night)
};

const round2 = (value: number) => Math.round((Number(value) || 0) * 100) / 100;

export function computeQuotationPricing(input: {
  hotelCostTotal: number; // base + board + occupancy + extra bed (excl. tax)
  tourismTaxAmount: number;
  includeTax: boolean;
  markupMode: MarkupMode;
  markupValue: number;
  totalNights: number;
  totalRooms: number;
}): QuotationPricing {
  const hotelCostTotal = round2(input.hotelCostTotal);
  const tourismTaxAmount = round2(input.tourismTaxAmount);
  const value = Math.max(0, Number(input.markupValue) || 0);
  const markupAmount = round2(input.markupMode === "percent" ? (hotelCostTotal * value) / 100 : value);
  const quotedTotal = round2(hotelCostTotal + markupAmount + (input.includeTax ? tourismTaxAmount : 0));
  const nights = Math.max(1, Number(input.totalNights) || 1);
  const rooms = Math.max(1, Number(input.totalRooms) || 1);

  return {
    includeTax: input.includeTax,
    markupMode: input.markupMode === "amount" ? "amount" : "percent",
    markupValue: value,
    hotelCostTotal,
    markupAmount,
    tourismTaxAmount,
    quotedTotal,
    totalNights: nights,
    totalRooms: rooms,
    dailyTax: round2(tourismTaxAmount / nights),
    dailyRate: round2((hotelCostTotal + markupAmount) / nights / rooms),
  };
}

/** Reads the commercial fields from an API payload safely. */
export function readQuotationCommercial(body: Record<string, unknown>) {
  const rawMode = String(body.markupMode ?? "percent");
  return {
    includeTax: body.includeTax === undefined ? true : Boolean(body.includeTax),
    markupMode: (rawMode === "amount" ? "amount" : "percent") as MarkupMode,
    markupValue: Math.max(0, Number(body.markupValue) || 0),
  };
}
