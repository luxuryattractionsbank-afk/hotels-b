/** Permission keys used across the UI and the API routes. */
export const PERMISSIONS = [
  { key: "search", label: "Search & compare rates", group: "Daily work" },
  { key: "quotations", label: "Create & manage quotations", group: "Daily work" },
  { key: "trips", label: "Create & manage trip packages", group: "Daily work" },
  { key: "bookings", label: "Confirm & view bookings", group: "Daily work" },
  { key: "send_email", label: "Email proposals to clients", group: "Daily work" },
  { key: "hotels", label: "Manage hotels, contacts & groups", group: "Contracts" },
  { key: "rooms", label: "Manage room types & occupancy", group: "Contracts" },
  { key: "rates", label: "Manage rates, markets & promos", group: "Contracts" },
  { key: "blackouts", label: "Manage blackout dates", group: "Contracts" },
  { key: "catalog", label: "Manage services, tours & tickets", group: "Contracts" },
  { key: "view_cost", label: "See net hotel cost & markup", group: "Commercial" },
  { key: "users", label: "Manage users & permissions", group: "Administration" },
  { key: "settings", label: "Manage SMTP & system settings", group: "Administration" },
] as const;

export type PermissionKey = (typeof PERMISSIONS)[number]["key"];

export const ROLE_PRESETS: Record<string, { label: string; description: string; permissions: PermissionKey[] }> = {
  admin: {
    label: "Administrator",
    description: "Full access including users, settings and commercial margins.",
    permissions: PERMISSIONS.map((item) => item.key),
  },
  manager: {
    label: "Manager",
    description: "Runs contracts and sees cost & markup, but cannot manage users.",
    permissions: ["search", "quotations", "trips", "bookings", "send_email", "hotels", "rooms", "rates", "blackouts", "catalog", "view_cost"],
  },
  agent: {
    label: "Reservations agent",
    description: "Sells: search, quote, package and book. Net cost and markup stay hidden.",
    permissions: ["search", "quotations", "trips", "bookings", "send_email"],
  },
  viewer: {
    label: "Viewer",
    description: "Read-only access to search and existing proposals.",
    permissions: ["search"],
  },
};

export function parsePermissions(value: string): PermissionKey[] {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter((item): item is PermissionKey => PERMISSIONS.some((perm) => perm.key === item));
}

export function serialisePermissions(list: string[]): string {
  return Array.from(new Set(list.filter((item) => PERMISSIONS.some((perm) => perm.key === item)))).join(",");
}

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  role: string;
  permissions: PermissionKey[];
};

/** Admins implicitly hold every permission so a locked-out admin is impossible. */
export function can(user: SessionUser | null, permission: PermissionKey): boolean {
  if (!user) return false;
  if (user.role === "admin") return true;
  return user.permissions.includes(permission);
}
