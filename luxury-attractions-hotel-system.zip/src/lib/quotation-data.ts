import { db } from "@/db";
import { hotels, quotationItems, quotations, roomTypes } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function ensureSampleQuotations() {
  const existing = await db.select({ id: quotations.id }).from(quotations).limit(1);
  if (existing.length > 0) return;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(837219)`);
    const again = await tx.select({ id: quotations.id }).from(quotations).limit(1);
    if (again.length > 0) return;

    const [execHotel] = await tx.select().from(hotels).where(eq(hotels.supplierCode, "AKE-DXB")).limit(1);
    const [skyHotel] = await tx.select().from(hotels).where(eq(hotels.supplierCode, "AKS-DXB")).limit(1);
    if (!execHotel || !skyHotel) return;

    const [execRoom] = await tx.select().from(roomTypes).where(eq(roomTypes.hotelId, execHotel.id)).limit(1);
    const [skyRoom] = await tx.select().from(roomTypes).where(eq(roomTypes.hotelId, skyHotel.id)).limit(1);
    if (!execRoom || !skyRoom) return;

    const today = new Date().toISOString().slice(0, 10);
    const addD = (d: string, n: number) => {
      const dt = new Date(`${d}T00:00:00Z`);
      dt.setUTCDate(dt.getUTCDate() + n);
      return dt.toISOString().slice(0, 10);
    };

    const stay1In = addD(today, 14);
    const stay1Out = addD(stay1In, 2);
    const stay2In = stay1Out;
    const stay2Out = addD(stay2In, 2);

    // Multi-stay proposal: Al Khoory Executive + Al Khoory Sky Garden
    const [quote1] = await tx
      .insert(quotations)
      .values({
        reference: "LAQ-10024",
        title: "Al Khoory Twin Stay Itinerary (Executive + Sky Garden)",
        clientName: "David Henderson",
        clientEmail: "david.henderson@travelcorp.example",
        clientPhone: "+44 20 7946 0912",
        clientCompany: "Apex Global Travel UK",
        market: "uk",
        status: "sent",
        validUntil: addD(today, 14),
        totalNights: 4,
        totalGuests: "2 Adults",
        baseAmount: "645.00",
        boardAmount: "0.00",
        occupancyAmount: "0.00",
        extraBedAmount: "0.00",
        tourismTaxAmount: "60.00",
        totalAmount: "705.00",
        currency: "AED",
        notes: "Combined 4-night itinerary: 2 nights at Al Khoory Executive Hotel followed by 2 nights at Al Khoory Sky Garden Hotel.",
      })
      .returning();

    await tx.insert(quotationItems).values([
      {
        quotationId: quote1.id,
        sortOrder: 0,
        hotelId: execHotel.id,
        roomTypeId: execRoom.id,
        boardType: "breakfast",
        checkIn: stay1In,
        checkOut: stay1Out,
        nights: 2,
        adults: 2,
        children: 0,
        infants: 0,
        rooms: 1,
        baseAmount: "330.00",
        boardAmount: "0.00",
        occupancyAmount: "0.00",
        extraBedAmount: "0.00",
        tourismTaxAmount: "30.00",
        totalAmount: "360.00",
        rateNames: "Winter Partner Rate BB",
        notes: "Stay 1: Al Khoory Executive Hotel (Al Barsha)",
      },
      {
        quotationId: quote1.id,
        sortOrder: 1,
        hotelId: skyHotel.id,
        roomTypeId: skyRoom.id,
        boardType: "breakfast",
        checkIn: stay2In,
        checkOut: stay2Out,
        nights: 2,
        adults: 2,
        children: 0,
        infants: 0,
        rooms: 1,
        baseAmount: "315.00",
        boardAmount: "0.00",
        occupancyAmount: "0.00",
        extraBedAmount: "0.00",
        tourismTaxAmount: "30.00",
        totalAmount: "345.00",
        rateNames: "Winter Partner Rate BB",
        notes: "Stay 2: Al Khoory Sky Garden Hotel",
      },
    ]);

    // Single stay proposal: Jumeirah Beach Hotel
    const [jumeirah] = await tx.select().from(hotels).where(eq(hotels.supplierCode, "JBH-DXB")).limit(1);
    if (jumeirah) {
      const [jRoom] = await tx.select().from(roomTypes).where(eq(roomTypes.hotelId, jumeirah.id)).limit(1);
      if (jRoom) {
        const jIn = addD(today, 21);
        const jOut = addD(jIn, 3);
        const [quote2] = await tx
          .insert(quotations)
          .values({
            reference: "LAQ-10025",
            title: "Jumeirah Beach Resort 3-Night Proposal",
            clientName: "Nabil Rahman",
            clientEmail: "nabil@rahmanholdings.example",
            clientPhone: "+971 50 882 1990",
            clientCompany: "Rahman Holdings Dubai",
            market: "all",
            status: "accepted",
            validUntil: addD(today, 10),
            totalNights: 3,
            totalGuests: "2 Adults",
            baseAmount: "2115.00",
            boardAmount: "0.00",
            occupancyAmount: "0.00",
            extraBedAmount: "0.00",
            tourismTaxAmount: "60.00",
            totalAmount: "2175.00",
            currency: "AED",
            notes: "Sea view deluxe room with daily breakfast included.",
          })
          .returning();

        await tx.insert(quotationItems).values([
          {
            quotationId: quote2.id,
            sortOrder: 0,
            hotelId: jumeirah.id,
            roomTypeId: jRoom.id,
            boardType: "breakfast",
            checkIn: jIn,
            checkOut: jOut,
            nights: 3,
            adults: 2,
            children: 0,
            infants: 0,
            rooms: 1,
            baseAmount: "2115.00",
            boardAmount: "0.00",
            occupancyAmount: "0.00",
            extraBedAmount: "0.00",
            tourismTaxAmount: "60.00",
            totalAmount: "2175.00",
            rateNames: "Winter Partner Rate BB",
            notes: "Deluxe King Sea View",
          },
        ]);
      }
    }
  });
}
