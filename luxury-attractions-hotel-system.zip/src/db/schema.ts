import {
  boolean,
  date,
  index,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const hotels = pgTable(
  "hotels",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    city: text("city").notNull(),
    country: text("country").notNull().default("United Arab Emirates"),
    locationId: integer("location_id").references(() => locations.id, { onDelete: "set null" }),
    address: text("address").notNull().default(""),
    starRating: integer("star_rating").notNull().default(5),
    supplierCode: text("supplier_code").notNull(),
    groupId: integer("group_id").references(() => hotelGroups.id, { onDelete: "set null" }),
    businessType: text("business_type").notNull().default("Hotel"),
    website: text("website").notNull().default(""),
    contractsFolderLink: text("contracts_folder_link").notNull().default(""),
    mediaLink: text("media_link").notNull().default(""),
    contactEmail: text("contact_email").notNull().default(""),
    contactPhone: text("contact_phone").notNull().default(""),
    currency: text("currency").notNull().default("AED"),
    checkInTime: text("check_in_time").notNull().default("15:00"),
    checkOutTime: text("check_out_time").notNull().default("12:00"),
    tourismTax: numeric("tourism_tax", { precision: 10, scale: 2 }).notNull().default("0"),
    tourismTaxBasis: text("tourism_tax_basis").notNull().default("room_night"),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("hotels_supplier_code_idx").on(table.supplierCode)],
);

export const markets = pgTable(
  "markets",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    label: text("label").notNull(),
    sortOrder: integer("sort_order").notNull().default(100),
    active: boolean("active").notNull().default(true),
  },
  (table) => [uniqueIndex("markets_slug_idx").on(table.slug)],
);

/** A district inside a city/emirate, e.g. city "Dubai" → location "Deira". */
export const locations = pgTable(
  "locations",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    name: text("name").notNull(),
    active: boolean("active").notNull().default(true),
  },
  (table) => [uniqueIndex("locations_city_name_idx").on(table.city, table.name)],
);

export const hotelGroups = pgTable(
  "hotel_groups",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    website: text("website").notNull().default(""),
    notes: text("notes").notNull().default(""),
    active: boolean("active").notNull().default(true),
  },
  (table) => [uniqueIndex("hotel_groups_name_idx").on(table.name)],
);

export const amenities = pgTable(
  "amenities",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    label: text("label").notNull(),
    icon: text("icon").notNull().default("check"),
    sortOrder: integer("sort_order").notNull().default(100),
    active: boolean("active").notNull().default(true),
  },
  (table) => [uniqueIndex("amenities_slug_idx").on(table.slug)],
);

export const hotelAmenities = pgTable(
  "hotel_amenities",
  {
    id: serial("id").primaryKey(),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id, { onDelete: "cascade" }),
    amenityId: integer("amenity_id")
      .notNull()
      .references(() => amenities.id, { onDelete: "cascade" }),
  },
  (table) => [uniqueIndex("hotel_amenities_unique_idx").on(table.hotelId, table.amenityId)],
);

export const roomCategories = pgTable(
  "room_categories",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    label: text("label").notNull(),
    sortOrder: integer("sort_order").notNull().default(100),
    active: boolean("active").notNull().default(true),
  },
  (table) => [uniqueIndex("room_categories_slug_idx").on(table.slug)],
);

export const hotelContacts = pgTable(
  "hotel_contacts",
  {
    id: serial("id").primaryKey(),
    // Legacy hotel owner; old rows are backfilled into hotel_contact_assignments and cleared.
    hotelId: integer("hotel_id").references(() => hotels.id, { onDelete: "set null" }),
    groupId: integer("group_id").references(() => hotelGroups.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    position: text("position").notNull().default(""),
    email: text("email").notNull().default(""),
    phone: text("phone").notNull().default(""),
    businessCardLink: text("business_card_link").notNull().default(""),
    whatsapp: boolean("whatsapp").notNull().default(false),
    telegram: boolean("telegram").notNull().default(false),
    viber: boolean("viber").notNull().default(false),
    otherContact: text("other_contact").notNull().default(""),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("hotel_contacts_hotel_idx").on(table.hotelId),
    index("hotel_contacts_group_idx").on(table.groupId),
  ],
);

export const hotelContactAssignments = pgTable(
  "hotel_contact_assignments",
  {
    id: serial("id").primaryKey(),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id, { onDelete: "cascade" }),
    contactId: integer("contact_id")
      .notNull()
      .references(() => hotelContacts.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("hotel_contact_assignments_unique_idx").on(table.hotelId, table.contactId),
    index("hotel_contact_assignments_contact_idx").on(table.contactId),
  ],
);

export const roomTypes = pgTable(
  "room_types",
  {
    id: serial("id").primaryKey(),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    code: text("code").notNull(),
    category: text("category").notNull().default("deluxe_king"),
    description: text("description").notNull().default(""),
    maxAdults: integer("max_adults").notNull().default(2),
    maxChildren: integer("max_children").notNull().default(0),
    maxInfants: integer("max_infants").notNull().default(0),
    includedAdults: integer("included_adults").notNull().default(2),
    baseSleeps: integer("base_sleeps").notNull().default(2),
    defaultInventory: integer("default_inventory").notNull().default(1),
    extraBedAllowed: boolean("extra_bed_allowed").notNull().default(false),
    mediaLink: text("media_link").notNull().default(""),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("room_types_hotel_idx").on(table.hotelId),
    uniqueIndex("room_types_hotel_code_idx").on(table.hotelId, table.code),
  ],
);

export const occupancyRules = pgTable(
  "occupancy_rules",
  {
    id: serial("id").primaryKey(),
    roomTypeId: integer("room_type_id")
      .notNull()
      .references(() => roomTypes.id, { onDelete: "cascade" }),
    adults: integer("adults").notNull(),
    children: integer("children").notNull().default(0),
    infants: integer("infants").notNull().default(0),
    extraBeds: integer("extra_beds").notNull().default(0),
    label: text("label").notNull().default(""),
  },
  (table) => [index("occupancy_rules_room_idx").on(table.roomTypeId)],
);

export const roomBedding = pgTable(
  "room_bedding",
  {
    id: serial("id").primaryKey(),
    roomTypeId: integer("room_type_id")
      .notNull()
      .references(() => roomTypes.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(),
    label: text("label").notNull(),
    maxPerRoom: integer("max_per_room").notNull().default(1),
    free: boolean("free").notNull().default(false),
    ratePerNight: numeric("rate_per_night", { precision: 10, scale: 2 }).notNull().default("0"),
    perStay: boolean("per_stay").notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(100),
  },
  (table) => [uniqueIndex("room_bedding_unique_idx").on(table.roomTypeId, table.kind)],
);

export const ratePeriods = pgTable(
  "rate_periods",
  {
    id: serial("id").primaryKey(),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id, { onDelete: "cascade" }),
    roomTypeId: integer("room_type_id")
      .notNull()
      .references(() => roomTypes.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    boardType: text("board_type").notNull().default("breakfast"),
    validFrom: date("valid_from").notNull(),
    validTo: date("valid_to").notNull(),
    bookingWindowStart: date("booking_window_start"),
    bookingWindowEnd: date("booking_window_end"),
    market: text("market").notNull().default("all"),
    marketExclusions: text("market_exclusions").notNull().default(""),
    promoCode: text("promo_code").notNull().default(""),
    baseRate: numeric("base_rate", { precision: 12, scale: 2 }).notNull(),
    rateBasis: text("rate_basis").notNull().default("room_night"),
    boardAdultSupplement: numeric("board_adult_supplement", { precision: 10, scale: 2 })
      .notNull()
      .default("0"),
    boardChildSupplement: numeric("board_child_supplement", { precision: 10, scale: 2 })
      .notNull()
      .default("0"),
    boardSupplementBasis: text("board_supplement_basis").notNull().default("person_night"),
    extraAdultRate: numeric("extra_adult_rate", { precision: 10, scale: 2 }).notNull().default("0"),
    extraChildRate: numeric("extra_child_rate", { precision: 10, scale: 2 }).notNull().default("0"),
    extraBedRate: numeric("extra_bed_rate", { precision: 10, scale: 2 }).notNull().default("0"),
    extraBedBasis: text("extra_bed_basis").notNull().default("bed_night"),
    minimumNights: integer("minimum_nights").notNull().default(1),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("rate_periods_hotel_idx").on(table.hotelId),
    index("rate_periods_room_dates_idx").on(table.roomTypeId, table.validFrom, table.validTo),
  ],
);

export const blackoutDates = pgTable(
  "blackout_dates",
  {
    id: serial("id").primaryKey(),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id, { onDelete: "cascade" }),
    roomTypeId: integer("room_type_id").references(() => roomTypes.id, { onDelete: "cascade" }),
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),
    reason: text("reason").notNull().default("Sold out by hotel"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("blackout_dates_hotel_dates_idx").on(table.hotelId, table.startDate, table.endDate)],
);

/** Staff accounts. Permissions are stored as a comma separated list of keys. */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    name: text("name").notNull(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("agent"), // admin | manager | agent | viewer
    permissions: text("permissions").notNull().default(""),
    phone: text("phone").notNull().default(""),
    active: boolean("active").notNull().default(true),
    mustChangePassword: boolean("must_change_password").notNull().default(false),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_email_idx").on(table.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    token: text("token").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("sessions_token_idx").on(table.token), index("sessions_user_idx").on(table.userId)],
);

/** Single-row SMTP configuration for sending quotations and trip packages. */
export const smtpSettings = pgTable("smtp_settings", {
  id: serial("id").primaryKey(),
  host: text("host").notNull().default(""),
  port: integer("port").notNull().default(587),
  secure: boolean("secure").notNull().default(false),
  username: text("username").notNull().default(""),
  password: text("password").notNull().default(""),
  fromName: text("from_name").notNull().default("Luxury Attractions"),
  fromEmail: text("from_email").notNull().default(""),
  replyTo: text("reply_to").notNull().default(""),
  bccSelf: boolean("bcc_self").notNull().default(false),
  active: boolean("active").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Bookable extras sold alongside a hotel stay: transfers and other services. */
export const services = pgTable(
  "services",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    kind: text("kind").notNull().default("shared_transfer"), // shared_transfer | private_transfer | other
    vehicleType: text("vehicle_type").notNull().default(""), // e.g. 7 Seater, 12 Seater
    priceMode: text("price_mode").notNull().default("per_person"), // per_person | per_vehicle
    oneWayPrice: numeric("one_way_price", { precision: 10, scale: 2 }).notNull().default("0"),
    twoWayPrice: numeric("two_way_price", { precision: 10, scale: 2 }).notNull().default("0"),
    details: text("details").notNull().default(""),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("services_kind_idx").on(table.kind)],
);

/** Tours and tickets with ticket-only / shared / private price tiers (all per person). */
export const tours = pgTable(
  "tours",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    category: text("category").notNull().default("tour"), // tour | ticket
    ticketOnlyPrice: numeric("ticket_only_price", { precision: 10, scale: 2 }).notNull().default("0"),
    sharedTransferPrice: numeric("shared_transfer_price", { precision: 10, scale: 2 }).notNull().default("0"),
    privateTransferPrice: numeric("private_transfer_price", { precision: 10, scale: 2 }).notNull().default("0"),
    details: text("details").notNull().default(""),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("tours_category_idx").on(table.category)],
);

export const tripPackages = pgTable(
  "trip_packages",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    quotationId: integer("quotation_id").references(() => quotations.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    clientName: text("client_name").notNull(),
    clientEmail: text("client_email").notNull().default(""),
    clientPhone: text("client_phone").notNull().default(""),
    clientCompany: text("client_company").notNull().default(""),
    status: text("status").notNull().default("draft"), // draft, sent, confirmed, completed
    startDate: date("start_date"),
    endDate: date("end_date"),
    includesHotels: boolean("includes_hotels").notNull().default(true),
    includeTax: boolean("include_tax").notNull().default(true),
    markupMode: text("markup_mode").notNull().default("percent"),
    markupValue: numeric("markup_value", { precision: 12, scale: 2 }).notNull().default("0"),
    hotelCostTotal: numeric("hotel_cost_total", { precision: 12, scale: 2 }).notNull().default("0"),
    extrasCostTotal: numeric("extras_cost_total", { precision: 12, scale: 2 }).notNull().default("0"),
    tourismTaxAmount: numeric("tourism_tax_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    markupAmount: numeric("markup_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    quotedTotal: numeric("quoted_total", { precision: 12, scale: 2 }).notNull().default("0"),
    totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    currency: text("currency").notNull().default("AED"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("trip_packages_reference_idx").on(table.reference),
    index("trip_packages_quote_idx").on(table.quotationId),
  ],
);

export const tripPackageItems = pgTable(
  "trip_package_items",
  {
    id: serial("id").primaryKey(),
    packageId: integer("package_id")
      .notNull()
      .references(() => tripPackages.id, { onDelete: "cascade" }),
    sortOrder: integer("sort_order").notNull().default(0),
    kind: text("kind").notNull().default("service"), // service | tour
    serviceId: integer("service_id").references(() => services.id, { onDelete: "set null" }),
    tourId: integer("tour_id").references(() => tours.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    priceType: text("price_type").notNull().default("per_person"), // for tours: ticket_only | shared | private; services: shared_one_way | shared_two_way | private_one_way | private_two_way
    serviceDate: date("service_date"),
    serviceTime: text("service_time").notNull().default(""),
    pickup: text("pickup").notNull().default(""),
    dropoff: text("dropoff").notNull().default(""),
    persons: integer("persons").notNull().default(1),
    vehicles: integer("vehicles").notNull().default(1),
    unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull().default("0"),
    totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull().default("0"),
    details: text("details").notNull().default(""),
  },
  (table) => [index("trip_package_items_pkg_idx").on(table.packageId)],
);

export const quotations = pgTable(
  "quotations",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    title: text("title").notNull().default(""),
    clientName: text("client_name").notNull(),
    clientEmail: text("client_email").notNull().default(""),
    clientPhone: text("client_phone").notNull().default(""),
    clientCompany: text("client_company").notNull().default(""),
    market: text("market").notNull().default("all"),
    status: text("status").notNull().default("draft"), // draft, sent, accepted, converted, expired
    validUntil: date("valid_until"),
    totalNights: integer("total_nights").notNull().default(0),
    totalGuests: text("total_guests").notNull().default(""),
    baseAmount: numeric("base_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    boardAmount: numeric("board_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    occupancyAmount: numeric("occupancy_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    extraBedAmount: numeric("extra_bed_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    tourismTaxAmount: numeric("tourism_tax_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    // Quotation commercial settings
    includeTax: boolean("include_tax").notNull().default(true),
    markupMode: text("markup_mode").notNull().default("percent"), // percent | amount
    markupValue: numeric("markup_value", { precision: 12, scale: 2 }).notNull().default("0"),
    hotelCostTotal: numeric("hotel_cost_total", { precision: 12, scale: 2 }).notNull().default("0"),
    markupAmount: numeric("markup_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    quotedTotal: numeric("quoted_total", { precision: 12, scale: 2 }).notNull().default("0"),
    totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    currency: text("currency").notNull().default("AED"),
    notes: text("notes").notNull().default(""),
    convertedBookingId: integer("converted_booking_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("quotations_reference_idx").on(table.reference),
    index("quotations_client_idx").on(table.clientName, table.clientEmail),
  ],
);

export const quotationItems = pgTable(
  "quotation_items",
  {
    id: serial("id").primaryKey(),
    quotationId: integer("quotation_id")
      .notNull()
      .references(() => quotations.id, { onDelete: "cascade" }),
    sortOrder: integer("sort_order").notNull().default(0),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id),
    roomTypeId: integer("room_type_id")
      .notNull()
      .references(() => roomTypes.id),
    ratePeriodId: integer("rate_period_id")
      .references(() => ratePeriods.id),
    boardType: text("board_type").notNull().default("breakfast"),
    checkIn: date("check_in").notNull(),
    checkOut: date("check_out").notNull(),
    nights: integer("nights").notNull().default(1),
    adults: integer("adults").notNull().default(2),
    children: integer("children").notNull().default(0),
    infants: integer("infants").notNull().default(0),
    rooms: integer("rooms").notNull().default(1),
    extraBeds: integer("extra_beds").notNull().default(0),
    sofaBeds: integer("sofa_beds").notNull().default(0),
    babyCots: integer("baby_cots").notNull().default(0),
    baseAmount: numeric("base_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    boardAmount: numeric("board_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    occupancyAmount: numeric("occupancy_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    extraBedAmount: numeric("extra_bed_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    tourismTaxAmount: numeric("tourism_tax_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    rateNames: text("rate_names").notNull().default(""),
    promoCodes: text("promo_codes").notNull().default(""),
    notes: text("notes").notNull().default(""),
  },
  (table) => [index("quotation_items_quote_idx").on(table.quotationId)],
);

export const bookings = pgTable(
  "bookings",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id),
    roomTypeId: integer("room_type_id")
      .notNull()
      .references(() => roomTypes.id),
    ratePeriodId: integer("rate_period_id")
      .references(() => ratePeriods.id),
    boardType: text("board_type").notNull().default("breakfast"),
    guestName: text("guest_name").notNull(),
    guestEmail: text("guest_email").notNull(),
    guestPhone: text("guest_phone").notNull().default(""),
    checkIn: date("check_in").notNull(),
    checkOut: date("check_out").notNull(),
    adults: integer("adults").notNull(),
    children: integer("children").notNull().default(0),
    infants: integer("infants").notNull().default(0),
    rooms: integer("rooms").notNull().default(1),
    extraBeds: integer("extra_beds").notNull().default(0),
    sofaBeds: integer("sofa_beds").notNull().default(0),
    babyCots: integer("baby_cots").notNull().default(0),
    nights: integer("nights").notNull(),
    baseAmount: numeric("base_amount", { precision: 12, scale: 2 }).notNull(),
    boardAmount: numeric("board_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    occupancyAmount: numeric("occupancy_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    extraBedAmount: numeric("extra_bed_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    tourismTaxAmount: numeric("tourism_tax_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).notNull(),
    currency: text("currency").notNull().default("AED"),
    status: text("status").notNull().default("confirmed"),
    notes: text("notes").notNull().default(""),
    quotationId: integer("quotation_id").references(() => quotations.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("bookings_reference_idx").on(table.reference),
    index("bookings_dates_idx").on(table.checkIn, table.checkOut),
  ],
);

export const bookingItems = pgTable(
  "booking_items",
  {
    id: serial("id").primaryKey(),
    bookingId: integer("booking_id")
      .notNull()
      .references(() => bookings.id, { onDelete: "cascade" }),
    sortOrder: integer("sort_order").notNull().default(0),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id),
    roomTypeId: integer("room_type_id")
      .notNull()
      .references(() => roomTypes.id),
    ratePeriodId: integer("rate_period_id")
      .references(() => ratePeriods.id),
    boardType: text("board_type").notNull().default("breakfast"),
    checkIn: date("check_in").notNull(),
    checkOut: date("check_out").notNull(),
    nights: integer("nights").notNull().default(1),
    adults: integer("adults").notNull().default(2),
    children: integer("children").notNull().default(0),
    infants: integer("infants").notNull().default(0),
    rooms: integer("rooms").notNull().default(1),
    extraBeds: integer("extra_beds").notNull().default(0),
    sofaBeds: integer("sofa_beds").notNull().default(0),
    babyCots: integer("baby_cots").notNull().default(0),
    baseAmount: numeric("base_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    boardAmount: numeric("board_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    occupancyAmount: numeric("occupancy_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    extraBedAmount: numeric("extra_bed_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    tourismTaxAmount: numeric("tourism_tax_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    rateNames: text("rate_names").notNull().default(""),
    promoCodes: text("promo_codes").notNull().default(""),
    notes: text("notes").notNull().default(""),
  },
  (table) => [index("booking_items_booking_idx").on(table.bookingId)],
);

export type User = typeof users.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type SmtpSetting = typeof smtpSettings.$inferSelect;
export type Service = typeof services.$inferSelect;
export type Tour = typeof tours.$inferSelect;
export type TripPackage = typeof tripPackages.$inferSelect;
export type TripPackageItem = typeof tripPackageItems.$inferSelect;
export type Location = typeof locations.$inferSelect;
export type Market = typeof markets.$inferSelect;
export type HotelGroup = typeof hotelGroups.$inferSelect;
export type HotelContact = typeof hotelContacts.$inferSelect;
export type HotelContactAssignment = typeof hotelContactAssignments.$inferSelect;
export type Hotel = typeof hotels.$inferSelect;
export type RoomType = typeof roomTypes.$inferSelect;
export type OccupancyRule = typeof occupancyRules.$inferSelect;
export type RatePeriod = typeof ratePeriods.$inferSelect;
export type BlackoutDate = typeof blackoutDates.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type BookingItem = typeof bookingItems.$inferSelect;
export type Quotation = typeof quotations.$inferSelect;
export type QuotationItem = typeof quotationItems.$inferSelect;
