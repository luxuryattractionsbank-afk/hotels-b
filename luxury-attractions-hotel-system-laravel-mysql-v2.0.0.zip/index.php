<?php
// Fallback when the document root is this folder and .htaccess is ignored.
require __DIR__.'/public/index.php';
