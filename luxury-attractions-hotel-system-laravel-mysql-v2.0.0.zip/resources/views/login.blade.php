<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in | Luxury Attractions Hotel Contracts</title>
<link rel="stylesheet" href="/build/app.css?v={{ @filemtime(public_path('build/app.css')) }}">
</head>
<body>
@if(session('ok'))<div style="position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:50;background:#dcfce7;color:#166534;border-radius:10px;padding:10px 16px;font:600 13px Inter,system-ui,sans-serif">{{ session('ok') }}</div>@endif
<div id="root"></div>
<script src="/build/login.js?v={{ @filemtime(public_path('build/login.js')) }}"></script>
</body>
</html>
