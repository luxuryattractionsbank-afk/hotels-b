<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Install | Luxury Attractions Hotel Contracts</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#0f2d2a;font:14px/1.5 Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#15211f;padding:40px 16px}
.wrap{max-width:720px;margin:0 auto}.brand{text-align:center;color:#fff;margin-bottom:24px}.logo{width:56px;height:56px;border-radius:16px;background:#174e48;display:grid;place-items:center;margin:0 auto 12px;font-weight:800;color:#e6c274;box-shadow:0 10px 30px rgba(0,0,0,.3)}
.brand h1{margin:0;font-size:22px}.brand p{margin:4px 0 0;color:#9fc7c1;font-size:13px}
.card{background:#fff;border-radius:18px;padding:22px 24px;margin-bottom:16px;box-shadow:0 20px 50px rgba(0,0,0,.25)}
.card h2{margin:0 0 12px;font-size:15px;color:#15554e;display:flex;gap:10px;align-items:center}.step{width:24px;height:24px;border-radius:99px;background:#dcece9;color:#15554e;display:grid;place-items:center;font-size:12px;font-weight:800}
ul{list-style:none;margin:0;padding:0}li{display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid #eef2f1}li small{color:#64748b;display:block}
.ok{color:#15803d;font-weight:800}.bad{color:#b91c1c;font-weight:800}
.grid{display:grid;gap:12px;grid-template-columns:1fr 1fr}.full{grid-column:1/-1}
label span{display:block;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#5b6b69;margin-bottom:4px}
input[type=text],input[type=email],input[type=password]{width:100%;height:42px;border:1px solid #d6e0de;border-radius:10px;padding:0 12px;font:inherit;background:#fbfdfc}
input:focus{outline:2px solid #2d8a7e;border-color:#2d8a7e}
.check{display:flex;gap:10px;align-items:flex-start;border:1px solid #d6e0de;border-radius:12px;padding:12px;background:#f7faf9}.check small{display:block;color:#64748b}
button{height:44px;border:0;border-radius:11px;background:#174e48;color:#fff;font-weight:700;padding:0 20px;cursor:pointer;font:inherit;font-weight:700}button:hover{background:#15554e}
.gold{background:#c9a24d;color:#1b1406}.gold:hover{background:#d8b669}
.msg{border-radius:12px;padding:12px 14px;margin-bottom:14px;font-weight:600}.err{background:#fef2f2;color:#991b1b}.good{background:#ecfdf5;color:#065f46}
.muted{color:#64748b;font-size:12px}code{background:#f1f5f4;padding:1px 6px;border-radius:6px}
@media(max-width:600px){.grid{grid-template-columns:1fr}}
</style></head><body><div class="wrap">
<div class="brand"><div class="logo">LA</div><h1>Hotel Contracts — Installation</h1><p>Luxury Attractions · Laravel + MySQL · hotels.luxuryattractions.com</p></div>
@if(session('error'))<div class="msg err">{{ session('error') }}</div>@endif
@if($errors->any())<div class="msg err">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
@if(session('ok'))<div class="msg good">✓ {{ session('ok') }}</div>@endif

<div class="card"><h2><span class="step">1</span> Server check</h2><ul>
@foreach($reqs as [$label, $pass, $detail])<li><div>{{ $label }}<small>{{ $detail }}</small></div><span class="{{ $pass ? 'ok' : 'bad' }}">{{ $pass ? 'PASS' : 'FIX' }}</span></li>@endforeach
</ul>@if(collect($reqs)->contains(fn ($r) => ! $r[1]))<p class="muted" style="margin:10px 0 0">Fix the items marked FIX (cPanel → Select PHP Version for PHP/extensions; set <code>storage</code> and <code>bootstrap/cache</code> to 775), then reload.</p>@endif</div>

<div class="card"><h2><span class="step">2</span> Connect your MySQL database</h2>
<p class="muted" style="margin-top:0">Create the database and user in cPanel → <b>MySQL® Databases</b>, add the user to the database with <b>ALL PRIVILEGES</b>, then enter the full names below. The connection is tested live before anything is written.</p>
<form method="post" action="/install/test" class="grid">@csrf
<label><span>Database host</span><input type="text" name="host" value="{{ old('host', $db['host'] ?? 'localhost') }}"></label>
<label><span>Port</span><input type="text" name="port" value="{{ old('port', $db['port'] ?? '3306') }}"></label>
<label class="full"><span>Database name</span><input type="text" name="database" required placeholder="e.g. myuser_hotels" value="{{ old('database', $db['database'] ?? '') }}"></label>
<label><span>Database username</span><input type="text" name="username" required autocomplete="off" placeholder="e.g. myuser_hotels" value="{{ old('username', $db['username'] ?? '') }}"></label>
<label><span>Database password</span><input type="password" name="password" autocomplete="new-password"></label>
<div class="full"><button type="submit">{{ $db ? 'Test again' : 'Test connection' }}</button> @if($db)<span class="ok" style="margin-left:10px">✓ Connected to {{ $db['database'] }}</span>@endif</div>
</form></div>

<div class="card" @if(!$db) style="opacity:.55" @endif><h2><span class="step">3</span> Administrator &amp; install</h2>
@if(!$db)<p class="muted" style="margin:0">Test the database connection first.</p>@else
<form method="post" action="/install" class="grid">@csrf
<label><span>Your name</span><input type="text" name="admin_name" required value="{{ old('admin_name') }}"></label>
<label><span>Admin email (login)</span><input type="email" name="admin_email" required value="{{ old('admin_email', 'admin@luxuryattractions.com') }}"></label>
<label><span>Password (min 8)</span><input type="password" name="admin_password" required></label>
<label><span>Confirm password</span><input type="password" name="admin_password_confirmation" required></label>
<label class="check full"><input type="checkbox" name="demo" value="1" checked><div><b>Load the sample catalogue</b><small>14 UAE hotels, 36 room types, 792 contracted rate lines, contacts, markets, transfers, tours, a sample quotation and trip package — identical to the original system. Illustrative only: replace with your real contracts.</small></div></label>
<label class="check full"><input type="checkbox" name="demo_agent" value="1"><div><b>Create a demo reservations agent</b><small>agent@luxuryattractions.com / Agent@12345 — shows how permissions hide net cost &amp; markup.</small></div></label>
<div class="full"><button class="gold" type="submit">Install now</button></div>
</form>@endif</div>
<p class="muted" style="text-align:center;color:#9fc7c1">Diagnostics: <a style="color:#e6c274" href="/check.php">/check.php</a> · <a style="color:#e6c274" href="/health">/health</a></p>
</div></body></html>
