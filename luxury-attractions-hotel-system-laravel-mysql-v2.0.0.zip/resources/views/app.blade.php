<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hotel Contracts | Luxury Attractions</title>
<meta name="description" content="B2B hotel contracts, rates, availability, and booking management for Luxury Attractions.">
<meta name="application-name" content="Luxury Attractions Hotel Contracts">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="stylesheet" href="/build/app.css?v={{ @filemtime(public_path('build/app.css')) }}">
</head>
<body>
<div id="root"><div style="display:grid;min-height:100vh;place-items:center;font:600 14px Inter,system-ui,sans-serif;color:#15554e">Loading contracts…</div></div>
<script id="la-boot" type="application/json">{!! $boot !!}</script>
<script src="/build/app.js?v={{ @filemtime(public_path('build/app.js')) }}"></script>
</body>
</html>
