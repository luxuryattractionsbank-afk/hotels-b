<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) require $maintenance;

require __DIR__.'/../vendor/autoload.php';

try {
    /** @var Application $app */
    $app = require_once __DIR__.'/../bootstrap/app.php';
    $app->handleRequest(Request::capture());
} catch (\Throwable $e) {
    if (! headers_sent()) http_response_code(500);
    echo '<!DOCTYPE html><meta charset="utf-8"><title>Startup error</title><div style="font:14px system-ui;max-width:860px;margin:40px auto;padding:20px;border:1px solid #fca5a5;border-radius:12px;background:#fef2f2;color:#7f1d1d">';
    echo '<h2 style="margin-top:0">The application could not start</h2><p><b>'.htmlspecialchars($e->getMessage()).'</b></p><p><code>'.htmlspecialchars($e->getFile()).':'.$e->getLine().'</code></p>';
    echo '<p>Open <a href="/check.php">/check.php</a> to diagnose PHP version, extensions and folder permissions.</p></div>';
}
