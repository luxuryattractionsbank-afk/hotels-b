<?php
/**
 * Pre-install diagnostic - open https://hotels.luxuryattractions.com/check.php
 * It never writes anything and can be deleted after a successful install.
 */
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Determine project root whether check.php is in public/ or root
$root = file_exists(__DIR__ . '/artisan') ? __DIR__ : dirname(__DIR__);
$ok = static fn (bool $v): string => $v ? 'PASS' : 'FAIL';

$version = PHP_VERSION;
$phpOk = version_compare($version, '8.2.0', '>=');

$needed = ['pdo_mysql','mbstring','openssl','dom','xml','curl','gd','fileinfo','zip','iconv','ctype','tokenizer','filter','session'];
$ext = [];
foreach ($needed as $e) { $ext[$e] = extension_loaded($e); }

$writable = [
    '.env'                       => is_writable($root.'/.env') || (!file_exists($root.'/.env') && is_writable($root)),
    'storage/'                   => is_dir($root.'/storage') && is_writable($root.'/storage'),
    'storage/framework/sessions' => is_dir($root.'/storage/framework/sessions') && is_writable($root.'/storage/framework/sessions'),
    'storage/framework/views'    => is_dir($root.'/storage/framework/views') && is_writable($root.'/storage/framework/views'),
    'storage/logs'               => is_dir($root.'/storage/logs') && is_writable($root.'/storage/logs'),
    'bootstrap/cache/'           => is_dir($root.'/bootstrap/cache') && is_writable($root.'/bootstrap/cache'),
];

$vendor = file_exists($root.'/vendor/autoload.php');
$htaccess = file_exists($root.'/.htaccess') && file_exists($root.'/public/.htaccess');

$dbMsg = 'Not tested - fill the form below.';
$dbState = '';
if (isset($_POST['db_test'])) {
    $host = trim($_POST['host'] ?? 'localhost') ?: 'localhost';
    $port = trim($_POST['port'] ?? '3306') ?: '3306';
    $name = trim($_POST['name'] ?? '');
    $user = trim($_POST['user'] ?? '');
    $pass = (string) ($_POST['pass'] ?? '');
    try {
        $pdo = new PDO("mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8,
        ]);
        $v = $pdo->query('select version()')->fetchColumn();
        $t = (int) $pdo->query('select count(*) from information_schema.tables where table_schema = '.$pdo->quote($name))->fetchColumn();
        $dbState = 'PASS';
        $dbMsg = "Connected - {$v}, database \"{$name}\" ({$t} existing table(s)).";
    } catch (Throwable $e) {
        $dbState = 'FAIL';
        $m = $e->getMessage();
        $dbMsg = str_contains($m, 'Access denied')
            ? 'Wrong database username/password, or user not added to database with ALL PRIVILEGES in cPanel.'
            : (str_contains($m, 'Unknown database')
                ? 'Database name does not exist - use the full cPanel name, e.g. myuser_hotels.'
                : (str_contains($m, 'refused') || str_contains($m, 'getaddrinfo') || str_contains($m, 'timed out')
                    ? 'Cannot reach database server - on cPanel host is "localhost" and port "3306".'
                    : $m));
    }
}

$allExtOk = !in_array(false, $ext, true);
$allWritOk = !in_array(false, $writable, true);
$ready = $phpOk && $allExtOk && $allWritOk && $vendor;
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Install check - Luxury Attractions Hotels</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#08090c;color:#e8eaf0;font:15px/1.55 ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.wrap{max-width:860px;margin:0 auto;padding:40px 20px}
h1{font-size:22px;margin:0 0 4px}p.sub{color:#8b93a5;margin:0 0 26px;font-size:13px}
.card{border:1px solid #1e2431;border-radius:12px;background:linear-gradient(180deg,#12151c,#0f1218);margin-bottom:18px;overflow:hidden}
.card h2{margin:0;padding:12px 18px;font-size:13px;letter-spacing:.04em;border-bottom:1px solid #1e2431;color:#c8cede}
table{width:100%;border-collapse:collapse;font-size:14px}
td{padding:9px 18px;border-bottom:1px solid #171c26}
td:last-child{width:90px;text-align:right;font-weight:700;font-size:12px;letter-spacing:.06em}
.PASS{color:#6ee7a8}.FAIL{color:#fda4a4}
input{width:100%;padding:8px 10px;border-radius:8px;border:1px solid #2a3140;background:#12151c;color:#e8eaf0;font-size:14px}
button{padding:10px 18px;border:0;border-radius:8px;background:linear-gradient(180deg,#d8b669,#b8903c);color:#14100a;font-weight:700;cursor:pointer}
.grid{display:grid;gap:12px;padding:16px 18px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr))}
label{display:block;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#8b93a5;margin-bottom:4px}
.msg{padding:12px 18px;font-size:14px;color:#c8cede;border-top:1px solid #1e2431}
.ready{padding:14px 18px;font-weight:700}
a{color:#e2c07a}
</style></head><body><div class="wrap">
<h1>Luxury Attractions Hotels &mdash; install check</h1>
<p class="sub">Laravel 12 + MySQL &middot; target hotels.luxuryattractions.com &middot; this page changes nothing and can be deleted after installing.</p>

<div class="card"><div class="ready <?= $ready ? 'PASS' : 'FAIL' ?>">
<?= $ready ? 'READY - open /install and complete the wizard.' : 'NOT READY - fix the FAIL rows below, then reload this page.' ?>
</div></div>

<div class="card"><h2>PHP &amp; server</h2><table>
<tr><td>PHP 8.2 or newer <span style="color:#8b93a5">(running <?= htmlspecialchars($version) ?>)</span></td><td class="<?= $ok($phpOk) ?>"><?= $ok($phpOk) ?></td></tr>
<?php foreach ($ext as $e => $has): ?>
<tr><td>PHP extension: <?= htmlspecialchars($e) ?></td><td class="<?= $ok($has) ?>"><?= $ok($has) ?></td></tr>
<?php endforeach; ?>
<tr><td>Composer dependencies (<code>vendor/autoload.php</code>)</td><td class="<?= $ok($vendor) ?>"><?= $ok($vendor) ?></td></tr>
<tr><td>Front-controller <code>.htaccess</code> files present</td><td class="<?= $ok($htaccess) ?>"><?= $ok($htaccess) ?></td></tr>
</table></div>

<div class="card"><h2>Writable paths</h2><table>
<?php foreach ($writable as $path => $w): ?>
<tr><td><?= htmlspecialchars($path) ?></td><td class="<?= $ok($w) ?>"><?= $ok($w) ?></td></tr>
<?php endforeach; ?>
</table><div class="msg">Fix with: <code>chmod -R 775 storage bootstrap/cache &amp;&amp; chmod 664 .env</code></div></div>

<div class="card"><h2>MySQL connection test</h2>
<form method="post"><div class="grid">
<div><label>Host</label><input name="host" value="<?= htmlspecialchars($_POST['host'] ?? 'localhost') ?>"></div>
<div><label>Port</label><input name="port" value="<?= htmlspecialchars($_POST['port'] ?? '3306') ?>"></div>
<div><label>Database</label><input name="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"></div>
<div><label>User</label><input name="user" value="<?= htmlspecialchars($_POST['user'] ?? '') ?>"></div>
<div><label>Password</label><input name="pass" type="password" value=""></div>
</div><div class="msg"><button name="db_test" value="1">Test connection</button></div></form>
<div class="msg <?= $dbState ?>"><?= htmlspecialchars($dbMsg) ?></div></div>

<p class="sub">Next: <a href="/install">run the installer</a> &middot; health JSON at <a href="/health">/health</a></p>
</div></body></html>
