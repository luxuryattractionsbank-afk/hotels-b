<?php

namespace App\Http\Middleware;

use App\Support\Installer;
use Closure;
use Illuminate\Http\Request;

/** Before installation every page goes to /install; afterwards /install is closed. Never touches the DB. */
class EnsureInstalled
{
    public function handle(Request $request, Closure $next)
    {
        $installing = $request->is('install') || $request->is('install/*');
        $installed = Installer::installed();
        if (! $installed && ! $installing && ! $request->is('health', 'api/health', 'up')) {
            return $request->is('api/*') ? response()->json(['error' => 'The system is not installed yet. Open /install.'], 503) : redirect('/install');
        }
        if ($installed && $installing) return redirect('/login');
        return $next($request);
    }
}
