<?php

namespace App\Http\Controllers;

use App\Support\Auth;
use App\Support\Rows;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Equivalent of src/app/page.tsx, src/app/login/page.tsx and src/lib/search-data.ts. */
class PageController extends Controller
{
    public static function bootData(array $user): array
    {
        $data = [
            'hotels' => Rows::all('hotels', ['name' => 'asc']),
            'markets' => Rows::all('markets', ['sort_order' => 'asc', 'label' => 'asc']),
            'locations' => Rows::all('locations', ['city' => 'asc', 'name' => 'asc']),
            'hotelGroups' => Rows::all('hotel_groups', ['name' => 'asc']),
            'contacts' => Rows::all('hotel_contacts', ['name' => 'asc', 'id' => 'asc']),
            'contactAssignments' => Rows::all('hotel_contact_assignments', ['hotel_id' => 'asc', 'contact_id' => 'asc']),
            'amenities' => Rows::all('amenities', ['sort_order' => 'asc', 'label' => 'asc']),
            'hotelAmenities' => Rows::all('hotel_amenities', ['hotel_id' => 'asc']),
            'roomCategories' => Rows::all('room_categories', ['sort_order' => 'asc', 'label' => 'asc']),
            'rooms' => Rows::all('room_types', ['hotel_id' => 'asc', 'name' => 'asc']),
            'bedding' => Rows::all('room_bedding', ['sort_order' => 'asc']),
            'occupancies' => Rows::all('occupancy_rules', ['room_type_id' => 'asc', 'adults' => 'asc']),
            'rates' => Rows::all('rate_periods', ['hotel_id' => 'asc', 'room_type_id' => 'asc', 'valid_from' => 'asc']),
            'blackouts' => Rows::all('blackout_dates', ['start_date' => 'asc']),
            'bookings' => Rows::all('bookings', ['created_at' => 'desc', 'id' => 'desc']),
            'bookingItems' => Rows::all('booking_items', ['sort_order' => 'asc', 'id' => 'asc']),
            'quotations' => Rows::all('quotations', ['created_at' => 'desc', 'id' => 'desc']),
            'quotationItems' => Rows::all('quotation_items', ['sort_order' => 'asc', 'id' => 'asc']),
            'services' => Rows::all('services', ['name' => 'asc']),
            'tours' => Rows::all('tours', ['name' => 'asc']),
            'tripPackages' => Rows::all('trip_packages', ['created_at' => 'desc']),
            'tripPackageItems' => Rows::all('trip_package_items', ['sort_order' => 'asc', 'id' => 'asc']),
        ];
        $isAdmin = $user['role'] === 'admin' || in_array('users', $user['permissions'], true);
        $users = [];
        if ($isAdmin) {
            foreach (DB::table('users')->orderBy('name')->get() as $u) {
                $row = Rows::out('users', $u);
                $users[] = ['id' => $row['id'], 'name' => $row['name'], 'email' => $row['email'], 'role' => $row['role'], 'permissions' => $row['permissions'],
                    'phone' => $row['phone'], 'active' => $row['active'], 'lastLoginAt' => $row['lastLoginAt']];
            }
        }
        $smtp = null;
        if ($user['role'] === 'admin' || in_array('settings', $user['permissions'], true)) {
            $smtp = Rows::out('smtp_settings', DB::table('smtp_settings')->first());
            if ($smtp) $smtp['password'] = $smtp['password'] ? '********' : '';
        }
        return ['data' => $data, 'today' => gmdate('Y-m-d'), 'currentUser' => $user, 'users' => $users, 'smtp' => $smtp];
    }

    public function home()
    {
        $user = Auth::user();
        if (! $user) return redirect('/login');
        $boot = json_encode(self::bootData($user), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
        return response()->view('app', ['boot' => $boot]);
    }

    public function login()
    {
        if (Auth::user()) return redirect('/');
        return response()->view('login');
    }

    public function bootstrap()
    {
        $user = Auth::user();
        if (! $user) return response()->json(['error' => 'Please sign in to continue.'], 401);
        return response()->json(self::bootData($user));
    }

    /** loadSearchContext(checkIn, checkOut) — raw contract data for the in-browser engine. */
    public function searchContext(Request $r)
    {
        if (! Auth::user()) return response()->json(['error' => 'Please sign in to continue.'], 401);
        $in = (string) $r->query('checkIn');
        $out = (string) $r->query('checkOut');
        $ok = preg_match('/^\d{4}-\d{2}-\d{2}$/', $in) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $out);
        if (! $ok) { $in = gmdate('Y-m-d'); $out = gmdate('Y-m-d', time() + 86400); }
        $lastNight = gmdate('Y-m-d', strtotime($out.' 00:00:00 UTC') - 86400);

        $amen = [];
        foreach (DB::table('hotel_amenities')->join('amenities', 'amenities.id', '=', 'hotel_amenities.amenity_id')->where('amenities.active', 1)->get(['hotel_amenities.hotel_id', 'amenities.slug']) as $a) {
            $amen[(int) $a->hotel_id][] = $a->slug;
        }
        $locations = DB::table('locations')->pluck('name', 'id')->all();
        $hotels = [];
        foreach (DB::table('hotels')->where('active', 1)->get() as $h) {
            $row = Rows::out('hotels', $h);
            $row['location'] = $h->location_id ? ($locations[$h->location_id] ?? '') : '';
            $row['amenities'] = $amen[(int) $h->id] ?? [];
            $hotels[] = $row;
        }
        $bookings = [];
        foreach (DB::table('bookings')->where('status', '!=', 'cancelled')->where('check_in', '<', $out)->where('check_out', '>', $in)->get(['room_type_id', 'check_in', 'check_out', 'rooms', 'status']) as $b) {
            $bookings[] = ['roomTypeId' => (int) $b->room_type_id, 'checkIn' => substr($b->check_in, 0, 10), 'checkOut' => substr($b->check_out, 0, 10), 'rooms' => (int) $b->rooms, 'status' => $b->status];
        }
        return response()->json([
            'hotels' => $hotels,
            'rooms' => Rows::outAll('room_types', DB::table('room_types')->where('active', 1)->get()),
            'occupancies' => Rows::all('occupancy_rules'),
            'bedding' => Rows::all('room_bedding'),
            'rates' => Rows::outAll('rate_periods', DB::table('rate_periods')->where('active', 1)->where('valid_from', '<=', $lastNight)->where('valid_to', '>=', $in)->get()),
            'blackouts' => Rows::outAll('blackout_dates', DB::table('blackout_dates')->where('start_date', '<=', $lastNight)->where('end_date', '>=', $in)->get()),
            'bookings' => $bookings,
        ]);
    }

    public function health()
    {
        $db = false;
        try { DB::select('select 1'); $db = true; } catch (\Throwable) {}
        return response()->json(['ok' => true, 'app' => 'Luxury Attractions Hotel Contracts', 'version' => trim((string) @file_get_contents(base_path('VERSION'))),
            'installed' => \App\Support\Installer::installed(), 'database' => $db, 'php' => PHP_VERSION, 'time' => gmdate('c')]);
    }
}
