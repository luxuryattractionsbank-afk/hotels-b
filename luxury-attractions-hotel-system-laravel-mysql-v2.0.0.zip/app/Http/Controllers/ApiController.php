<?php

namespace App\Http\Controllers;

use App\Support\Auth;
use App\Support\Rows;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

/**
 * Line-by-line PHP port of every src/app/api/<name>/route.ts in the original
 * luxury-attractions-hotel-system (Next.js). Same messages, status codes and JSON.
 */
class ApiController extends Controller
{
    /* ----------------------------- JS semantics ----------------------------- */

    private static function n($v): float
    {
        if (is_bool($v)) return $v ? 1 : 0;
        if (is_int($v) || is_float($v)) return is_nan((float) $v) ? 0 : (float) $v;
        if (is_string($v) && trim($v) !== '' && is_numeric(trim($v))) return (float) trim($v);
        return 0;
    }

    /** String(v || fallback) */
    private static function or($v, string $fallback = ''): string
    {
        if ($v === null || $v === false || $v === '' || $v === 0 || $v === 0.0 || $v === '0' && false) return $fallback;
        if ($v === true) return 'true';
        if (is_array($v)) return implode(',', $v);
        return (string) $v;
    }

    /** String(v ?? "") */
    private static function s($v): string
    {
        if ($v === null) return '';
        if (is_bool($v)) return $v ? 'true' : 'false';
        if (is_array($v)) return implode(',', $v);
        return (string) $v;
    }

    private static function truthy($v): bool
    {
        return ! ($v === null || $v === false || $v === 0 || $v === 0.0 || $v === '');
    }

    private static function fixed($v): string
    {
        return number_format((float) $v, 2, '.', '');
    }

    private static function round2($v): float
    {
        return round((float) $v, 2);
    }

    private static function body(Request $r): array
    {
        $data = json_decode($r->getContent() ?: '[]', true);
        return is_array($data) ? $data : [];
    }

    private static function json($data, int $status = 200)
    {
        return response()->json($data, $status);
    }

    private static function reference(string $prefix, int $digits): string
    {
        $ms = (string) (int) floor(microtime(true) * 1000);
        return $prefix.'-'.substr($ms, -$digits).'-'.random_int(10, 99);
    }

    private static function positiveId($v): ?int
    {
        $id = self::n($v);
        return ($id > 0 && floor($id) == $id) ? (int) $id : null;
    }

    private static function parseIds($v): ?array
    {
        if (! is_array($v)) return null;
        $ids = [];
        foreach ($v as $x) {
            $id = self::positiveId($x);
            if ($id === null) return null;
            $ids[] = $id;
        }
        return array_values(array_unique($ids));
    }

    private static function readContact($raw): array
    {
        $raw = is_array($raw) ? $raw : [];
        return [
            'name' => mb_substr(trim(self::s($raw['name'] ?? null)), 0, 160),
            'position' => mb_substr(trim(self::s($raw['position'] ?? null)), 0, 160),
            'email' => mb_substr(trim(self::s($raw['email'] ?? null)), 0, 240),
            'phone' => mb_substr(trim(self::s($raw['phone'] ?? null)), 0, 64),
            'businessCardLink' => mb_substr(trim(self::s($raw['businessCardLink'] ?? null)), 0, 1000),
            'whatsapp' => ($raw['whatsapp'] ?? null) === true,
            'telegram' => ($raw['telegram'] ?? null) === true,
            'viber' => ($raw['viber'] ?? null) === true,
            'otherContact' => mb_substr(trim(self::s($raw['otherContact'] ?? null)), 0, 300),
        ];
    }

    private static function slugify(string $value, int $len = 40): string
    {
        $s = preg_replace('/[^a-z0-9]+/', '_', strtolower(trim($value))) ?? '';
        return substr(trim($s, '_'), 0, $len);
    }

    private static function ensureContactAssignments(): void
    {
        $legacy = DB::table('hotel_contacts')->whereNotNull('hotel_id')->get(['id', 'hotel_id']);
        if ($legacy->isEmpty()) return;
        foreach ($legacy as $row) {
            if (! DB::table('hotel_contact_assignments')->where(['hotel_id' => $row->hotel_id, 'contact_id' => $row->id])->exists()) {
                Rows::insert('hotel_contact_assignments', ['hotelId' => $row->hotel_id, 'contactId' => $row->id]);
            }
        }
        DB::table('hotel_contacts')->whereNotNull('hotel_id')->update(['hotel_id' => null]);
    }

    private static function contactIdentity(array $c): string
    {
        $email = strtolower(trim($c['email']));
        if ($email) return 'email:'.$email;
        return 'person:'.strtolower(trim($c['name'])).'|'.preg_replace('/\D/', '', $c['phone']);
    }

    private static function groupContactCandidates(int $groupId, array $contacts, array $assignments, array $hotels): array
    {
        $groupHotelIds = [];
        foreach ($hotels as $h) if ($h['groupId'] === $groupId) $groupHotelIds[$h['id']] = true;
        $linked = [];
        foreach ($assignments as $a) if (isset($groupHotelIds[$a['hotelId']])) $linked[$a['contactId']] = true;
        $ordered = array_values(array_filter($contacts, fn ($c) => $c['groupId'] === $groupId || ($c['groupId'] === null && isset($linked[$c['id']]))));
        usort($ordered, fn ($a, $b) => ((int) ($b['groupId'] === $groupId) - (int) ($a['groupId'] === $groupId)) ?: ($a['id'] - $b['id']));
        $seen = [];
        $out = [];
        foreach ($ordered as $c) {
            $id = self::contactIdentity($c);
            if (isset($seen[$id])) continue;
            $seen[$id] = true;
            $out[] = $c;
        }
        return $out;
    }

    private static function pricing(float $hotelCost, float $tax, bool $includeTax, string $mode, $value, $nights, $rooms): array
    {
        $hotelCostTotal = self::round2($hotelCost);
        $tourismTaxAmount = self::round2($tax);
        $v = max(0, self::n($value));
        $markupAmount = self::round2($mode === 'percent' ? ($hotelCostTotal * $v) / 100 : $v);
        $quotedTotal = self::round2($hotelCostTotal + $markupAmount + ($includeTax ? $tourismTaxAmount : 0));
        $n = max(1, self::n($nights) ?: 1);
        $r = max(1, self::n($rooms) ?: 1);
        return [
            'includeTax' => $includeTax, 'markupMode' => $mode === 'amount' ? 'amount' : 'percent', 'markupValue' => $v,
            'hotelCostTotal' => $hotelCostTotal, 'markupAmount' => $markupAmount, 'tourismTaxAmount' => $tourismTaxAmount,
            'quotedTotal' => $quotedTotal, 'totalNights' => $n, 'totalRooms' => $r,
            'dailyTax' => self::round2($tourismTaxAmount / $n), 'dailyRate' => self::round2(($hotelCostTotal + $markupAmount) / $n / $r),
        ];
    }

    private static function commercial(array $b): array
    {
        $mode = self::s($b['markupMode'] ?? 'percent');
        return [
            'includeTax' => ! array_key_exists('includeTax', $b) || $b['includeTax'] === null ? true : self::truthy($b['includeTax']),
            'markupMode' => $mode === 'amount' ? 'amount' : 'percent',
            'markupValue' => max(0, self::n($b['markupValue'] ?? 0)),
        ];
    }

    private static function nightsBetween(string $in, string $out): int
    {
        return (int) round((strtotime($out.' 00:00:00 UTC') - strtotime($in.' 00:00:00 UTC')) / 86400);
    }

    /* --------------------------------- auth --------------------------------- */

    public function auth(Request $r)
    {
        try {
            $b = self::body($r);
            $action = self::or($b['action'] ?? null, 'login');
            if ($action === 'logout') {
                $r->session()->forget('uid');
                $r->session()->invalidate();
                return self::json(['ok' => true]);
            }
            if ($action === 'change-password') {
                $current = Auth::user();
                if (! $current) return self::json(['error' => 'Please sign in first.'], 401);
                $currentPassword = self::or($b['currentPassword'] ?? null);
                $newPassword = self::or($b['newPassword'] ?? null);
                if (mb_strlen($newPassword) < 8) return self::json(['error' => 'New password must be at least 8 characters.'], 400);
                $row = DB::table('users')->where('id', $current['id'])->first();
                if (! $row || ! Auth::verify($currentPassword, $row->password_hash)) return self::json(['error' => 'Your current password is incorrect.'], 400);
                DB::table('users')->where('id', $current['id'])->update(['password_hash' => Auth::hash($newPassword), 'must_change_password' => 0]);
                return self::json(['ok' => true]);
            }
            $email = strtolower(trim(self::or($b['email'] ?? null)));
            $password = self::or($b['password'] ?? null);
            if (! $email || $password === '') return self::json(['error' => 'Enter your email and password.'], 400);
            $row = DB::table('users')->where('email', $email)->first();
            if (! $row || ! (int) $row->active || ! Auth::verify($password, $row->password_hash)) return self::json(['error' => 'Incorrect email or password.'], 401);
            $r->session()->regenerate();
            $r->session()->put('uid', (int) $row->id);
            DB::table('users')->where('id', $row->id)->update(['last_login_at' => Rows::now()]);
            return self::json(['ok' => true, 'mustChangePassword' => (bool) (int) $row->must_change_password]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Sign in failed. Please try again.'], 500);
        }
    }

    /* --------------------------------- users -------------------------------- */

    public function usersPost(Request $r)
    {
        [$user, $err] = Auth::guard('users');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $email = strtolower(trim(self::or($b['email'] ?? null)));
            $name = trim(self::or($b['name'] ?? null));
            $password = self::or($b['password'] ?? null);
            $role = self::or($b['role'] ?? null, 'agent');
            if (! $email || ! $name) return self::json(['error' => 'Name and email are required.'], 400);
            if (mb_strlen($password) < 8) return self::json(['error' => 'Password must be at least 8 characters.'], 400);
            if (! isset(Auth::ROLE_PRESETS[$role])) return self::json(['error' => 'Choose a valid role.'], 400);
            if (DB::table('users')->where('email', $email)->exists()) return self::json(['error' => 'A user with that email already exists.'], 409);
            $perms = is_array($b['permissions'] ?? null) && count($b['permissions']) > 0 ? $b['permissions'] : Auth::ROLE_PRESETS[$role];
            $created = Rows::insert('users', [
                'email' => $email, 'name' => $name, 'passwordHash' => Auth::hash($password), 'role' => $role,
                'permissions' => Auth::serialise($perms), 'phone' => self::or($b['phone'] ?? null), 'active' => true,
                'mustChangePassword' => ($b['mustChangePassword'] ?? null) !== false,
            ]);
            return self::json(['user' => ['id' => $created['id'], 'email' => $created['email'], 'name' => $created['name'], 'role' => $created['role']]], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to create this user.'], 400);
        }
    }

    public function usersPatch(Request $r)
    {
        [$user, $err] = Auth::guard('users');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            if (! $id) return self::json(['error' => 'User id is required.'], 400);
            $target = DB::table('users')->where('id', $id)->first();
            if (! $target) return self::json(['error' => 'User not found.'], 404);
            $patch = [];
            if (array_key_exists('name', $b)) $patch['name'] = trim(self::s($b['name']));
            if (array_key_exists('phone', $b)) $patch['phone'] = self::s($b['phone']);
            if (array_key_exists('role', $b) && isset(Auth::ROLE_PRESETS[self::s($b['role'])])) $patch['role'] = self::s($b['role']);
            if (is_array($b['permissions'] ?? null)) $patch['permissions'] = Auth::serialise($b['permissions']);
            if (array_key_exists('active', $b)) {
                if (! self::truthy($b['active']) && $target->role === 'admin') {
                    if (DB::table('users')->where('role', 'admin')->count() <= 1) return self::json(['error' => 'You cannot disable the last administrator.'], 400);
                }
                $patch['active'] = self::truthy($b['active']);
            }
            if (array_key_exists('password', $b) && mb_strlen(self::s($b['password'])) > 0) {
                $password = self::s($b['password']);
                if (mb_strlen($password) < 8) return self::json(['error' => 'Password must be at least 8 characters.'], 400);
                $patch['passwordHash'] = Auth::hash($password);
                $patch['mustChangePassword'] = true;
            }
            $u = Rows::update('users', $id, $patch);
            return self::json(['user' => ['id' => $u['id'], 'name' => $u['name'], 'role' => $u['role']]]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to update this user.'], 400);
        }
    }

    public function usersDelete(Request $r)
    {
        [$user, $err] = Auth::guard('users');
        if ($err) return $err;
        try {
            $id = (int) self::n($r->query('id'));
            if (! $id) return self::json(['error' => 'User id is required.'], 400);
            if ($user && $id === $user['id']) return self::json(['error' => 'You cannot delete your own account.'], 400);
            $target = DB::table('users')->where('id', $id)->first();
            if (! $target) return self::json(['error' => 'User not found.'], 404);
            if ($target->role === 'admin' && DB::table('users')->where('role', 'admin')->count() <= 1) {
                return self::json(['error' => 'You cannot delete the last administrator.'], 400);
            }
            DB::table('users')->where('id', $id)->delete();
            return self::json(['ok' => true]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to delete this user.'], 400);
        }
    }

    /* --------------------------------- email -------------------------------- */

    private static function smtpRow(): ?array
    {
        return Rows::out('smtp_settings', DB::table('smtp_settings')->first());
    }

    private static function mailer(array $s)
    {
        $scheme = $s['secure'] ? 'smtps' : 'smtp';
        $dsn = sprintf('%s://%s:%s@%s:%d', $scheme, rawurlencode($s['username']), rawurlencode((string) $s['password']), $s['host'], $s['port']);
        if (! $s['username']) $dsn = sprintf('%s://%s:%d', $scheme, $s['host'], $s['port']);
        return new \Symfony\Component\Mailer\Mailer(\Symfony\Component\Mailer\Transport::fromDsn($dsn));
    }

    public function emailPut(Request $r)
    {
        [, $err] = Auth::guard('settings');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $existing = self::smtpRow();
            $values = [
                'host' => trim(self::or($b['host'] ?? null)),
                'port' => max(1, (int) (self::n($b['port'] ?? null) ?: 587)),
                'secure' => self::truthy($b['secure'] ?? null),
                'username' => trim(self::or($b['username'] ?? null)),
                'password' => self::or($b['password'] ?? null) ?: ($existing['password'] ?? ''),
                'fromName' => trim(self::or($b['fromName'] ?? null, 'Luxury Attractions')),
                'fromEmail' => trim(self::or($b['fromEmail'] ?? null)),
                'replyTo' => trim(self::or($b['replyTo'] ?? null)),
                'bccSelf' => self::truthy($b['bccSelf'] ?? null),
                'active' => self::truthy($b['active'] ?? null),
                'updatedAt' => '__now',
            ];
            if (! $values['host'] || ! $values['fromEmail']) return self::json(['error' => 'SMTP host and the from-address are required.'], 400);
            $saved = $existing ? Rows::update('smtp_settings', $existing['id'], $values) : Rows::insert('smtp_settings', $values);
            $saved['password'] = $saved['password'] ? '********' : '';
            return self::json(['settings' => $saved]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save SMTP settings.'], 400);
        }
    }

    public function emailPost(Request $r)
    {
        [$user, $err] = Auth::guard('send_email');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $s = self::smtpRow();
            if (! $s || ! $s['active'] || ! $s['host']) return self::json(['error' => 'Email is not configured yet. Add SMTP details in Settings first.'], 400);
            $mailer = self::mailer($s);
            $from = new \Symfony\Component\Mime\Address($s['fromEmail'], $s['fromName']);
            if (($b['action'] ?? null) === 'test') {
                $to = self::or($b['to'] ?? null, $user['email'] ?? $s['fromEmail']);
                $mailer->send((new \Symfony\Component\Mime\Email())->from($from)->to($to)->subject('Luxury Attractions — SMTP test')
                    ->text('Your SMTP settings are working. Quotations and trip packages can now be emailed from the system.'));
                return self::json(['ok' => true, 'message' => "Test email sent to {$to}."]);
            }
            $to = trim(self::or($b['to'] ?? null));
            $subject = trim(self::or($b['subject'] ?? null));
            $message = trim(self::or($b['message'] ?? null));
            if (! $to || ! $subject) return self::json(['error' => 'Recipient and subject are required.'], 400);
            $paras = implode('', array_map(fn ($l) => '<p style="margin:0 0 10px">'.($l === '' ? '&nbsp;' : $l).'</p>', explode("\n", $message)));
            $html = '<div style="font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:14px;color:#1e293b;line-height:1.6">'.$paras
                .'<hr style="border:none;border-top:1px solid #e2e8f0;margin:18px 0" /><p style="margin:0;font-size:12px;color:#64748b"><b style="color:#174e48">Luxury Attractions</b><br/>hotels.luxuryattractions.com</p></div>';
            $mail = (new \Symfony\Component\Mime\Email())->from($from)->to(...array_map('trim', explode(',', $to)))->subject($subject)->text($message)->html($html);
            if ($cc = self::or($b['cc'] ?? null)) $mail->cc(...array_map('trim', explode(',', $cc)));
            if ($s['bccSelf']) $mail->bcc($s['fromEmail']);
            if ($s['replyTo']) $mail->replyTo($s['replyTo']);
            if (self::truthy($b['pdfBase64'] ?? null) && self::truthy($b['fileName'] ?? null)) {
                $base64 = preg_replace('/^data:application\/pdf;base64,/', '', self::s($b['pdfBase64']));
                $mail->attach(base64_decode($base64), self::s($b['fileName']), 'application/pdf');
            }
            $mailer->send($mail);
            return self::json(['ok' => true, 'message' => "Email sent to {$to}."]);
        } catch (\Throwable $e) {
            return self::json(['error' => 'Email failed: '.$e->getMessage()], 502);
        }
    }

    /* --------------------------------- hotels ------------------------------- */

    public function hotelsPost(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            self::ensureContactAssignments();
            $b = self::body($r);
            $name = trim(self::s($b['name'] ?? null));
            $city = trim(self::s($b['city'] ?? null));
            $supplierCode = strtoupper(trim(self::s($b['supplierCode'] ?? null)));
            if (! $name || ! $city || ! $supplierCode) return self::json(['error' => 'Hotel name, city, and supplier code are required.'], 400);
            $rawAmenityIds = ! array_key_exists('amenityIds', $b) ? [] : self::parseIds($b['amenityIds']);
            $selectedIds = ! array_key_exists('includedContactIds', $b) ? null : self::parseIds($b['includedContactIds']);
            if ($rawAmenityIds === null || (array_key_exists('includedContactIds', $b) && $selectedIds === null)) {
                return self::json(['error' => 'Invalid amenity or shared contact selection.'], 400);
            }
            $requestedGroupId = self::truthy($b['groupId'] ?? null) ? self::n($b['groupId']) : null;
            if ($requestedGroupId !== null && ($requestedGroupId < 1 || floor($requestedGroupId) != $requestedGroupId)) return self::json(['error' => 'Choose a valid umbrella company.'], 400);
            $requestedGroupId = $requestedGroupId !== null ? (int) $requestedGroupId : null;
            $newGroup = is_array($b['newGroup'] ?? null) ? $b['newGroup'] : null;
            $groupName = trim(self::s($newGroup['name'] ?? null));
            if ($requestedGroupId && $groupName) return self::json(['error' => 'Choose an existing group or create a new one, not both.'], 400);
            if ($newGroup && ! $groupName) return self::json(['error' => 'Enter the new umbrella company name.'], 400);
            $newContacts = [];
            foreach ((is_array($b['contacts'] ?? null) ? $b['contacts'] : []) as $value) {
                $c = self::readContact($value) + ['addToGroup' => is_array($value) && ($value['addToGroup'] ?? null) === true];
                if ($c['name'] !== '') $newContacts[] = $c;
            }
            foreach ($newContacts as $c) {
                if ($c['addToGroup'] && ! $requestedGroupId && ! $groupName) return self::json(['error' => 'Choose an umbrella company before adding a contact to it.'], 400);
            }

            $result = DB::transaction(function () use ($b, $name, $city, $supplierCode, $rawAmenityIds, $selectedIds, $requestedGroupId, $newGroup, $groupName, $newContacts) {
                $groupId = $requestedGroupId;
                if ($groupName) {
                    if (DB::table('hotel_groups')->whereRaw('LOWER(name) = ?', [strtolower($groupName)])->exists()) throw new InputError('That umbrella company already exists. Select it from the list instead.');
                    $created = Rows::insert('hotel_groups', ['name' => mb_substr($groupName, 0, 160), 'website' => mb_substr(trim(self::s($newGroup['website'] ?? null)), 0, 1000), 'notes' => mb_substr(trim(self::s($newGroup['notes'] ?? null)), 0, 1000)]);
                    $groupId = $created['id'];
                } elseif ($groupId) {
                    if (! DB::table('hotel_groups')->where('id', $groupId)->exists()) throw new InputError('The selected umbrella company no longer exists.');
                }
                if ($rawAmenityIds && count($rawAmenityIds) > 0) {
                    if (DB::table('amenities')->whereIn('id', $rawAmenityIds)->count() !== count($rawAmenityIds)) throw new InputError('One or more selected amenities are no longer available.');
                }
                $inheritedIds = [];
                if ($groupId && ! $groupName) {
                    $candidates = self::groupContactCandidates($groupId, Rows::all('hotel_contacts'), Rows::all('hotel_contact_assignments'), Rows::all('hotels'));
                    $allowed = array_column($candidates, 'id');
                    $inheritedIds = $selectedIds ?? $allowed;
                    foreach ($inheritedIds as $id) if (! in_array($id, $allowed, true)) throw new InputError('A selected shared contact does not belong to this umbrella company.');
                } elseif ($selectedIds && count($selectedIds) > 0) {
                    throw new InputError('Shared contacts can only be selected for an existing umbrella company.');
                }
                $locationId = self::n($b['locationId'] ?? null) > 0 ? (int) self::n($b['locationId']) : null;
                $newLocationName = trim(self::s($b['newLocationName'] ?? null));
                if ($locationId) {
                    $existing = DB::table('locations')->where('id', $locationId)->first();
                    if (! $existing) throw new InputError('The selected location no longer exists.');
                    if (strtolower($existing->city) !== strtolower($city)) throw new InputError('That location belongs to a different city/emirate.');
                } elseif ($newLocationName) {
                    $locationId = self::upsertLocation($city, mb_substr($newLocationName, 0, 120))['id'];
                }
                $hotel = Rows::insert('hotels', [
                    'name' => $name, 'city' => $city, 'locationId' => $locationId, 'supplierCode' => $supplierCode,
                    'country' => self::or($b['country'] ?? null, 'United Arab Emirates'), 'address' => self::or($b['address'] ?? null),
                    'businessType' => self::or($b['businessType'] ?? null, 'Hotel'), 'groupId' => $groupId,
                    'website' => self::or($b['website'] ?? null), 'contractsFolderLink' => self::or($b['contractsFolderLink'] ?? null),
                    'mediaLink' => self::or($b['mediaLink'] ?? null), 'starRating' => max(1, min(5, (int) (self::n($b['starRating'] ?? null) ?: 5))),
                    'contactEmail' => self::or($b['contactEmail'] ?? null), 'contactPhone' => self::or($b['contactPhone'] ?? null),
                    'checkInTime' => self::or($b['checkInTime'] ?? null, '15:00'), 'checkOutTime' => self::or($b['checkOutTime'] ?? null, '12:00'),
                    'tourismTax' => (string) max(0, self::n($b['tourismTax'] ?? null)), 'tourismTaxBasis' => self::or($b['tourismTaxBasis'] ?? null, 'room_night'),
                ]);
                foreach ($rawAmenityIds ?: [] as $amenityId) Rows::insert('hotel_amenities', ['hotelId' => $hotel['id'], 'amenityId' => $amenityId]);
                foreach ($inheritedIds as $contactId) Rows::insert('hotel_contact_assignments', ['hotelId' => $hotel['id'], 'contactId' => $contactId]);
                foreach ($newContacts as $contact) {
                    $addToGroup = $contact['addToGroup'];
                    unset($contact['addToGroup']);
                    $created = Rows::insert('hotel_contacts', $contact + ['groupId' => $addToGroup ? $groupId : null]);
                    Rows::insert('hotel_contact_assignments', ['hotelId' => $hotel['id'], 'contactId' => $created['id']]);
                }
                return ['hotel' => $hotel, 'inheritedCount' => count($inheritedIds), 'contactsCreated' => count($newContacts), 'groupId' => $groupId];
            });
            return self::json($result, 201);
        } catch (InputError $e) {
            return self::json(['error' => $e->getMessage()], 400);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => Rows::isUnique($e) ? 'That supplier code or umbrella company name is already in use.' : 'Unable to save this hotel.'], 409);
        }
    }

    private static function upsertLocation(string $city, string $name): array
    {
        $row = DB::table('locations')->where('city', $city)->where('name', $name)->first();
        if ($row) {
            DB::table('locations')->where('id', $row->id)->update(['active' => 1]);
            return Rows::find('locations', $row->id);
        }
        return Rows::insert('locations', ['city' => $city, 'name' => $name]);
    }

    /* ---------------------------------- rooms ------------------------------- */

    private const BEDDING_KINDS = [
        ['extra_bed', 'Extra bed', 'extraBedMax', 'extraBedFree', 'extraBedRate'],
        ['sofa_bed', 'Sofa bed', 'sofaBedMax', 'sofaBedFree', 'sofaBedRate'],
        ['baby_cot', 'Baby cot', 'babyCotMax', 'babyCotFree', 'babyCotRate'],
    ];

    public function roomsPost(Request $r)
    {
        [, $err] = Auth::guard('rooms');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $duplicateFrom = (int) self::n($b['duplicateFrom'] ?? null);
            if ($duplicateFrom > 0) {
                $source = Rows::find('room_types', $duplicateFrom);
                if (! $source) return self::json(['error' => 'Room type to duplicate was not found.'], 404);
                $codes = DB::table('room_types')->where('hotel_id', $source['hotelId'])->pluck('code')->all();
                $suffix = 2;
                $next = $source['code'].'-'.$suffix;
                while (in_array($next, $codes, true) && $suffix < 99) { $suffix++; $next = $source['code'].'-'.$suffix; }
                $room = Rows::insert('room_types', [
                    'hotelId' => $source['hotelId'], 'name' => $source['name'].' (copy)', 'code' => $next, 'category' => $source['category'],
                    'description' => $source['description'], 'maxAdults' => $source['maxAdults'], 'maxChildren' => $source['maxChildren'],
                    'maxInfants' => $source['maxInfants'], 'includedAdults' => $source['includedAdults'], 'baseSleeps' => $source['baseSleeps'],
                    'defaultInventory' => $source['defaultInventory'], 'extraBedAllowed' => $source['extraBedAllowed'], 'mediaLink' => $source['mediaLink'],
                ]);
                foreach (Rows::outAll('occupancy_rules', DB::table('occupancy_rules')->where('room_type_id', $source['id'])->get()) as $o) {
                    Rows::insert('occupancy_rules', ['roomTypeId' => $room['id'], 'adults' => $o['adults'], 'children' => $o['children'], 'infants' => $o['infants'], 'extraBeds' => $o['extraBeds'], 'label' => $o['label']]);
                }
                foreach (Rows::outAll('room_bedding', DB::table('room_bedding')->where('room_type_id', $source['id'])->get()) as $x) {
                    Rows::insert('room_bedding', ['roomTypeId' => $room['id'], 'kind' => $x['kind'], 'label' => $x['label'], 'maxPerRoom' => $x['maxPerRoom'], 'free' => $x['free'], 'ratePerNight' => $x['ratePerNight'], 'perStay' => $x['perStay'], 'sortOrder' => $x['sortOrder']]);
                }
                return self::json(['room' => $room], 201);
            }
            $hotelId = (int) self::n($b['hotelId'] ?? null);
            $name = trim(self::s($b['name'] ?? null));
            $code = strtoupper(trim(self::s($b['code'] ?? null)));
            $category = trim(self::or($b['category'] ?? null));
            if (! $hotelId || ! $name || ! $code || ! $category) return self::json(['error' => 'Hotel, room name, code and category are required.'], 400);
            $maxAdults = max(1, (int) (self::n($b['maxAdults'] ?? null) ?: 2));
            $maxChildren = max(0, (int) self::n($b['maxChildren'] ?? null));
            $maxInfants = max(0, (int) self::n($b['maxInfants'] ?? null));
            $baseSleeps = max(1, (int) (self::n($b['baseSleeps'] ?? null) ?: 2));
            $room = Rows::insert('room_types', [
                'hotelId' => $hotelId, 'name' => $name, 'code' => $code, 'category' => $category, 'description' => self::or($b['description'] ?? null),
                'maxAdults' => $maxAdults, 'maxChildren' => $maxChildren, 'maxInfants' => $maxInfants,
                'includedAdults' => max(1, (int) (self::n($b['includedAdults'] ?? null) ?: 2)), 'baseSleeps' => $baseSleeps,
                'defaultInventory' => max(1, (int) (self::n($b['defaultInventory'] ?? null) ?: 1)),
                'extraBedAllowed' => self::n($b['extraBedMax'] ?? null) > 0, 'mediaLink' => self::or($b['mediaLink'] ?? null),
            ]);
            foreach (self::BEDDING_KINDS as $i => [$kind, $label, $maxKey, $freeKey, $rateKey]) {
                $max = max(0, (int) self::n($b[$maxKey] ?? null));
                if ($max === 0) continue;
                Rows::insert('room_bedding', [
                    'roomTypeId' => $room['id'], 'kind' => $kind, 'label' => self::or($b[$kind.'Label'] ?? null, $label), 'maxPerRoom' => $max,
                    'free' => self::truthy($b[$freeKey] ?? null), 'ratePerNight' => (string) max(0, self::n($b[$rateKey] ?? null)),
                    'perStay' => self::truthy($b[$kind.'PerStay'] ?? null), 'sortOrder' => ($i + 1) * 10,
                ]);
            }
            $occ = [];
            foreach ((is_array($b['occupancies'] ?? null) ? $b['occupancies'] : []) as $item) {
                $item = is_array($item) ? $item : [];
                $a = max(0, (int) floor(self::n($item['adults'] ?? null)));
                $c = max(0, (int) floor(self::n($item['children'] ?? null)));
                $in = max(0, (int) floor(self::n($item['infants'] ?? null)));
                $eb = max(0, (int) floor(self::n($item['extraBeds'] ?? null)));
                $lbl = trim(self::s($item['label'] ?? null));
                if ($a <= 0) continue;
                $occ[] = ['roomTypeId' => $room['id'], 'adults' => $a, 'children' => $c, 'infants' => $in, 'extraBeds' => $eb,
                    'label' => $lbl ?: $a.'A'.($c ? " + {$c}C" : '').($in ? " + {$in}I" : '').($eb ? " + {$eb} extra bed" : '')];
            }
            if (! $occ) {
                $occ = [
                    ['roomTypeId' => $room['id'], 'adults' => 1, 'children' => 0, 'infants' => 0, 'extraBeds' => 0, 'label' => 'Single use'],
                    ['roomTypeId' => $room['id'], 'adults' => min(2, $maxAdults), 'children' => 0, 'infants' => 0, 'extraBeds' => 0, 'label' => 'Double'],
                ];
                if ($maxChildren > 0) $occ[] = ['roomTypeId' => $room['id'], 'adults' => 1, 'children' => min(2, $maxChildren), 'infants' => 0, 'extraBeds' => 0, 'label' => '1 adult + 2 children'];
                if ($maxAdults > 2) $occ[] = ['roomTypeId' => $room['id'], 'adults' => $maxAdults, 'children' => 0, 'infants' => 0, 'extraBeds' => 0, 'label' => "{$maxAdults} adults"];
            }
            Rows::insertMany('occupancy_rules', $occ);
            return self::json(['room' => $room], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => Rows::isUnique($e) ? 'That room code already exists for this hotel.' : 'Unable to save this room type.'], 400);
        }
    }

    public function roomsPatch(Request $r)
    {
        [, $err] = Auth::guard('rooms');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            if (! $id) return self::json(['error' => 'Room type id is required.'], 400);
            $room = Rows::find('room_types', $id);
            if (! $room) return self::json(['error' => 'Room type not found.'], 404);
            $p = [];
            if (array_key_exists('defaultInventory', $b)) $p['defaultInventory'] = max(0, (int) floor(self::n($b['defaultInventory'])));
            if (array_key_exists('mediaLink', $b)) $p['mediaLink'] = self::or($b['mediaLink']);
            if (array_key_exists('maxAdults', $b)) $p['maxAdults'] = max(1, (int) (self::n($b['maxAdults']) ?: 1));
            if (array_key_exists('maxChildren', $b)) $p['maxChildren'] = max(0, (int) self::n($b['maxChildren']));
            if (array_key_exists('maxInfants', $b)) $p['maxInfants'] = max(0, (int) self::n($b['maxInfants']));
            if (array_key_exists('baseSleeps', $b)) $p['baseSleeps'] = max(1, (int) (self::n($b['baseSleeps']) ?: 1));
            if (array_key_exists('includedAdults', $b)) $p['includedAdults'] = max(1, (int) (self::n($b['includedAdults']) ?: 1));
            if (array_key_exists('name', $b)) $p['name'] = trim(self::s($b['name'])) ?: $room['name'];
            if (! $p) return self::json(['error' => 'Nothing to update.'], 400);
            return self::json(['room' => Rows::update('room_types', $id, $p)]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to update this room type.'], 400);
        }
    }

    /* ------------------------ rates, blackouts, lookups --------------------- */

    public function ratesPost(Request $r)
    {
        [, $err] = Auth::guard('rates');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $isDate = fn ($v) => (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', self::s($v));
            $hotelId = (int) self::n($b['hotelId'] ?? null);
            $roomTypeId = (int) self::n($b['roomTypeId'] ?? null);
            $validFrom = self::or($b['validFrom'] ?? null);
            $validTo = self::or($b['validTo'] ?? null);
            $name = trim(self::s($b['name'] ?? null));
            if (! $hotelId || ! $roomTypeId || ! $name || ! $validFrom || ! $validTo || $validTo < $validFrom) {
                return self::json(['error' => 'Hotel, room, rate name, and a valid date range are required.'], 400);
            }
            $bws = $isDate($b['bookingWindowStart'] ?? null) ? self::s($b['bookingWindowStart']) : null;
            $bwe = $isDate($b['bookingWindowEnd'] ?? null) ? self::s($b['bookingWindowEnd']) : null;
            if ($bws && $bwe && $bwe < $bws) return self::json(['error' => 'The booking window end must be after its start.'], 400);
            $req = self::or($b['market'] ?? null, 'all');
            $market = $req === 'all' || preg_match('/^[a-z0-9_]+$/', $req) ? $req : 'all';
            $ex = [];
            foreach ((is_array($b['marketExclusions'] ?? null) ? $b['marketExclusions'] : []) as $v) {
                $v = strtolower(trim(self::s($v)));
                if ($v !== 'all' && preg_match('/^[a-z0-9_]+$/', $v)) $ex[$v] = true;
            }
            $rate = Rows::insert('rate_periods', [
                'hotelId' => $hotelId, 'roomTypeId' => $roomTypeId, 'name' => $name, 'boardType' => self::or($b['boardType'] ?? null, 'breakfast'),
                'validFrom' => $validFrom, 'validTo' => $validTo, 'bookingWindowStart' => $bws, 'bookingWindowEnd' => $bwe,
                'market' => $market, 'marketExclusions' => implode(',', array_keys($ex)), 'promoCode' => trim(self::or($b['promoCode'] ?? null)),
                'baseRate' => (string) max(0, self::n($b['baseRate'] ?? null)), 'rateBasis' => self::or($b['rateBasis'] ?? null, 'room_night'),
                'boardAdultSupplement' => (string) max(0, self::n($b['boardAdultSupplement'] ?? null)),
                'boardChildSupplement' => (string) max(0, self::n($b['boardChildSupplement'] ?? null)),
                'boardSupplementBasis' => self::or($b['boardSupplementBasis'] ?? null, 'person_night'),
                'extraAdultRate' => (string) max(0, self::n($b['extraAdultRate'] ?? null)),
                'extraChildRate' => (string) max(0, self::n($b['extraChildRate'] ?? null)),
                'extraBedRate' => (string) max(0, self::n($b['extraBedRate'] ?? null)),
                'extraBedBasis' => self::or($b['extraBedBasis'] ?? null, 'bed_night'),
                'minimumNights' => max(1, (int) (self::n($b['minimumNights'] ?? null) ?: 1)),
            ]);
            return self::json(['rate' => $rate], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this rate plan.'], 400);
        }
    }

    public function blackoutsPost(Request $r)
    {
        [, $err] = Auth::guard('blackouts');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $hotelId = (int) self::n($b['hotelId'] ?? null);
            $start = self::or($b['startDate'] ?? null);
            $end = self::or($b['endDate'] ?? null);
            if (! $hotelId || ! $start || ! $end || $end < $start) return self::json(['error' => 'Hotel and a valid closure date range are required.'], 400);
            $blackout = Rows::insert('blackout_dates', [
                'hotelId' => $hotelId, 'roomTypeId' => self::truthy($b['roomTypeId'] ?? null) ? (int) self::n($b['roomTypeId']) : null,
                'startDate' => $start, 'endDate' => $end, 'reason' => self::or($b['reason'] ?? null, 'Sold out by hotel'),
            ]);
            return self::json(['blackout' => $blackout], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this closure period.'], 400);
        }
    }

    private static function upsertBySlug(string $table, string $slug, array $insert, array $update): array
    {
        $row = DB::table($table)->where('slug', $slug)->first();
        if ($row) return Rows::update($table, $row->id, $update);
        return Rows::insert($table, $insert + ['slug' => $slug]);
    }

    public function amenitiesPost(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $label = trim(self::s($b['label'] ?? null));
            if (! $label) return self::json(['error' => 'Give the amenity a name, e.g. Spa.'], 400);
            $slug = self::or($b['slug'] ?? null, self::slugify($label));
            if (! $slug) return self::json(['error' => 'Could not build a code for that amenity name.'], 400);
            $icon = in_array(self::s($b['icon'] ?? null), ['waves', 'umbrella', 'dumbbell', 'train', 'check'], true) ? self::s($b['icon']) : 'check';
            $amenity = self::upsertBySlug('amenities', $slug, ['label' => $label, 'icon' => $icon, 'sortOrder' => max(0, (int) (self::n($b['sortOrder'] ?? null) ?: 100))], ['label' => $label, 'icon' => $icon]);
            return self::json(['amenity' => $amenity], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this amenity.'], 400);
        }
    }

    public function hotelAmenitiesPost(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $hotelId = (int) self::n($b['hotelId'] ?? null);
            if (! $hotelId) return self::json(['error' => 'Choose a hotel first.'], 400);
            $ids = [];
            foreach ((is_array($b['amenityIds'] ?? null) ? $b['amenityIds'] : []) as $v) {
                $id = self::n($v);
                if ($id > 0 && floor($id) == $id) $ids[] = (int) $id;
            }
            DB::transaction(function () use ($hotelId, $ids) {
                DB::table('hotel_amenities')->where('hotel_id', $hotelId)->delete();
                foreach ($ids as $amenityId) Rows::insert('hotel_amenities', ['hotelId' => $hotelId, 'amenityId' => $amenityId]);
            });
            return self::json(['hotelId' => $hotelId, 'amenityIds' => $ids]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to update the hotel amenities.'], 400);
        }
    }

    public function roomCategoriesPost(Request $r)
    {
        [, $err] = Auth::guard('rooms');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $label = trim(self::s($b['label'] ?? null));
            if (! $label) return self::json(['error' => 'Give the category a name, e.g. Triple Room.'], 400);
            $slug = self::or($b['slug'] ?? null, self::slugify($label));
            if (! $slug) return self::json(['error' => 'Could not build a code for that category name.'], 400);
            $category = self::upsertBySlug('room_categories', $slug, ['label' => $label, 'sortOrder' => max(0, (int) (self::n($b['sortOrder'] ?? null) ?: 500))], ['label' => $label]);
            return self::json(['category' => $category], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this room category.'], 400);
        }
    }

    public function hotelGroupsPost(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $name = trim(self::s($b['name'] ?? null));
            if (! $name) return self::json(['error' => 'Enter the group or chain name.'], 400);
            $values = ['website' => self::or($b['website'] ?? null), 'notes' => self::or($b['notes'] ?? null)];
            $row = DB::table('hotel_groups')->where('name', $name)->first();
            $group = $row ? Rows::update('hotel_groups', $row->id, $values) : Rows::insert('hotel_groups', $values + ['name' => $name]);
            return self::json(['group' => $group], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this group.'], 400);
        }
    }

    public function marketsPost(Request $r)
    {
        [, $err] = Auth::guard('rates');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $label = trim(self::s($b['label'] ?? null));
            if (! $label) return self::json(['error' => 'Enter a market or nationality, e.g. DRC Nationals.'], 400);
            $slug = self::or($b['slug'] ?? null, self::slugify($label, 48));
            if (! preg_match('/^[a-z0-9_]+$/', $slug)) return self::json(['error' => 'Could not build a code for that name.'], 400);
            $market = self::upsertBySlug('markets', $slug, ['label' => $label, 'sortOrder' => max(0, (int) (self::n($b['sortOrder'] ?? null) ?: 200))], ['label' => $label, 'active' => true]);
            return self::json(['market' => $market], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this market.'], 400);
        }
    }

    private static function deleteById(Request $r, string $perm, string $table, string $label, string $fail)
    {
        [, $err] = Auth::guard($perm);
        if ($err) return $err;
        try {
            $id = (int) self::n($r->query('id'));
            if (! $id) return self::json(['error' => "{$label} id is required."], 400);
            DB::table($table)->where('id', $id)->delete();
            return self::json(['ok' => true]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => $fail], 400);
        }
    }

    public function marketsDelete(Request $r) { return self::deleteById($r, 'rates', 'markets', 'Market', 'Unable to delete this market. It may still be used by a rate line.'); }

    public function locationsPost(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $city = trim(self::s($b['city'] ?? null));
            $name = trim(self::s($b['name'] ?? null));
            if (! $city || ! $name) return self::json(['error' => 'Choose the city/emirate and enter the location name.'], 400);
            return self::json(['location' => self::upsertLocation(mb_substr($city, 0, 120), mb_substr($name, 0, 120))], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this location.'], 400);
        }
    }

    public function locationsDelete(Request $r) { return self::deleteById($r, 'hotels', 'locations', 'Location', 'Unable to delete this location.'); }

    public function occupancyPost(Request $r)
    {
        [, $err] = Auth::guard('rooms');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $roomTypeId = (int) self::n($b['roomTypeId'] ?? null);
            $a = max(1, (int) floor(self::n($b['adults'] ?? null) ?: 1));
            $c = max(0, (int) floor(self::n($b['children'] ?? null)));
            $in = max(0, (int) floor(self::n($b['infants'] ?? null)));
            $eb = max(0, (int) floor(self::n($b['extraBeds'] ?? null)));
            if (! $roomTypeId) return self::json(['error' => 'Choose a room type.'], 400);
            if (! DB::table('room_types')->where('id', $roomTypeId)->exists()) return self::json(['error' => 'Room type not found.'], 404);
            $label = trim(self::s($b['label'] ?? null)) ?: $a.'A'.($c ? " + {$c}C" : '').($in ? " + {$in}I" : '').($eb ? ' + extra bed' : '');
            $rule = Rows::insert('occupancy_rules', ['roomTypeId' => $roomTypeId, 'adults' => $a, 'children' => $c, 'infants' => $in, 'extraBeds' => $eb, 'label' => $label]);
            return self::json(['occupancy' => $rule], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this occupancy combination.'], 400);
        }
    }

    public function occupancyDelete(Request $r) { return self::deleteById($r, 'rooms', 'occupancy_rules', 'Occupancy', 'Unable to delete this occupancy combination.'); }

    /* -------------------------------- contacts ------------------------------ */

    private static function pruneContactIfUnused(int $id): void
    {
        $c = DB::table('hotel_contacts')->where('id', $id)->first(['group_id']);
        if (! $c || $c->group_id) return;
        if (! DB::table('hotel_contact_assignments')->where('contact_id', $id)->exists()) DB::table('hotel_contacts')->where('id', $id)->delete();
    }

    public function contactsPost(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            self::ensureContactAssignments();
            $b = self::body($r);
            $details = self::readContact($b);
            if (! $details['name']) return self::json(['error' => 'Contact name is required.'], 400);
            $hotelId = self::positiveId($b['hotelId'] ?? null);
            $explicitGroupId = self::positiveId($b['groupId'] ?? null);
            if (! $hotelId && ! $explicitGroupId) return self::json(['error' => 'Choose a hotel or umbrella company for this contact.'], 400);
            $selected = ! array_key_exists('hotelIds', $b) ? [] : self::parseIds($b['hotelIds']);
            if ($selected === null) return self::json(['error' => 'Invalid hotel selection.'], 400);
            $result = DB::transaction(function () use ($b, $details, $hotelId, $explicitGroupId, $selected) {
                $hotel = $hotelId ? DB::table('hotels')->where('id', $hotelId)->first(['id', 'group_id']) : null;
                if ($hotelId && ! $hotel) throw new InputError('That hotel no longer exists.');
                $hotelGroup = $hotel && $hotel->group_id ? (int) $hotel->group_id : null;
                $groupId = $hotelId ? (($b['addToGroup'] ?? null) === true ? $hotelGroup : null) : $explicitGroupId;
                if ($hotelId && ($b['addToGroup'] ?? null) === true && ! $groupId) throw new InputError('Assign this hotel to an umbrella company before sharing the contact with it.');
                if ($explicitGroupId && $hotel && $hotelGroup !== $explicitGroupId) throw new InputError('The selected hotel does not belong to that umbrella company.');
                if ($groupId && ! DB::table('hotel_groups')->where('id', $groupId)->exists()) throw new InputError('That umbrella company no longer exists.');
                $hotelIds = array_values(array_unique(array_merge($hotelId ? [$hotelId] : [], $selected)));
                if ($hotelIds && $groupId) {
                    if (DB::table('hotels')->whereIn('id', $hotelIds)->where('group_id', $groupId)->count() !== count($hotelIds)) throw new InputError('Select only hotels in this umbrella company.');
                } elseif (count($selected) > 0) {
                    throw new InputError('Choose an umbrella company before assigning this contact to multiple hotels.');
                }
                $contact = Rows::insert('hotel_contacts', $details + ['groupId' => $groupId]);
                foreach ($hotelIds as $id) Rows::insert('hotel_contact_assignments', ['contactId' => $contact['id'], 'hotelId' => $id]);
                return ['contact' => $contact, 'hotelIds' => $hotelIds];
            });
            return self::json($result, 201);
        } catch (InputError $e) {
            return self::json(['error' => $e->getMessage()], 400);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this contact.'], 400);
        }
    }

    public function contactsPatch(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            self::ensureContactAssignments();
            $b = self::body($r);
            $id = self::positiveId($b['id'] ?? null);
            if (! $id) return self::json(['error' => 'Contact id is required.'], 400);
            $result = DB::transaction(function () use ($b, $id) {
                $contact = Rows::find('hotel_contacts', $id);
                if (! $contact) throw new InputError('Contact not found.');
                if (array_key_exists('groupId', $b)) {
                    $groupId = $b['groupId'] === null ? null : self::positiveId($b['groupId']);
                    if ($b['groupId'] !== null && ! $groupId) throw new InputError('Choose a valid umbrella company.');
                    if ($groupId) {
                        if (! DB::table('hotel_groups')->where('id', $groupId)->exists()) throw new InputError('Umbrella company not found.');
                        if ($contact['groupId'] && $contact['groupId'] !== $groupId) throw new InputError('Remove this contact from its current group before sharing it with another.');
                        $links = DB::table('hotel_contact_assignments')->where('contact_id', $id)->pluck('hotel_id')->all();
                        if ($links && DB::table('hotels')->whereIn('id', $links)->where('group_id', $groupId)->count() !== count($links)) {
                            throw new InputError('This contact is used outside that umbrella company. Remove the other hotel assignments first.');
                        }
                    } elseif (! $contact['groupId']) {
                        throw new InputError('This contact is not shared with a group.');
                    }
                    DB::table('hotel_contacts')->where('id', $id)->update(['group_id' => $groupId]);
                    if (! $groupId) self::pruneContactIfUnused($id);
                    return ['ok' => true, 'contactId' => $id, 'groupId' => $groupId];
                }
                $hotelId = self::positiveId($b['hotelId'] ?? null);
                if (! $hotelId || ! is_bool($b['attached'] ?? null)) throw new InputError('Choose a hotel and an assignment action.');
                $hotel = DB::table('hotels')->where('id', $hotelId)->first(['id', 'group_id']);
                if (! $hotel) throw new InputError('Hotel not found.');
                $hotelGroup = $hotel->group_id ? (int) $hotel->group_id : null;
                if ($b['attached']) {
                    if (! $hotelGroup) throw new InputError('The hotel must belong to an umbrella company to reuse a shared contact.');
                    if ($contact['groupId'] && $contact['groupId'] !== $hotelGroup) throw new InputError('This contact belongs to another umbrella company.');
                    $sibling = DB::table('hotel_contact_assignments')->join('hotels', 'hotel_contact_assignments.hotel_id', '=', 'hotels.id')
                        ->where('hotel_contact_assignments.contact_id', $id)->where('hotels.group_id', $hotelGroup)->exists();
                    if ($contact['groupId'] !== $hotelGroup && ! $sibling) throw new InputError('That contact does not belong to this umbrella company or one of its hotels.');
                    if (! DB::table('hotel_contact_assignments')->where(['contact_id' => $id, 'hotel_id' => $hotelId])->exists()) {
                        Rows::insert('hotel_contact_assignments', ['contactId' => $id, 'hotelId' => $hotelId]);
                    }
                } else {
                    $removed = DB::table('hotel_contact_assignments')->where(['hotel_id' => $hotelId, 'contact_id' => $id])->delete();
                    if (! $removed) throw new InputError('The contact is not assigned to this hotel.');
                    self::pruneContactIfUnused($id);
                }
                return ['ok' => true, 'contactId' => $id, 'hotelId' => $hotelId, 'attached' => $b['attached']];
            });
            return self::json($result);
        } catch (InputError $e) {
            return self::json(['error' => $e->getMessage()], 400);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to update this contact.'], 400);
        }
    }

    public function contactsDelete(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            self::ensureContactAssignments();
            $id = self::positiveId($r->query('id'));
            $hotelId = self::positiveId($r->query('hotelId'));
            $groupId = self::positiveId($r->query('groupId'));
            if (! $id || ((int) (bool) $hotelId + (int) (bool) $groupId) !== 1) {
                return self::json(['error' => 'Choose exactly one hotel or umbrella company to remove the contact from.'], 400);
            }
            $result = DB::transaction(function () use ($id, $hotelId, $groupId) {
                if ($hotelId) {
                    $removed = DB::table('hotel_contact_assignments')->where(['hotel_id' => $hotelId, 'contact_id' => $id])->delete();
                    if (! $removed) throw new InputError('The contact is not assigned to this hotel.');
                    self::pruneContactIfUnused($id);
                    return ['ok' => true, 'removedFrom' => 'hotel', 'hotelId' => $hotelId, 'contactId' => $id];
                }
                $c = DB::table('hotel_contacts')->where('id', $id)->first(['group_id']);
                if (! $c || (int) $c->group_id !== $groupId) throw new InputError('The contact is not shared with this umbrella company.');
                DB::table('hotel_contacts')->where('id', $id)->update(['group_id' => null]);
                self::pruneContactIfUnused($id);
                return ['ok' => true, 'removedFrom' => 'group', 'groupId' => $groupId, 'contactId' => $id];
            });
            return self::json($result);
        } catch (InputError $e) {
            return self::json(['error' => $e->getMessage()], 400);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to remove this contact.'], 400);
        }
    }

    /* ----------------------------- services & tours ------------------------- */

    public function servicesGet() { return self::json(['services' => Rows::all('services')]); }

    public function servicesPost(Request $r)
    {
        [, $err] = Auth::guard('catalog');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $name = trim(self::s($b['name'] ?? null));
            if (! $name) return self::json(['error' => 'Service name is required.'], 400);
            $service = Rows::insert('services', [
                'name' => $name, 'kind' => in_array(self::s($b['kind'] ?? null), ['shared_transfer', 'private_transfer', 'other'], true) ? self::s($b['kind']) : 'shared_transfer',
                'vehicleType' => self::or($b['vehicleType'] ?? null), 'priceMode' => ($b['priceMode'] ?? null) === 'per_vehicle' ? 'per_vehicle' : 'per_person',
                'oneWayPrice' => (string) max(0, self::n($b['oneWayPrice'] ?? null)), 'twoWayPrice' => (string) max(0, self::n($b['twoWayPrice'] ?? null)),
                'details' => self::or($b['details'] ?? null),
            ]);
            return self::json(['service' => $service], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this service.'], 400);
        }
    }

    public function servicesDelete(Request $r) { return self::deleteById($r, 'catalog', 'services', 'Service', 'Unable to delete this service.'); }

    public function toursGet() { return self::json(['tours' => Rows::all('tours')]); }

    public function toursPost(Request $r)
    {
        [, $err] = Auth::guard('catalog');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $name = trim(self::s($b['name'] ?? null));
            if (! $name) return self::json(['error' => 'Tour / ticket name is required.'], 400);
            $tour = Rows::insert('tours', [
                'name' => $name, 'category' => self::s($b['category'] ?? null) === 'ticket' ? 'ticket' : 'tour',
                'ticketOnlyPrice' => (string) max(0, self::n($b['ticketOnlyPrice'] ?? null)),
                'sharedTransferPrice' => (string) max(0, self::n($b['sharedTransferPrice'] ?? null)),
                'privateTransferPrice' => (string) max(0, self::n($b['privateTransferPrice'] ?? null)),
                'details' => self::or($b['details'] ?? null),
            ]);
            return self::json(['tour' => $tour], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save this tour / ticket.'], 400);
        }
    }

    public function toursDelete(Request $r) { return self::deleteById($r, 'catalog', 'tours', 'Tour', 'Unable to delete this tour / ticket.'); }

    /* -------------------------------- quotations ---------------------------- */

    public function quotationsGet(Request $r)
    {
        try {
            $id = (int) self::n($r->query('id'));
            if ($id) {
                $quote = Rows::find('quotations', $id);
                if (! $quote) return self::json(['error' => 'Quotation not found.'], 404);
                $items = Rows::outAll('quotation_items', DB::table('quotation_items')->where('quotation_id', $id)->orderBy('sort_order')->orderBy('check_in')->get());
                return self::json(['quotation' => $quote, 'items' => $items]);
            }
            return self::json(['quotations' => Rows::all('quotations', ['created_at' => 'desc']), 'items' => Rows::all('quotation_items', ['sort_order' => 'asc'])]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Failed to load quotations.'], 500);
        }
    }

    private const ITEM_COPY = ['hotelId', 'roomTypeId', 'ratePeriodId', 'boardType', 'checkIn', 'checkOut', 'nights', 'adults', 'children', 'infants', 'rooms', 'extraBeds', 'sofaBeds', 'babyCots', 'baseAmount', 'boardAmount', 'occupancyAmount', 'extraBedAmount', 'tourismTaxAmount', 'totalAmount', 'rateNames', 'promoCodes', 'notes'];

    private static function validateStayItems(array $rawItems, bool $strict): array
    {
        $sum = ['base' => 0, 'board' => 0, 'occ' => 0, 'bed' => 0, 'tax' => 0, 'total' => 0, 'nights' => 0];
        $items = [];
        foreach ($rawItems as $idx => $it) {
            $it = is_array($it) ? $it : [];
            $hotelId = (int) self::n($it['hotelId'] ?? null);
            $roomTypeId = (int) self::n($it['roomTypeId'] ?? null);
            if ($strict && (! $hotelId || ! $roomTypeId)) throw new InputError('Each stay item requires a valid hotel and room type.');
            $in = self::or($it['checkIn'] ?? null);
            $out = self::or($it['checkOut'] ?? null);
            if ($strict && (! $in || ! $out || $out <= $in)) throw new InputError('Invalid check-in/check-out dates for stay item.');
            $nights = (int) (self::n($it['nights'] ?? null) ?: ($in && $out ? self::nightsBetween($in, $out) : 0));
            $base = self::n($it['baseAmount'] ?? null); $board = self::n($it['boardAmount'] ?? null); $occ = self::n($it['occupancyAmount'] ?? null);
            $bed = self::n($it['extraBedAmount'] ?? null); $tax = self::n($it['tourismTaxAmount'] ?? null);
            $total = self::n($it['totalAmount'] ?? null) ?: ($base + $board + $occ + $bed + $tax);
            $sum['base'] += $base; $sum['board'] += $board; $sum['occ'] += $occ; $sum['bed'] += $bed; $sum['tax'] += $tax; $sum['total'] += $total; $sum['nights'] += $nights;
            $items[] = [
                'sortOrder' => $idx, 'hotelId' => $hotelId, 'roomTypeId' => $roomTypeId,
                'ratePeriodId' => self::truthy($it['ratePeriodId'] ?? null) ? (int) self::n($it['ratePeriodId']) : null,
                'boardType' => self::or($it['boardType'] ?? null, 'breakfast'), 'checkIn' => $in, 'checkOut' => $out, 'nights' => $nights,
                'adults' => max(1, (int) (self::n($it['adults'] ?? null) ?: 2)), 'children' => max(0, (int) self::n($it['children'] ?? null)),
                'infants' => max(0, (int) self::n($it['infants'] ?? null)), 'rooms' => max(1, (int) (self::n($it['rooms'] ?? null) ?: 1)),
                'extraBeds' => max(0, (int) self::n($it['extraBeds'] ?? null)), 'sofaBeds' => max(0, (int) self::n($it['sofaBeds'] ?? null)),
                'babyCots' => max(0, (int) self::n($it['babyCots'] ?? null)),
                'baseAmount' => self::fixed($base), 'boardAmount' => self::fixed($board), 'occupancyAmount' => self::fixed($occ),
                'extraBedAmount' => self::fixed($bed), 'tourismTaxAmount' => self::fixed($tax), 'totalAmount' => self::fixed($total),
                'rateNames' => self::or($it['rateNames'] ?? null), 'promoCodes' => self::or($it['promoCodes'] ?? null), 'notes' => self::or($it['notes'] ?? null),
            ];
        }
        return [$items, $sum];
    }

    public function quotationsPost(Request $r)
    {
        [, $err] = Auth::guard('quotations');
        if ($err) return $err;
        try {
            $b = self::body($r);
            if (is_array($b['combineQuotationIds'] ?? null) && count($b['combineQuotationIds']) >= 2) {
                $ids = array_values(array_filter(array_map(fn ($v) => (int) self::n($v), $b['combineQuotationIds']), fn ($v) => $v > 0));
                $sourceQuotes = Rows::outAll('quotations', DB::table('quotations')->whereIn('id', $ids)->get());
                $sourceItems = Rows::outAll('quotation_items', DB::table('quotation_items')->whereIn('quotation_id', $ids)->orderBy('check_in')->get());
                if (count($sourceQuotes) < 2 || ! $sourceItems) return self::json(['error' => 'Select at least 2 valid quotations to combine.'], 400);
                $q0 = $sourceQuotes[0];
                $sum = ['base' => 0, 'board' => 0, 'occ' => 0, 'bed' => 0, 'tax' => 0, 'nights' => 0, 'rooms' => 0];
                foreach ($sourceItems as $it) {
                    $sum['base'] += self::n($it['baseAmount']); $sum['board'] += self::n($it['boardAmount']); $sum['occ'] += self::n($it['occupancyAmount']);
                    $sum['bed'] += self::n($it['extraBedAmount']); $sum['tax'] += self::n($it['tourismTaxAmount']); $sum['nights'] += $it['nights'] ?: 0; $sum['rooms'] += $it['rooms'] ?: 1;
                }
                $c = self::commercial($b);
                $p = self::pricing($sum['base'] + $sum['board'] + $sum['occ'] + $sum['bed'], $sum['tax'], $c['includeTax'], $c['markupMode'], $c['markupValue'], $sum['nights'], $sum['rooms'] ?: 1);
                $result = DB::transaction(function () use ($b, $q0, $sourceQuotes, $sourceItems, $sum, $p) {
                    $quote = Rows::insert('quotations', [
                        'reference' => self::reference('LAQ', 6), 'title' => trim(self::or($b['title'] ?? null, 'Combined Itinerary ('.count($sourceItems).' stays)')),
                        'clientName' => trim(self::or($b['clientName'] ?? null, $q0['clientName'] ?: 'Combined Itinerary Client')),
                        'clientEmail' => trim(self::or($b['clientEmail'] ?? null, $q0['clientEmail'] ?? '')), 'clientPhone' => trim(self::or($b['clientPhone'] ?? null, $q0['clientPhone'] ?? '')),
                        'clientCompany' => trim(self::or($b['clientCompany'] ?? null, $q0['clientCompany'] ?? '')), 'market' => $q0['market'] ?: 'all', 'status' => 'draft',
                        'totalNights' => $sum['nights'], 'totalGuests' => ($sourceItems[0]['adults'] ?: 2).' Adults',
                        'baseAmount' => self::fixed($sum['base']), 'boardAmount' => self::fixed($sum['board']), 'occupancyAmount' => self::fixed($sum['occ']),
                        'extraBedAmount' => self::fixed($sum['bed']), 'tourismTaxAmount' => self::fixed($sum['tax']),
                        'includeTax' => $p['includeTax'], 'markupMode' => $p['markupMode'], 'markupValue' => (string) $p['markupValue'],
                        'hotelCostTotal' => (string) $p['hotelCostTotal'], 'markupAmount' => (string) $p['markupAmount'], 'quotedTotal' => (string) $p['quotedTotal'],
                        'totalAmount' => (string) $p['quotedTotal'], 'currency' => $q0['currency'] ?: 'AED',
                        'notes' => self::or($b['notes'] ?? null, 'Combined from quotations: '.implode(', ', array_column($sourceQuotes, 'reference'))),
                    ]);
                    $items = [];
                    foreach ($sourceItems as $idx => $it) {
                        $row = ['quotationId' => $quote['id'], 'sortOrder' => $idx];
                        foreach (self::ITEM_COPY as $k) $row[$k] = $it[$k];
                        $items[] = Rows::insert('quotation_items', $row);
                    }
                    return ['quotation' => $quote, 'items' => $items];
                });
                return self::json($result, 201);
            }

            $rawItems = is_array($b['items'] ?? null) ? $b['items'] : [];
            if (! $rawItems) return self::json(['error' => 'Quotation must have at least one hotel stay.'], 400);
            [$items, $sum] = self::validateStayItems($rawItems, true);
            $c = self::commercial($b);
            $roomsSum = array_sum(array_map(fn ($i) => $i['rooms'] ?: 1, $items));
            $p = self::pricing($sum['base'] + $sum['board'] + $sum['occ'] + $sum['bed'], $sum['tax'], $c['includeTax'], $c['markupMode'], $c['markupValue'], $sum['nights'], $roomsSum ?: 1);
            $title = trim(self::s($b['title'] ?? null)) ?: (count($rawItems) > 1 ? 'Multi-Stay Itinerary ('.count($rawItems).' hotels)' : 'Hotel Stay Quotation');
            $result = DB::transaction(function () use ($b, $items, $sum, $p, $title) {
                $first = $items[0];
                $quote = Rows::insert('quotations', [
                    'reference' => self::reference('LAQ', 6), 'title' => $title,
                    'clientName' => trim(self::s($b['clientName'] ?? null)) ?: 'Guest / Partner', 'clientEmail' => trim(self::s($b['clientEmail'] ?? null)),
                    'clientPhone' => trim(self::s($b['clientPhone'] ?? null)), 'clientCompany' => trim(self::s($b['clientCompany'] ?? null)),
                    'market' => self::or($b['market'] ?? null, 'all'), 'status' => 'draft',
                    'validUntil' => self::truthy($b['validUntil'] ?? null) ? self::s($b['validUntil']) : null,
                    'totalNights' => $sum['nights'], 'totalGuests' => ($first['adults'] ?: 2).' Adults'.($first['children'] ? " + {$first['children']} Children" : ''),
                    'baseAmount' => self::fixed($sum['base']), 'boardAmount' => self::fixed($sum['board']), 'occupancyAmount' => self::fixed($sum['occ']),
                    'extraBedAmount' => self::fixed($sum['bed']), 'tourismTaxAmount' => self::fixed($sum['tax']),
                    'includeTax' => $p['includeTax'], 'markupMode' => $p['markupMode'], 'markupValue' => (string) $p['markupValue'],
                    'hotelCostTotal' => (string) $p['hotelCostTotal'], 'markupAmount' => (string) $p['markupAmount'], 'quotedTotal' => (string) $p['quotedTotal'],
                    'totalAmount' => (string) $p['quotedTotal'], 'currency' => self::or($b['currency'] ?? null, 'AED'), 'notes' => self::or($b['notes'] ?? null),
                ]);
                $inserted = [];
                foreach ($items as $it) $inserted[] = Rows::insert('quotation_items', $it + ['quotationId' => $quote['id']]);
                return ['quotation' => $quote, 'items' => $inserted];
            });
            return self::json($result, 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => $e instanceof InputError ? $e->getMessage() : 'Unable to save quotation.'], 400);
        }
    }

    public function quotationsPatch(Request $r)
    {
        [, $err] = Auth::guard('quotations');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            if (! $id) return self::json(['error' => 'Quotation ID required.'], 400);
            $p = [];
            foreach (['status' => false, 'title' => true, 'clientName' => true, 'clientEmail' => true, 'clientPhone' => true, 'clientCompany' => true, 'notes' => false] as $k => $trim) {
                if (array_key_exists($k, $b)) $p[$k] = $trim ? trim(self::s($b[$k])) : self::s($b[$k]);
            }
            if (array_key_exists('validUntil', $b)) $p['validUntil'] = self::truthy($b['validUntil']) ? self::s($b['validUntil']) : null;
            $p['updatedAt'] = '__now';
            if (array_key_exists('includeTax', $b) || array_key_exists('markupMode', $b) || array_key_exists('markupValue', $b)) {
                $cur = Rows::find('quotations', $id);
                if (! $cur) return self::json(['error' => 'Quotation not found.'], 404);
                $c = self::commercial([
                    'includeTax' => $b['includeTax'] ?? $cur['includeTax'], 'markupMode' => $b['markupMode'] ?? $cur['markupMode'],
                    'markupValue' => $b['markupValue'] ?? self::n($cur['markupValue']),
                ]);
                $hotelCost = self::n($cur['baseAmount']) + self::n($cur['boardAmount']) + self::n($cur['occupancyAmount']) + self::n($cur['extraBedAmount']);
                $rooms = array_sum(array_map(fn ($x) => (int) $x ?: 1, DB::table('quotation_items')->where('quotation_id', $id)->pluck('rooms')->all()));
                $pr = self::pricing($hotelCost, self::n($cur['tourismTaxAmount']), $c['includeTax'], $c['markupMode'], $c['markupValue'], $cur['totalNights'], $rooms ?: 1);
                $p += ['includeTax' => $pr['includeTax'], 'markupMode' => $pr['markupMode'], 'markupValue' => (string) $pr['markupValue'], 'hotelCostTotal' => (string) $pr['hotelCostTotal'],
                    'markupAmount' => (string) $pr['markupAmount'], 'quotedTotal' => (string) $pr['quotedTotal'], 'totalAmount' => (string) $pr['quotedTotal']];
            }
            return self::json(['quotation' => Rows::update('quotations', $id, $p)]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Failed to update quotation.'], 400);
        }
    }

    public function quotationsDelete(Request $r) { return self::deleteById($r, 'quotations', 'quotations', 'Quotation', 'Failed to delete quotation.'); }

    /* --------------------------------- bookings ----------------------------- */

    public function bookingsPost(Request $r)
    {
        [, $err] = Auth::guard('bookings');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $reference = self::reference('LAH', 7);

            if (self::truthy($b['convertQuotationId'] ?? null)) {
                $quoteId = (int) self::n($b['convertQuotationId']);
                $quote = Rows::find('quotations', $quoteId);
                if (! $quote) return self::json(['error' => 'Quotation not found.'], 404);
                $items = Rows::outAll('quotation_items', DB::table('quotation_items')->where('quotation_id', $quoteId)->orderBy('sort_order')->get());
                if (! $items) return self::json(['error' => 'Quotation has no stay segments.'], 400);
                $guestName = trim(self::or($b['guestName'] ?? null, $quote['clientName'] ?? ''));
                $guestEmail = trim(self::or($b['guestEmail'] ?? null, $quote['clientEmail'] ?? ''));
                $guestPhone = trim(self::or($b['guestPhone'] ?? null, $quote['clientPhone'] ?? ''));
                $notes = trim(self::or($b['notes'] ?? null, $quote['notes'] ?? ''));
                if (! $guestName || ! $guestEmail) return self::json(['error' => 'Guest name and email are required to confirm booking.'], 400);
                $first = $items[0];
                $last = $items[count($items) - 1];
                $booking = DB::transaction(function () use ($reference, $quote, $items, $first, $last, $guestName, $guestEmail, $guestPhone, $notes) {
                    $booking = Rows::insert('bookings', [
                        'reference' => $reference, 'hotelId' => $first['hotelId'], 'roomTypeId' => $first['roomTypeId'], 'ratePeriodId' => $first['ratePeriodId'],
                        'boardType' => $first['boardType'], 'guestName' => $guestName, 'guestEmail' => $guestEmail, 'guestPhone' => $guestPhone,
                        'checkIn' => $first['checkIn'], 'checkOut' => $last['checkOut'], 'adults' => $first['adults'], 'children' => $first['children'],
                        'infants' => $first['infants'], 'rooms' => $first['rooms'],
                        'extraBeds' => array_sum(array_column($items, 'extraBeds')), 'sofaBeds' => array_sum(array_column($items, 'sofaBeds')), 'babyCots' => array_sum(array_column($items, 'babyCots')),
                        'nights' => $quote['totalNights'], 'baseAmount' => $quote['baseAmount'], 'boardAmount' => $quote['boardAmount'],
                        'occupancyAmount' => $quote['occupancyAmount'], 'extraBedAmount' => $quote['extraBedAmount'], 'tourismTaxAmount' => $quote['tourismTaxAmount'],
                        'totalAmount' => $quote['totalAmount'], 'currency' => $quote['currency'], 'status' => 'confirmed',
                        'notes' => $notes ? "{$notes} (Converted from Quote {$quote['reference']})" : "Converted from Quote {$quote['reference']}", 'quotationId' => $quote['id'],
                    ]);
                    foreach ($items as $idx => $it) {
                        $row = ['bookingId' => $booking['id'], 'sortOrder' => $idx];
                        foreach (self::ITEM_COPY as $k) $row[$k] = $it[$k];
                        Rows::insert('booking_items', $row);
                    }
                    Rows::update('quotations', $quote['id'], ['status' => 'converted', 'convertedBookingId' => $booking['id'], 'updatedAt' => '__now']);
                    return $booking;
                });
                return self::json(['booking' => $booking, 'quotationConverted' => true], 201);
            }

            if (is_array($b['items'] ?? null) && count($b['items']) > 0) {
                $guestName = trim(self::s($b['guestName'] ?? null));
                $guestEmail = trim(self::s($b['guestEmail'] ?? null));
                $guestPhone = trim(self::s($b['guestPhone'] ?? null));
                if (! $guestName || ! $guestEmail) return self::json(['error' => 'Guest name and email are required.'], 400);
                [$items, $sum] = self::validateStayItems($b['items'], false);
                $first = $items[0];
                $last = $items[count($items) - 1];
                $booking = DB::transaction(function () use ($b, $reference, $items, $sum, $first, $last, $guestName, $guestEmail, $guestPhone) {
                    $booking = Rows::insert('bookings', [
                        'reference' => $reference, 'hotelId' => $first['hotelId'], 'roomTypeId' => $first['roomTypeId'], 'ratePeriodId' => $first['ratePeriodId'],
                        'boardType' => $first['boardType'], 'guestName' => $guestName, 'guestEmail' => $guestEmail, 'guestPhone' => $guestPhone,
                        'checkIn' => $first['checkIn'], 'checkOut' => $last['checkOut'], 'adults' => $first['adults'], 'children' => $first['children'],
                        'infants' => $first['infants'], 'rooms' => $first['rooms'],
                        'extraBeds' => array_sum(array_column($items, 'extraBeds')), 'sofaBeds' => array_sum(array_column($items, 'sofaBeds')), 'babyCots' => array_sum(array_column($items, 'babyCots')),
                        'nights' => $sum['nights'], 'baseAmount' => self::fixed($sum['base']), 'boardAmount' => self::fixed($sum['board']),
                        'occupancyAmount' => self::fixed($sum['occ']), 'extraBedAmount' => self::fixed($sum['bed']), 'tourismTaxAmount' => self::fixed($sum['tax']),
                        'totalAmount' => self::fixed($sum['total']), 'currency' => self::or($b['currency'] ?? null, 'AED'), 'status' => 'confirmed',
                        'notes' => self::or($b['notes'] ?? null, count($items) > 1 ? 'Multi-hotel booking ('.count($items).' stays)' : ''),
                    ]);
                    foreach ($items as $it) Rows::insert('booking_items', $it + ['bookingId' => $booking['id']]);
                    return $booking;
                });
                return self::json(['booking' => $booking], 201);
            }

            // Single search-result booking. The original pricing engine runs in the browser
            // (same TypeScript code) and posts the priced offer as __priced.
            $pr = is_array($b['__priced'] ?? null) ? $b['__priced'] : null;
            $boardType = self::or($b['boardType'] ?? null);
            if (! $pr || ! $boardType) return self::json(['error' => 'Select a hotel, room and board option from the search results.'], 400);
            $guestName = trim(self::s($b['guestName'] ?? null));
            $guestEmail = trim(self::s($b['guestEmail'] ?? null));
            if (! $guestName || ! $guestEmail) return self::json(['error' => 'Guest name and email are required.'], 400);
            $offer = is_array($pr['offer'] ?? null) ? $pr['offer'] : [];
            $c = is_array($pr['criteria'] ?? null) ? $pr['criteria'] : [];
            $hotelId = (int) self::n($pr['hotelId'] ?? null);
            $roomTypeId = (int) self::n($pr['roomTypeId'] ?? null);
            if (! DB::table('room_types')->where('id', $roomTypeId)->where('hotel_id', $hotelId)->where('active', 1)->exists()) {
                return self::json(['error' => 'Unavailable: This room is no longer available.'], 409);
            }
            $common = [
                'hotelId' => $hotelId, 'roomTypeId' => $roomTypeId, 'ratePeriodId' => (int) self::n($offer['primaryRatePeriodId'] ?? null) ?: null, 'boardType' => $boardType,
                'checkIn' => self::s($c['checkIn'] ?? ''), 'checkOut' => self::s($c['checkOut'] ?? ''), 'adults' => (int) self::n($c['adults'] ?? 2),
                'children' => (int) self::n($c['children'] ?? 0), 'infants' => (int) self::n($c['infants'] ?? 0), 'rooms' => max(1, (int) self::n($c['rooms'] ?? 1)),
                'extraBeds' => (int) self::n($offer['extraBeds'] ?? 0), 'sofaBeds' => (int) self::n($offer['sofaBeds'] ?? 0), 'babyCots' => (int) self::n($offer['babyCots'] ?? 0),
                'nights' => (int) self::n($offer['nights'] ?? 0), 'baseAmount' => (string) self::n($offer['baseAmount'] ?? 0), 'boardAmount' => (string) self::n($offer['boardAmount'] ?? 0),
                'occupancyAmount' => (string) self::n($offer['occupancyAmount'] ?? 0), 'extraBedAmount' => (string) self::n($offer['extraBedAmount'] ?? 0),
                'tourismTaxAmount' => (string) self::n($offer['tourismTaxAmount'] ?? 0), 'totalAmount' => (string) self::n($offer['totalAmount'] ?? 0),
            ];
            $booking = DB::transaction(function () use ($b, $reference, $common, $pr, $offer, $guestName, $guestEmail) {
                $booking = Rows::insert('bookings', $common + [
                    'reference' => $reference, 'guestName' => $guestName, 'guestEmail' => $guestEmail, 'guestPhone' => self::or($b['guestPhone'] ?? null),
                    'currency' => self::or($pr['currency'] ?? null, 'AED'), 'notes' => self::or($b['notes'] ?? null), 'status' => 'confirmed',
                ]);
                Rows::insert('booking_items', $common + [
                    'bookingId' => $booking['id'], 'sortOrder' => 0,
                    'rateNames' => implode(', ', (array) ($offer['rateNames'] ?? [])), 'promoCodes' => implode(', ', (array) ($offer['promoCodes'] ?? [])),
                    'notes' => self::or($b['notes'] ?? null),
                ]);
                return $booking;
            });
            return self::json(['booking' => $booking, 'offer' => $offer], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => $e->getMessage() ?: 'Unable to process booking.'], 400);
        }
    }

    /* ------------------------------ trip packages --------------------------- */

    public function tripPackagesGet(Request $r)
    {
        try {
            $id = (int) self::n($r->query('id'));
            $services = Rows::all('services');
            $tours = Rows::all('tours');
            if ($id) {
                $pkg = Rows::find('trip_packages', $id);
                if (! $pkg) return self::json(['error' => 'Trip package not found.'], 404);
                $items = Rows::outAll('trip_package_items', DB::table('trip_package_items')->where('package_id', $id)->orderBy('service_date')->orderBy('service_time')->orderBy('sort_order')->get());
                $quote = null;
                $hotelItems = [];
                if ($pkg['quotationId']) {
                    $quote = Rows::find('quotations', $pkg['quotationId']);
                    $hotelItems = Rows::outAll('quotation_items', DB::table('quotation_items')->where('quotation_id', $pkg['quotationId'])->orderBy('sort_order')->get());
                }
                return self::json(['tripPackage' => $pkg, 'items' => $items, 'quotation' => $quote, 'hotelItems' => $hotelItems, 'services' => $services, 'tours' => $tours]);
            }
            return self::json(['tripPackages' => Rows::all('trip_packages', ['created_at' => 'desc']), 'items' => Rows::all('trip_package_items', ['sort_order' => 'asc']), 'services' => $services, 'tours' => $tours]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Failed to load trip packages.'], 500);
        }
    }

    public function tripPackagesPost(Request $r)
    {
        [, $err] = Auth::guard('trips');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $title = trim(self::s($b['title'] ?? null)) ?: 'Trip Package';
            $clientName = trim(self::s($b['clientName'] ?? null)) ?: 'Valued Guest';
            $quotationId = self::n($b['quotationId'] ?? null) > 0 ? (int) self::n($b['quotationId']) : null;
            $includesHotels = ($b['includesHotels'] ?? null) === false ? false : self::truthy($b['includesHotels'] ?? true);
            $validated = [];
            $extras = 0;
            foreach ((is_array($b['items'] ?? null) ? $b['items'] : []) as $idx => $raw) {
                $raw = is_array($raw) ? $raw : [];
                $kind = self::s($raw['kind'] ?? null) === 'tour' ? 'tour' : 'service';
                $name = trim(self::s($raw['name'] ?? null));
                if (! $name) continue;
                $persons = max(1, (int) (self::n($raw['persons'] ?? null) ?: 1));
                $vehicles = max(1, (int) (self::n($raw['vehicles'] ?? null) ?: 1));
                $unit = max(0, self::n($raw['unitPrice'] ?? null));
                $priceMode = $kind === 'service' && self::s($raw['priceMode'] ?? null) === 'per_vehicle' ? 'per_vehicle' : 'per_person';
                $total = self::round2($unit * ($priceMode === 'per_vehicle' ? max(1, $vehicles) : max(1, $persons)));
                $extras += $total;
                $validated[] = [
                    'sortOrder' => $idx, 'kind' => $kind, 'serviceId' => self::truthy($raw['serviceId'] ?? null) ? (int) self::n($raw['serviceId']) : null,
                    'tourId' => self::truthy($raw['tourId'] ?? null) ? (int) self::n($raw['tourId']) : null, 'name' => $name,
                    'priceType' => self::or($raw['priceType'] ?? null, $kind === 'tour' ? 'ticket_only' : 'shared_one_way'),
                    'serviceDate' => self::truthy($raw['serviceDate'] ?? null) ? self::s($raw['serviceDate']) : null, 'serviceTime' => self::or($raw['serviceTime'] ?? null),
                    'pickup' => self::or($raw['pickup'] ?? null), 'dropoff' => self::or($raw['dropoff'] ?? null), 'persons' => $persons, 'vehicles' => $vehicles,
                    'unitPrice' => self::fixed($unit), 'totalAmount' => self::fixed($total), 'details' => self::or($raw['details'] ?? null),
                ];
            }
            $hotelCost = 0;
            $tax = 0;
            $quote = null;
            if ($quotationId) {
                $quote = Rows::find('quotations', $quotationId);
                if (! $quote) return self::json(['error' => 'Linked quotation not found.'], 404);
                $hotelCost = self::n($quote['hotelCostTotal']) ?: (self::n($quote['baseAmount']) + self::n($quote['boardAmount']) + self::n($quote['occupancyAmount']) + self::n($quote['extraBedAmount']));
                $tax = self::n($quote['tourismTaxAmount']);
            }
            $c = self::commercial([
                'includeTax' => $b['includeTax'] ?? ($quote['includeTax'] ?? true), 'markupMode' => $b['markupMode'] ?? ($quote['markupMode'] ?? 'percent'),
                'markupValue' => $b['markupValue'] ?? ($quote['markupValue'] ?? 0),
            ]);
            $p = self::pricing($hotelCost + $extras, $tax, $c['includeTax'], $c['markupMode'], $c['markupValue'], $quote['totalNights'] ?? 1, 1);
            $pkg = DB::transaction(function () use ($b, $title, $clientName, $quotationId, $includesHotels, $validated, $extras, $hotelCost, $tax, $quote, $p) {
                $pkg = Rows::insert('trip_packages', [
                    'reference' => self::reference('TRP', 6), 'quotationId' => $quotationId, 'title' => $title, 'clientName' => $clientName,
                    'clientEmail' => self::or($b['clientEmail'] ?? null, $quote['clientEmail'] ?? ''), 'clientPhone' => self::or($b['clientPhone'] ?? null, $quote['clientPhone'] ?? ''),
                    'clientCompany' => self::or($b['clientCompany'] ?? null, $quote['clientCompany'] ?? ''), 'status' => 'draft',
                    'startDate' => self::truthy($b['startDate'] ?? null) ? self::s($b['startDate']) : null, 'endDate' => self::truthy($b['endDate'] ?? null) ? self::s($b['endDate']) : null,
                    'includesHotels' => $includesHotels, 'includeTax' => $p['includeTax'], 'markupMode' => $p['markupMode'], 'markupValue' => (string) $p['markupValue'],
                    'hotelCostTotal' => $includesHotels ? self::fixed($hotelCost) : '0.00', 'extrasCostTotal' => self::fixed($extras),
                    'tourismTaxAmount' => $includesHotels ? self::fixed($tax) : '0.00', 'markupAmount' => (string) $p['markupAmount'],
                    'quotedTotal' => (string) $p['quotedTotal'], 'totalAmount' => (string) $p['quotedTotal'], 'currency' => $quote['currency'] ?? 'AED',
                    'notes' => self::or($b['notes'] ?? null),
                ]);
                foreach ($validated as $it) Rows::insert('trip_package_items', $it + ['packageId' => $pkg['id']]);
                return $pkg;
            });
            return self::json(['tripPackage' => $pkg], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to save trip package.'], 400);
        }
    }

    public function tripPackagesPatch(Request $r)
    {
        [, $err] = Auth::guard('trips');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            if (! $id) return self::json(['error' => 'Trip package id required.'], 400);
            $cur = Rows::find('trip_packages', $id);
            if (! $cur) return self::json(['error' => 'Trip package not found.'], 404);
            $p = ['updatedAt' => '__now'];
            foreach (['status', 'clientEmail', 'clientPhone', 'clientCompany', 'notes'] as $k) if (array_key_exists($k, $b)) $p[$k] = self::s($b[$k]);
            foreach (['title', 'clientName'] as $k) if (array_key_exists($k, $b)) $p[$k] = trim(self::s($b[$k]));
            if (array_key_exists('includesHotels', $b)) $p['includesHotels'] = self::truthy($b['includesHotels']);
            if (array_key_exists('includeTax', $b) || array_key_exists('markupMode', $b) || array_key_exists('markupValue', $b) || self::truthy($b['reprice'] ?? null)) {
                $extras = array_sum(array_map(fn ($v) => self::n($v), DB::table('trip_package_items')->where('package_id', $id)->pluck('total_amount')->all()));
                $c = self::commercial(['includeTax' => $b['includeTax'] ?? $cur['includeTax'], 'markupMode' => $b['markupMode'] ?? $cur['markupMode'], 'markupValue' => $b['markupValue'] ?? self::n($cur['markupValue'])]);
                $hotelCost = $cur['includesHotels'] ? self::n($cur['hotelCostTotal']) : 0;
                $tax = $cur['includesHotels'] ? self::n($cur['tourismTaxAmount']) : 0;
                $pr = self::pricing($hotelCost + $extras, $tax, $c['includeTax'], $c['markupMode'], $c['markupValue'], 1, 1);
                $p += ['includeTax' => $pr['includeTax'], 'markupMode' => $pr['markupMode'], 'markupValue' => (string) $pr['markupValue'], 'extrasCostTotal' => self::fixed($extras),
                    'markupAmount' => (string) $pr['markupAmount'], 'quotedTotal' => (string) $pr['quotedTotal'], 'totalAmount' => (string) $pr['quotedTotal']];
            }
            return self::json(['tripPackage' => Rows::update('trip_packages', $id, $p)]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Failed to update trip package.'], 400);
        }
    }

    public function tripPackagesDelete(Request $r) { return self::deleteById($r, 'trips', 'trip_packages', 'Trip package', 'Failed to delete trip package.'); }

    private static function repricePackage(int $packageId): void
    {
        $pkg = Rows::find('trip_packages', $packageId);
        if (! $pkg) return;
        $extras = array_sum(array_map(fn ($v) => self::n($v), DB::table('trip_package_items')->where('package_id', $packageId)->pluck('total_amount')->all()));
        $hotelCost = $pkg['includesHotels'] ? self::n($pkg['hotelCostTotal']) : 0;
        $tax = $pkg['includesHotels'] ? self::n($pkg['tourismTaxAmount']) : 0;
        $p = self::pricing($hotelCost + $extras, $tax, $pkg['includeTax'] !== false, $pkg['markupMode'] === 'amount' ? 'amount' : 'percent', self::n($pkg['markupValue']), 1, 1);
        Rows::update('trip_packages', $packageId, ['extrasCostTotal' => self::fixed($extras), 'markupAmount' => (string) $p['markupAmount'], 'quotedTotal' => (string) $p['quotedTotal'], 'totalAmount' => (string) $p['quotedTotal'], 'updatedAt' => '__now']);
    }

    public function tripItemsPost(Request $r)
    {
        [, $err] = Auth::guard('trips');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $packageId = (int) self::n($b['packageId'] ?? null);
            if (! $packageId) return self::json(['error' => 'Package id required.'], 400);
            if (! DB::table('trip_packages')->where('id', $packageId)->exists()) return self::json(['error' => 'Trip package not found.'], 404);
            $kind = self::s($b['kind'] ?? null) === 'tour' ? 'tour' : 'service';
            $name = trim(self::s($b['name'] ?? null));
            if (! $name) return self::json(['error' => 'Choose a service or tour to add.'], 400);
            $persons = max(1, (int) (self::n($b['persons'] ?? null) ?: 1));
            $vehicles = max(1, (int) (self::n($b['vehicles'] ?? null) ?: 1));
            $unit = max(0, self::n($b['unitPrice'] ?? null));
            $mode = $kind === 'service' && self::s($b['priceMode'] ?? null) === 'per_vehicle' ? 'per_vehicle' : 'per_person';
            $total = self::round2($unit * ($mode === 'per_vehicle' ? $vehicles : $persons));
            $last = DB::table('trip_package_items')->where('package_id', $packageId)->max('sort_order');
            $item = Rows::insert('trip_package_items', [
                'packageId' => $packageId, 'sortOrder' => ($last === null ? -1 : (int) $last) + 1, 'kind' => $kind,
                'serviceId' => self::truthy($b['serviceId'] ?? null) ? (int) self::n($b['serviceId']) : null, 'tourId' => self::truthy($b['tourId'] ?? null) ? (int) self::n($b['tourId']) : null,
                'name' => $name, 'priceType' => self::or($b['priceType'] ?? null, $kind === 'tour' ? 'ticket_only' : 'shared_one_way'),
                'serviceDate' => self::truthy($b['serviceDate'] ?? null) ? self::s($b['serviceDate']) : null, 'serviceTime' => self::or($b['serviceTime'] ?? null),
                'pickup' => self::or($b['pickup'] ?? null), 'dropoff' => self::or($b['dropoff'] ?? null), 'persons' => $persons, 'vehicles' => $vehicles,
                'unitPrice' => self::fixed($unit), 'totalAmount' => self::fixed($total), 'details' => self::or($b['details'] ?? null),
            ]);
            self::repricePackage($packageId);
            return self::json(['item' => $item], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to add this line.'], 400);
        }
    }

    public function tripItemsDelete(Request $r)
    {
        [, $err] = Auth::guard('trips');
        if ($err) return $err;
        try {
            $id = (int) self::n($r->query('id'));
            if (! $id) return self::json(['error' => 'Item id required.'], 400);
            $item = Rows::find('trip_package_items', $id);
            if (! $item) return self::json(['error' => 'Item not found.'], 404);
            DB::table('trip_package_items')->where('id', $id)->delete();
            self::repricePackage($item['packageId']);
            return self::json(['ok' => true]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to delete this line.'], 400);
        }
    }
}

class InputError extends \RuntimeException {}
