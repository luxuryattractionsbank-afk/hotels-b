<?php

namespace App\Http\Controllers;

use App\Support\Installer;
use Illuminate\Http\Request;

class InstallController extends Controller
{
    public function show()
    {
        return response()->view('install', ['reqs' => Installer::requirements(), 'db' => session('install_db')]);
    }

    private function db(Request $r): array
    {
        return [
            'host' => trim((string) $r->input('host')) ?: 'localhost',
            'port' => trim((string) $r->input('port')) ?: '3306',
            'database' => trim((string) $r->input('database')),
            'username' => trim((string) $r->input('username')),
            'password' => (string) $r->input('password'),
        ];
    }

    public function test(Request $r)
    {
        $db = $this->db($r);
        if (! $db['database'] || ! $db['username']) return back()->withInput()->with('error', 'Enter the database name and username.');
        try {
            $msg = Installer::testDb($db);
        } catch (\Throwable $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }
        session(['install_db' => $db]);
        return redirect('/install')->with('ok', $msg);
    }

    public function install(Request $r)
    {
        $db = session('install_db');
        if (! $db) return redirect('/install')->with('error', 'Test the database connection first (step 2).');
        $d = $r->validate([
            'admin_name' => 'required|string|max:120',
            'admin_email' => 'required|email|max:190',
            'admin_password' => 'required|string|min:8|confirmed',
            'admin_phone' => 'nullable|string|max:60',
        ], ['admin_password.confirmed' => 'The two passwords do not match.']);
        try {
            Installer::testDb($db);
            Installer::install($db, $d + ['demo' => $r->boolean('demo'), 'demo_agent' => $r->boolean('demo_agent')], rtrim($r->getSchemeAndHttpHost().$r->getBaseUrl(), '/'));
        } catch (\Throwable $e) {
            report($e);
            return back()->withInput()->with('error', 'Installation failed: '.$e->getMessage());
        }
        session()->forget('install_db');
        return redirect('/login')->with('ok', 'Installation complete — sign in with '.strtolower($d['admin_email']).'.');
    }
}
