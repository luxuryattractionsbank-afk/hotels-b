<?php

// Global helpers (kept for the Composer autoloader).
