<?php

namespace App\Support;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use PDO;

/** WordPress-style browser installer: upload -> extract -> /install. */
class Installer
{
    public static function lockPath(): string { return storage_path('installed.lock'); }

    public static function installed(): bool { return is_file(self::lockPath()); }

    public static function requirements(): array
    {
        $e = fn ($x) => extension_loaded($x);
        $w = fn ($p) => is_dir($p) && is_writable($p);
        return [
            ['PHP 8.2 or newer', version_compare(PHP_VERSION, '8.2.0', '>='), 'Running PHP '.PHP_VERSION],
            ['PDO MySQL extension', $e('pdo_mysql'), 'pdo_mysql'],
            ['mbstring, openssl, ctype, tokenizer, xml, fileinfo', $e('mbstring') && $e('openssl') && $e('ctype') && $e('tokenizer') && $e('dom') && $e('fileinfo'), 'cPanel → Select PHP Version → Extensions'],
            ['.env writable', is_writable(base_path('.env')) || (! file_exists(base_path('.env')) && is_writable(base_path())), '.env'],
            ['storage/ writable', $w(storage_path()) && $w(storage_path('framework/sessions')) && $w(storage_path('framework/views')) && $w(storage_path('logs')), 'storage/ (775)'],
            ['bootstrap/cache writable', $w(base_path('bootstrap/cache')), 'bootstrap/cache (775)'],
        ];
    }

    public static function testDb(array $c): string
    {
        try {
            $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['database']};charset=utf8mb4", $c['username'], $c['password'], [PDO::ATTR_TIMEOUT => 8, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $v = $pdo->query('select version()')->fetchColumn();
            $n = (int) $pdo->query('select count(*) from information_schema.tables where table_schema = '.$pdo->quote($c['database']))->fetchColumn();
            return "Connected to MySQL/MariaDB {$v} — database “{$c['database']}” has {$n} table(s).";
        } catch (\PDOException $e) {
            $m = $e->getMessage();
            if (str_contains($m, 'Access denied')) throw new \RuntimeException('Access denied: wrong database username/password, or the user was not added to the database with ALL PRIVILEGES (cPanel → MySQL Databases → Add User To Database).');
            if (str_contains($m, 'Unknown database')) throw new \RuntimeException('Unknown database: use the full cPanel name including the prefix, e.g. myuser_hotels.');
            if (str_contains($m, 'refused') || str_contains($m, 'getaddrinfo') || str_contains($m, 'timed out') || str_contains($m, 'No such file')) throw new \RuntimeException('Cannot reach the database server. On cPanel the host is “localhost” and the port 3306.');
            throw new \RuntimeException($m);
        }
    }

    public static function writeEnv(array $values): void
    {
        $file = base_path('.env');
        $env = is_file($file) ? file_get_contents($file) : (string) @file_get_contents(base_path('.env.example'));
        foreach ($values as $k => $v) {
            $v = (string) $v;
            if ($v === '' || preg_match('/[\s#"\'$\\\\=]/', $v)) $v = '"'.str_replace(['\\', '"', '$'], ['\\\\', '\\"', '\\$'], $v).'"';
            $line = "{$k}={$v}";
            $env = preg_match("/^{$k}=.*$/m", $env) ? preg_replace_callback("/^{$k}=.*$/m", fn () => $line, $env) : rtrim($env)."\n{$line}";
        }
        file_put_contents($file, rtrim($env)."\n");
    }

    public static function install(array $db, array $i, string $url): void
    {
        @set_time_limit(300);
        $key = env('APP_KEY') ?: 'base64:'.base64_encode(random_bytes(32));
        self::writeEnv([
            'APP_NAME' => 'Luxury Attractions Hotels', 'APP_ENV' => 'production', 'APP_DEBUG' => 'false', 'APP_URL' => $url, 'APP_KEY' => $key,
            'DB_CONNECTION' => 'mysql', 'DB_HOST' => $db['host'], 'DB_PORT' => $db['port'], 'DB_DATABASE' => $db['database'],
            'DB_USERNAME' => $db['username'], 'DB_PASSWORD' => $db['password'], 'SESSION_DRIVER' => 'file', 'CACHE_STORE' => 'file', 'QUEUE_CONNECTION' => 'sync',
        ]);
        config(['database.default' => 'mysql', 'database.connections.mysql' => array_merge(config('database.connections.mysql'), [
            'host' => $db['host'], 'port' => $db['port'], 'database' => $db['database'], 'username' => $db['username'], 'password' => $db['password'],
        ])]);
        DB::purge('mysql');
        DB::setDefaultConnection('mysql');
        self::migrateAndSeed($i);
    }

    /** Also used by the local test harness (sqlite). */
    public static function migrateAndSeed(array $i): void
    {
        Artisan::call('migrate', ['--force' => true]);
        self::importDemo(! empty($i['demo']));
        $email = strtolower(trim($i['admin_email']));
        if (DB::table('users')->where('email', $email)->exists()) {
            DB::table('users')->where('email', $email)->update(['name' => $i['admin_name'], 'password_hash' => Auth::hash($i['admin_password']), 'role' => 'admin', 'permissions' => Auth::serialise(Auth::PERMISSIONS), 'active' => 1]);
        } else {
            Rows::insert('users', ['email' => $email, 'name' => $i['admin_name'], 'passwordHash' => Auth::hash($i['admin_password']), 'role' => 'admin',
                'permissions' => Auth::serialise(Auth::PERMISSIONS), 'phone' => $i['admin_phone'] ?? '', 'active' => true, 'mustChangePassword' => false]);
        }
        if (! empty($i['demo_agent']) && ! DB::table('users')->where('email', 'agent@luxuryattractions.com')->exists()) {
            Rows::insert('users', ['email' => 'agent@luxuryattractions.com', 'name' => 'Reservations Agent', 'passwordHash' => Auth::hash('Agent@12345'), 'role' => 'agent',
                'permissions' => Auth::serialise(Auth::ROLE_PRESETS['agent']), 'active' => true, 'mustChangePassword' => false]);
        }
        file_put_contents(self::lockPath(), 'Installed '.gmdate('c').' — delete this file only to run /install again.');
        foreach (['config:clear', 'route:clear', 'view:clear'] as $c) { try { Artisan::call($c); } catch (\Throwable) {} }
    }

    /** Imports the original system's catalogue (database/demo.json). Reference lists always; hotels/rates only with demo. */
    public static function importDemo(bool $full): void
    {
        $data = json_decode((string) file_get_contents(database_path('demo.json')), true) ?: [];
        $reference = ['amenities', 'locations', 'markets', 'room_categories'];
        if (DB::table('markets')->count() > 0) return;
        foreach (SchemaMap::ORDER as $table) {
            if (! isset($data[$table]) || (! $full && ! in_array($table, $reference, true))) continue;
            $cols = SchemaMap::TABLES[$table];
            $rows = [];
            foreach ($data[$table] as $r) {
                $row = [];
                foreach ($cols as $snake => [$camel, $type]) {
                    if (! array_key_exists($snake, $r)) continue;
                    $row[$snake] = Rows::toDb($r[$snake], $type);
                }
                $rows[] = $row;
            }
            foreach (array_chunk($rows, 200) as $chunk) DB::table($table)->insert($chunk);
        }
    }
}
