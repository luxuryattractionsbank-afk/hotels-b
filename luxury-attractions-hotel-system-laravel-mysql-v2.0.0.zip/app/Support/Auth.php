<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/** Session user + permission model ported from src/lib/auth.ts and src/lib/permissions.ts. */
class Auth
{
    public const PERMISSIONS = ['search', 'quotations', 'trips', 'bookings', 'send_email', 'hotels', 'rooms', 'rates', 'blackouts', 'catalog', 'view_cost', 'users', 'settings'];

    public const ROLE_PRESETS = [
        'admin' => self::PERMISSIONS,
        'manager' => ['search', 'quotations', 'trips', 'bookings', 'send_email', 'hotels', 'rooms', 'rates', 'blackouts', 'catalog', 'view_cost'],
        'agent' => ['search', 'quotations', 'trips', 'bookings', 'send_email'],
        'viewer' => ['search'],
    ];

    public static function parse(?string $value): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) $value)), fn ($p) => in_array($p, self::PERMISSIONS, true)));
    }

    public static function serialise(array $list): string
    {
        return implode(',', array_values(array_unique(array_filter(array_map('strval', $list), fn ($p) => in_array($p, self::PERMISSIONS, true)))));
    }

    public static function hash(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    /** Accepts bcrypt and the original scrypt:salt:hash format (users migrated from Next.js). */
    public static function verify(string $password, ?string $stored): bool
    {
        $stored = (string) $stored;
        if (str_starts_with($stored, 'scrypt:')) {
            [, $salt, $hash] = array_pad(explode(':', $stored), 3, '');
            if (! $salt || ! $hash || ! function_exists('sodium_crypto_pwhash_scryptsalsa208sha256_ll')) return false;
            $derived = sodium_crypto_pwhash_scryptsalsa208sha256_ll($password, $salt, 16384, 8, 64);
            return hash_equals($hash, bin2hex($derived));
        }
        return password_verify($password, $stored);
    }

    public static function user(): ?array
    {
        $id = session('uid');
        if (! $id) return null;
        try {
            $row = DB::table('users')->where('id', $id)->first();
        } catch (\Throwable) {
            return null;
        }
        if (! $row || ! (int) $row->active) return null;
        return ['id' => (int) $row->id, 'name' => $row->name, 'email' => $row->email, 'role' => $row->role, 'permissions' => self::parse($row->permissions)];
    }

    public static function can(?array $user, string $permission): bool
    {
        if (! $user) return false;
        if ($user['role'] === 'admin') return true;
        return in_array($permission, $user['permissions'], true);
    }

    /** Returns [user, errorResponse|null] exactly like requirePermission() in the original. */
    public static function guard(string $permission): array
    {
        $user = self::user();
        if (! $user) return [null, response()->json(['error' => 'Please sign in to continue.'], 401)];
        if (! self::can($user, $permission)) return [$user, response()->json(['error' => 'You do not have permission to do that.'], 403)];
        return [$user, null];
    }
}
