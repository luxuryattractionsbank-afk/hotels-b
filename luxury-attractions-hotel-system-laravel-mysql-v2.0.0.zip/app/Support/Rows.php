<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/**
 * Thin Drizzle-compatible layer: reads rows as camelCase with the exact JSON types the
 * original React screens expect (numeric => "123.00", boolean => true/false, timestamps ISO).
 */
class Rows
{
    public static function cols(string $table): array
    {
        return SchemaMap::TABLES[$table];
    }

    public static function out(string $table, $row): ?array
    {
        if ($row === null) return null;
        $row = (array) $row;
        $out = [];
        foreach (self::cols($table) as $snake => [$camel, $type, $notNull]) {
            $v = $row[$snake] ?? null;
            $out[$camel] = self::cast($v, $type, $notNull);
        }
        return $out;
    }

    public static function outAll(string $table, iterable $rows): array
    {
        $list = [];
        foreach ($rows as $r) $list[] = self::out($table, $r);
        return $list;
    }

    private static function cast($v, string $type, bool $notNull)
    {
        if ($v === null) {
            if (! $notNull) return null;
            return match (true) {
                $type === 'text' => '',
                $type === 'int' => 0,
                $type === 'bool' => false,
                str_starts_with($type, 'num') => number_format(0, (int) substr($type, 4), '.', ''),
                default => null,
            };
        }
        if ($type === 'int') return (int) $v;
        if ($type === 'bool') return (bool) (int) $v || $v === true || $v === 't';
        if (str_starts_with($type, 'num')) return number_format((float) $v, (int) substr($type, 4), '.', '');
        if ($type === 'date') return substr((string) $v, 0, 10);
        if ($type === 'ts') {
            $t = strtotime(str_contains((string) $v, 'T') || str_contains((string) $v, '+') ? (string) $v : $v.' UTC');
            return $t ? gmdate('Y-m-d\TH:i:s.000\Z', $t) : null;
        }
        return (string) $v;
    }

    public static function now(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    /** camelCase values => snake_case DB values. $fill applies the schema defaults. */
    public static function in(string $table, array $values, bool $fill): array
    {
        $cols = self::cols($table);
        $byCamel = [];
        foreach ($cols as $snake => $c) $byCamel[$c[0]] = $snake;
        $out = [];
        foreach ($values as $k => $v) {
            $snake = $byCamel[$k] ?? (isset($cols[$k]) ? $k : null);
            if (! $snake) continue;
            $out[$snake] = self::toDb($v, $cols[$snake][1]);
        }
        if ($fill) {
            foreach ($cols as $snake => [$camel, $type, $notNull, $default]) {
                if ($snake === 'id' || array_key_exists($snake, $out)) continue;
                if ($default === '__now') $out[$snake] = self::now();
                elseif ($default !== null) $out[$snake] = self::toDb($default, $type);
                elseif ($notNull && $type === 'text') $out[$snake] = '';
            }
        }
        return $out;
    }

    public static function toDb($v, string $type)
    {
        if ($v === null) return null;
        if ($type === 'bool') return $v ? 1 : 0;
        if ($type === 'int') return (int) $v;
        if ($type === 'ts') {
            if ($v === '__now' || $v === true) return self::now();
            $t = is_numeric($v) ? (int) $v : strtotime((string) $v);
            return $t ? gmdate('Y-m-d H:i:s', $t) : self::now();
        }
        if ($type === 'date') return substr((string) $v, 0, 10);
        if (str_starts_with($type, 'num')) return (string) (is_numeric($v) ? $v : 0);
        if (is_array($v)) return json_encode($v);
        return is_bool($v) ? ($v ? 'true' : 'false') : (string) $v;
    }

    public static function find(string $table, $id): ?array
    {
        return self::out($table, DB::table($table)->where('id', $id)->first());
    }

    public static function insert(string $table, array $values): array
    {
        $id = DB::table($table)->insertGetId(self::in($table, $values, true));
        return self::find($table, $id);
    }

    public static function insertMany(string $table, array $rows): array
    {
        $out = [];
        foreach ($rows as $r) $out[] = self::insert($table, $r);
        return $out;
    }

    public static function update(string $table, $id, array $patch): ?array
    {
        $data = self::in($table, $patch, false);
        if ($data) DB::table($table)->where('id', $id)->update($data);
        return self::find($table, $id);
    }

    /** SELECT * ... ORDER BY for the dashboard payload. */
    public static function all(string $table, array $order = []): array
    {
        $q = DB::table($table);
        foreach ($order as $col => $dir) $q->orderBy($col, $dir);
        return self::outAll($table, $q->get());
    }

    public static function isUnique(\Throwable $e): bool
    {
        $m = strtolower($e->getMessage());
        return str_contains($m, 'unique') || str_contains($m, 'duplicate') || (string) $e->getCode() === '23000' || (string) $e->getCode() === '23505';
    }
}
