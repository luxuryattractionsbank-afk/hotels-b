<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Generated from the original src/db/schema.ts (Drizzle/PostgreSQL) -> MySQL. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('amenities', function (Blueprint $t) {
            $t->id('id');
            $t->string('slug', 191);
            $t->text('label')->nullable();
            $t->text('icon')->nullable();
            $t->integer('sort_order')->default(100);
            $t->boolean('active')->default(true);
            $t->unique(['slug'], 'amenities_slug_idx');
        });

        Schema::create('locations', function (Blueprint $t) {
            $t->id('id');
            $t->string('city', 191);
            $t->string('name', 191);
            $t->boolean('active')->default(true);
            $t->unique(['city', 'name'], 'locations_city_name_idx');
        });

        Schema::create('hotel_groups', function (Blueprint $t) {
            $t->id('id');
            $t->string('name', 191);
            $t->text('website')->nullable();
            $t->text('notes')->nullable();
            $t->boolean('active')->default(true);
            $t->unique(['name'], 'hotel_groups_name_idx');
        });

        Schema::create('hotels', function (Blueprint $t) {
            $t->id('id');
            $t->text('name')->nullable();
            $t->text('city')->nullable();
            $t->text('country')->nullable();
            $t->unsignedBigInteger('location_id')->nullable();
            $t->text('address')->nullable();
            $t->integer('star_rating')->default(5);
            $t->string('supplier_code', 191);
            $t->unsignedBigInteger('group_id')->nullable();
            $t->text('business_type')->nullable();
            $t->text('website')->nullable();
            $t->text('contracts_folder_link')->nullable();
            $t->text('media_link')->nullable();
            $t->text('contact_email')->nullable();
            $t->text('contact_phone')->nullable();
            $t->text('currency')->nullable();
            $t->text('check_in_time')->nullable();
            $t->text('check_out_time')->nullable();
            $t->decimal('tourism_tax', 10, 2)->default('0');
            $t->text('tourism_tax_basis')->nullable();
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('location_id')->references('id')->on('locations')->nullOnDelete();
            $t->foreign('group_id')->references('id')->on('hotel_groups')->nullOnDelete();
            $t->unique(['supplier_code'], 'hotels_supplier_code_idx');
        });

        Schema::create('room_types', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id');
            $t->text('name')->nullable();
            $t->string('code', 191);
            $t->text('category')->nullable();
            $t->text('description')->nullable();
            $t->integer('max_adults')->default(2);
            $t->integer('max_children')->default(0);
            $t->integer('max_infants')->default(0);
            $t->integer('included_adults')->default(2);
            $t->integer('base_sleeps')->default(2);
            $t->integer('default_inventory')->default(1);
            $t->boolean('extra_bed_allowed')->default(false);
            $t->text('media_link')->nullable();
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('hotel_id')->references('id')->on('hotels')->cascadeOnDelete();
            $t->index(['hotel_id'], 'room_types_hotel_idx');
            $t->unique(['hotel_id', 'code'], 'room_types_hotel_code_idx');
        });

        Schema::create('blackout_dates', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('room_type_id')->nullable();
            $t->date('start_date');
            $t->date('end_date');
            $t->text('reason')->nullable();
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('hotel_id')->references('id')->on('hotels')->cascadeOnDelete();
            $t->foreign('room_type_id')->references('id')->on('room_types')->cascadeOnDelete();
            $t->index(['hotel_id', 'start_date', 'end_date'], 'blackout_dates_hotel_dates_idx');
        });

        Schema::create('rate_periods', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('room_type_id');
            $t->text('name')->nullable();
            $t->text('board_type')->nullable();
            $t->date('valid_from');
            $t->date('valid_to');
            $t->date('booking_window_start')->nullable();
            $t->date('booking_window_end')->nullable();
            $t->text('market')->nullable();
            $t->text('market_exclusions')->nullable();
            $t->text('promo_code')->nullable();
            $t->decimal('base_rate', 12, 2);
            $t->text('rate_basis')->nullable();
            $t->decimal('board_adult_supplement', 10, 2)->default('0');
            $t->decimal('board_child_supplement', 10, 2)->default('0');
            $t->text('board_supplement_basis')->nullable();
            $t->decimal('extra_adult_rate', 10, 2)->default('0');
            $t->decimal('extra_child_rate', 10, 2)->default('0');
            $t->decimal('extra_bed_rate', 10, 2)->default('0');
            $t->text('extra_bed_basis')->nullable();
            $t->integer('minimum_nights')->default(1);
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('hotel_id')->references('id')->on('hotels')->cascadeOnDelete();
            $t->foreign('room_type_id')->references('id')->on('room_types')->cascadeOnDelete();
            $t->index(['hotel_id'], 'rate_periods_hotel_idx');
            $t->index(['room_type_id', 'valid_from', 'valid_to'], 'rate_periods_room_dates_idx');
        });

        Schema::create('quotations', function (Blueprint $t) {
            $t->id('id');
            $t->string('reference', 191);
            $t->text('title')->nullable();
            $t->string('client_name', 191);
            $t->string('client_email', 191)->default('');
            $t->text('client_phone')->nullable();
            $t->text('client_company')->nullable();
            $t->text('market')->nullable();
            $t->text('status')->nullable();
            $t->date('valid_until')->nullable();
            $t->integer('total_nights')->default(0);
            $t->text('total_guests')->nullable();
            $t->decimal('base_amount', 12, 2)->default('0');
            $t->decimal('board_amount', 12, 2)->default('0');
            $t->decimal('occupancy_amount', 12, 2)->default('0');
            $t->decimal('extra_bed_amount', 12, 2)->default('0');
            $t->decimal('tourism_tax_amount', 12, 2)->default('0');
            $t->boolean('include_tax')->default(true);
            $t->text('markup_mode')->nullable();
            $t->decimal('markup_value', 12, 2)->default('0');
            $t->decimal('hotel_cost_total', 12, 2)->default('0');
            $t->decimal('markup_amount', 12, 2)->default('0');
            $t->decimal('quoted_total', 12, 2)->default('0');
            $t->decimal('total_amount', 12, 2)->default('0');
            $t->text('currency')->nullable();
            $t->text('notes')->nullable();
            $t->integer('converted_booking_id')->nullable();
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->timestamp('updated_at')->nullable()->useCurrent();
            $t->unique(['reference'], 'quotations_reference_idx');
            $t->index(['client_name', 'client_email'], 'quotations_client_idx');
        });

        Schema::create('bookings', function (Blueprint $t) {
            $t->id('id');
            $t->string('reference', 191);
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('room_type_id');
            $t->unsignedBigInteger('rate_period_id')->nullable();
            $t->text('board_type')->nullable();
            $t->text('guest_name')->nullable();
            $t->text('guest_email')->nullable();
            $t->text('guest_phone')->nullable();
            $t->date('check_in');
            $t->date('check_out');
            $t->integer('adults');
            $t->integer('children')->default(0);
            $t->integer('infants')->default(0);
            $t->integer('rooms')->default(1);
            $t->integer('extra_beds')->default(0);
            $t->integer('sofa_beds')->default(0);
            $t->integer('baby_cots')->default(0);
            $t->integer('nights');
            $t->decimal('base_amount', 12, 2);
            $t->decimal('board_amount', 12, 2)->default('0');
            $t->decimal('occupancy_amount', 12, 2)->default('0');
            $t->decimal('extra_bed_amount', 12, 2)->default('0');
            $t->decimal('tourism_tax_amount', 12, 2)->default('0');
            $t->decimal('total_amount', 12, 2);
            $t->text('currency')->nullable();
            $t->text('status')->nullable();
            $t->text('notes')->nullable();
            $t->unsignedBigInteger('quotation_id')->nullable();
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('hotel_id')->references('id')->on('hotels');
            $t->foreign('room_type_id')->references('id')->on('room_types');
            $t->foreign('rate_period_id')->references('id')->on('rate_periods');
            $t->foreign('quotation_id')->references('id')->on('quotations')->nullOnDelete();
            $t->unique(['reference'], 'bookings_reference_idx');
            $t->index(['check_in', 'check_out'], 'bookings_dates_idx');
        });

        Schema::create('booking_items', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('booking_id');
            $t->integer('sort_order')->default(0);
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('room_type_id');
            $t->unsignedBigInteger('rate_period_id')->nullable();
            $t->text('board_type')->nullable();
            $t->date('check_in');
            $t->date('check_out');
            $t->integer('nights')->default(1);
            $t->integer('adults')->default(2);
            $t->integer('children')->default(0);
            $t->integer('infants')->default(0);
            $t->integer('rooms')->default(1);
            $t->integer('extra_beds')->default(0);
            $t->integer('sofa_beds')->default(0);
            $t->integer('baby_cots')->default(0);
            $t->decimal('base_amount', 12, 2)->default('0');
            $t->decimal('board_amount', 12, 2)->default('0');
            $t->decimal('occupancy_amount', 12, 2)->default('0');
            $t->decimal('extra_bed_amount', 12, 2)->default('0');
            $t->decimal('tourism_tax_amount', 12, 2)->default('0');
            $t->decimal('total_amount', 12, 2)->default('0');
            $t->text('rate_names')->nullable();
            $t->text('promo_codes')->nullable();
            $t->text('notes')->nullable();
            $t->foreign('booking_id')->references('id')->on('bookings')->cascadeOnDelete();
            $t->foreign('hotel_id')->references('id')->on('hotels');
            $t->foreign('room_type_id')->references('id')->on('room_types');
            $t->foreign('rate_period_id')->references('id')->on('rate_periods');
            $t->index(['booking_id'], 'booking_items_booking_idx');
        });

        Schema::create('hotel_amenities', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('amenity_id');
            $t->foreign('hotel_id')->references('id')->on('hotels')->cascadeOnDelete();
            $t->foreign('amenity_id')->references('id')->on('amenities')->cascadeOnDelete();
            $t->unique(['hotel_id', 'amenity_id'], 'hotel_amenities_unique_idx');
        });

        Schema::create('hotel_contacts', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id')->nullable();
            $t->unsignedBigInteger('group_id')->nullable();
            $t->text('name')->nullable();
            $t->text('position')->nullable();
            $t->text('email')->nullable();
            $t->text('phone')->nullable();
            $t->text('business_card_link')->nullable();
            $t->boolean('whatsapp')->default(false);
            $t->boolean('telegram')->default(false);
            $t->boolean('viber')->default(false);
            $t->text('other_contact')->nullable();
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('hotel_id')->references('id')->on('hotels')->nullOnDelete();
            $t->foreign('group_id')->references('id')->on('hotel_groups')->nullOnDelete();
            $t->index(['hotel_id'], 'hotel_contacts_hotel_idx');
            $t->index(['group_id'], 'hotel_contacts_group_idx');
        });

        Schema::create('hotel_contact_assignments', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('contact_id');
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('hotel_id')->references('id')->on('hotels')->cascadeOnDelete();
            $t->foreign('contact_id')->references('id')->on('hotel_contacts')->cascadeOnDelete();
            $t->unique(['hotel_id', 'contact_id'], 'hotel_contact_assignments_unique_idx');
            $t->index(['contact_id'], 'hotel_contact_assignments_contact_idx');
        });

        Schema::create('markets', function (Blueprint $t) {
            $t->id('id');
            $t->string('slug', 191);
            $t->text('label')->nullable();
            $t->integer('sort_order')->default(100);
            $t->boolean('active')->default(true);
            $t->unique(['slug'], 'markets_slug_idx');
        });

        Schema::create('occupancy_rules', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('room_type_id');
            $t->integer('adults');
            $t->integer('children')->default(0);
            $t->integer('infants')->default(0);
            $t->integer('extra_beds')->default(0);
            $t->text('label')->nullable();
            $t->foreign('room_type_id')->references('id')->on('room_types')->cascadeOnDelete();
            $t->index(['room_type_id'], 'occupancy_rules_room_idx');
        });

        Schema::create('quotation_items', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('quotation_id');
            $t->integer('sort_order')->default(0);
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('room_type_id');
            $t->unsignedBigInteger('rate_period_id')->nullable();
            $t->text('board_type')->nullable();
            $t->date('check_in');
            $t->date('check_out');
            $t->integer('nights')->default(1);
            $t->integer('adults')->default(2);
            $t->integer('children')->default(0);
            $t->integer('infants')->default(0);
            $t->integer('rooms')->default(1);
            $t->integer('extra_beds')->default(0);
            $t->integer('sofa_beds')->default(0);
            $t->integer('baby_cots')->default(0);
            $t->decimal('base_amount', 12, 2)->default('0');
            $t->decimal('board_amount', 12, 2)->default('0');
            $t->decimal('occupancy_amount', 12, 2)->default('0');
            $t->decimal('extra_bed_amount', 12, 2)->default('0');
            $t->decimal('tourism_tax_amount', 12, 2)->default('0');
            $t->decimal('total_amount', 12, 2)->default('0');
            $t->text('rate_names')->nullable();
            $t->text('promo_codes')->nullable();
            $t->text('notes')->nullable();
            $t->foreign('quotation_id')->references('id')->on('quotations')->cascadeOnDelete();
            $t->foreign('hotel_id')->references('id')->on('hotels');
            $t->foreign('room_type_id')->references('id')->on('room_types');
            $t->foreign('rate_period_id')->references('id')->on('rate_periods');
            $t->index(['quotation_id'], 'quotation_items_quote_idx');
        });

        Schema::create('room_bedding', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('room_type_id');
            $t->string('kind', 191);
            $t->text('label')->nullable();
            $t->integer('max_per_room')->default(1);
            $t->boolean('free')->default(false);
            $t->decimal('rate_per_night', 10, 2)->default('0');
            $t->boolean('per_stay')->default(false);
            $t->integer('sort_order')->default(100);
            $t->foreign('room_type_id')->references('id')->on('room_types')->cascadeOnDelete();
            $t->unique(['room_type_id', 'kind'], 'room_bedding_unique_idx');
        });

        Schema::create('room_categories', function (Blueprint $t) {
            $t->id('id');
            $t->string('slug', 191);
            $t->text('label')->nullable();
            $t->integer('sort_order')->default(100);
            $t->boolean('active')->default(true);
            $t->unique(['slug'], 'room_categories_slug_idx');
        });

        Schema::create('services', function (Blueprint $t) {
            $t->id('id');
            $t->text('name')->nullable();
            $t->string('kind', 191)->default('shared_transfer');
            $t->text('vehicle_type')->nullable();
            $t->text('price_mode')->nullable();
            $t->decimal('one_way_price', 10, 2)->default('0');
            $t->decimal('two_way_price', 10, 2)->default('0');
            $t->text('details')->nullable();
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->index(['kind'], 'services_kind_idx');
        });

        Schema::create('users', function (Blueprint $t) {
            $t->id('id');
            $t->string('email', 191);
            $t->text('name')->nullable();
            $t->text('password_hash')->nullable();
            $t->text('role')->nullable();
            $t->text('permissions')->nullable();
            $t->text('phone')->nullable();
            $t->boolean('active')->default(true);
            $t->boolean('must_change_password')->default(false);
            $t->timestamp('last_login_at')->nullable();
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->unique(['email'], 'users_email_idx');
        });

        Schema::create('sessions', function (Blueprint $t) {
            $t->id('id');
            $t->string('token', 191);
            $t->unsignedBigInteger('user_id');
            $t->timestamp('expires_at');
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
            $t->unique(['token'], 'sessions_token_idx');
            $t->index(['user_id'], 'sessions_user_idx');
        });

        Schema::create('smtp_settings', function (Blueprint $t) {
            $t->id('id');
            $t->text('host')->nullable();
            $t->integer('port')->default(587);
            $t->boolean('secure')->default(false);
            $t->text('username')->nullable();
            $t->text('password')->nullable();
            $t->text('from_name')->nullable();
            $t->text('from_email')->nullable();
            $t->text('reply_to')->nullable();
            $t->boolean('bcc_self')->default(false);
            $t->boolean('active')->default(false);
            $t->timestamp('updated_at')->nullable()->useCurrent();
        });

        Schema::create('tours', function (Blueprint $t) {
            $t->id('id');
            $t->text('name')->nullable();
            $t->string('category', 191)->default('tour');
            $t->decimal('ticket_only_price', 10, 2)->default('0');
            $t->decimal('shared_transfer_price', 10, 2)->default('0');
            $t->decimal('private_transfer_price', 10, 2)->default('0');
            $t->text('details')->nullable();
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->index(['category'], 'tours_category_idx');
        });

        Schema::create('trip_packages', function (Blueprint $t) {
            $t->id('id');
            $t->string('reference', 191);
            $t->unsignedBigInteger('quotation_id')->nullable();
            $t->text('title')->nullable();
            $t->text('client_name')->nullable();
            $t->text('client_email')->nullable();
            $t->text('client_phone')->nullable();
            $t->text('client_company')->nullable();
            $t->text('status')->nullable();
            $t->date('start_date')->nullable();
            $t->date('end_date')->nullable();
            $t->boolean('includes_hotels')->default(true);
            $t->boolean('include_tax')->default(true);
            $t->text('markup_mode')->nullable();
            $t->decimal('markup_value', 12, 2)->default('0');
            $t->decimal('hotel_cost_total', 12, 2)->default('0');
            $t->decimal('extras_cost_total', 12, 2)->default('0');
            $t->decimal('tourism_tax_amount', 12, 2)->default('0');
            $t->decimal('markup_amount', 12, 2)->default('0');
            $t->decimal('quoted_total', 12, 2)->default('0');
            $t->decimal('total_amount', 12, 2)->default('0');
            $t->text('currency')->nullable();
            $t->text('notes')->nullable();
            $t->timestamp('created_at')->nullable()->useCurrent();
            $t->timestamp('updated_at')->nullable()->useCurrent();
            $t->foreign('quotation_id')->references('id')->on('quotations')->nullOnDelete();
            $t->unique(['reference'], 'trip_packages_reference_idx');
            $t->index(['quotation_id'], 'trip_packages_quote_idx');
        });

        Schema::create('trip_package_items', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('package_id');
            $t->integer('sort_order')->default(0);
            $t->text('kind')->nullable();
            $t->unsignedBigInteger('service_id')->nullable();
            $t->unsignedBigInteger('tour_id')->nullable();
            $t->text('name')->nullable();
            $t->text('price_type')->nullable();
            $t->date('service_date')->nullable();
            $t->text('service_time')->nullable();
            $t->text('pickup')->nullable();
            $t->text('dropoff')->nullable();
            $t->integer('persons')->default(1);
            $t->integer('vehicles')->default(1);
            $t->decimal('unit_price', 10, 2)->default('0');
            $t->decimal('total_amount', 10, 2)->default('0');
            $t->text('details')->nullable();
            $t->foreign('package_id')->references('id')->on('trip_packages')->cascadeOnDelete();
            $t->foreign('service_id')->references('id')->on('services')->nullOnDelete();
            $t->foreign('tour_id')->references('id')->on('tours')->nullOnDelete();
            $t->index(['package_id'], 'trip_package_items_pkg_idx');
        });

    }

    public function down(): void
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('trip_package_items');
        Schema::dropIfExists('trip_packages');
        Schema::dropIfExists('tours');
        Schema::dropIfExists('smtp_settings');
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('users');
        Schema::dropIfExists('services');
        Schema::dropIfExists('room_categories');
        Schema::dropIfExists('room_bedding');
        Schema::dropIfExists('quotation_items');
        Schema::dropIfExists('occupancy_rules');
        Schema::dropIfExists('markets');
        Schema::dropIfExists('hotel_contact_assignments');
        Schema::dropIfExists('hotel_contacts');
        Schema::dropIfExists('hotel_amenities');
        Schema::dropIfExists('booking_items');
        Schema::dropIfExists('bookings');
        Schema::dropIfExists('quotations');
        Schema::dropIfExists('rate_periods');
        Schema::dropIfExists('blackout_dates');
        Schema::dropIfExists('room_types');
        Schema::dropIfExists('hotels');
        Schema::dropIfExists('hotel_groups');
        Schema::dropIfExists('locations');
        Schema::dropIfExists('amenities');
        Schema::enableForeignKeyConstraints();
    }
};
