<?php

use App\Http\Controllers\ApiController as A;
use App\Http\Controllers\InstallController as I;
use App\Http\Controllers\PageController as P;
use Illuminate\Support\Facades\Route;

// Browser installer
Route::get('/install', [I::class, 'show']);
Route::post('/install/test', [I::class, 'test']);
Route::post('/install', [I::class, 'install']);

// Pages (same URLs as the Next.js app)
Route::get('/', [P::class, 'home']);
Route::get('/login', [P::class, 'login']);
Route::get('/health', [P::class, 'health']);
Route::get('/api/health', [P::class, 'health']);
Route::get('/api/bootstrap', [P::class, 'bootstrap']);
Route::get('/api/search-context', [P::class, 'searchContext']);

// JSON API — one entry per src/app/api/<name>/route.ts
Route::post('/api/auth', [A::class, 'auth'])->middleware('throttle:20,1');
Route::post('/api/users', [A::class, 'usersPost']);
Route::patch('/api/users', [A::class, 'usersPatch']);
Route::delete('/api/users', [A::class, 'usersDelete']);
Route::put('/api/email', [A::class, 'emailPut']);
Route::post('/api/email', [A::class, 'emailPost']);
Route::post('/api/hotels', [A::class, 'hotelsPost']);
Route::post('/api/rooms', [A::class, 'roomsPost']);
Route::patch('/api/rooms', [A::class, 'roomsPatch']);
Route::post('/api/rates', [A::class, 'ratesPost']);
Route::post('/api/blackouts', [A::class, 'blackoutsPost']);
Route::post('/api/amenities', [A::class, 'amenitiesPost']);
Route::post('/api/hotel-amenities', [A::class, 'hotelAmenitiesPost']);
Route::post('/api/room-categories', [A::class, 'roomCategoriesPost']);
Route::post('/api/hotel-groups', [A::class, 'hotelGroupsPost']);
Route::post('/api/markets', [A::class, 'marketsPost']);
Route::delete('/api/markets', [A::class, 'marketsDelete']);
Route::post('/api/locations', [A::class, 'locationsPost']);
Route::delete('/api/locations', [A::class, 'locationsDelete']);
Route::post('/api/occupancy', [A::class, 'occupancyPost']);
Route::delete('/api/occupancy', [A::class, 'occupancyDelete']);
Route::post('/api/contacts', [A::class, 'contactsPost']);
Route::patch('/api/contacts', [A::class, 'contactsPatch']);
Route::delete('/api/contacts', [A::class, 'contactsDelete']);
Route::get('/api/services', [A::class, 'servicesGet']);
Route::post('/api/services', [A::class, 'servicesPost']);
Route::delete('/api/services', [A::class, 'servicesDelete']);
Route::get('/api/tours', [A::class, 'toursGet']);
Route::post('/api/tours', [A::class, 'toursPost']);
Route::delete('/api/tours', [A::class, 'toursDelete']);
Route::get('/api/quotations', [A::class, 'quotationsGet']);
Route::post('/api/quotations', [A::class, 'quotationsPost']);
Route::patch('/api/quotations', [A::class, 'quotationsPatch']);
Route::delete('/api/quotations', [A::class, 'quotationsDelete']);
Route::post('/api/bookings', [A::class, 'bookingsPost']);
Route::get('/api/trip-packages', [A::class, 'tripPackagesGet']);
Route::post('/api/trip-packages', [A::class, 'tripPackagesPost']);
Route::patch('/api/trip-packages', [A::class, 'tripPackagesPatch']);
Route::delete('/api/trip-packages', [A::class, 'tripPackagesDelete']);
Route::post('/api/trip-package-items', [A::class, 'tripItemsPost']);
Route::delete('/api/trip-package-items', [A::class, 'tripItemsDelete']);
