<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

// Guarantee a valid APP_KEY so sessions/cookies work before the installer has run.
$base = dirname(__DIR__);
if (! is_file($base.'/.env') && is_file($base.'/.env.example')) @copy($base.'/.env.example', $base.'/.env');
if (is_file($base.'/.env')) {
    $env = (string) file_get_contents($base.'/.env');
    if (! preg_match('/^APP_KEY=base64:\S+/m', $env)) {
        $key = 'base64:'.base64_encode(random_bytes(32));
        $env = preg_match('/^APP_KEY=.*$/m', $env) ? preg_replace('/^APP_KEY=.*$/m', 'APP_KEY='.$key, $env) : $env."\nAPP_KEY={$key}\n";
        @file_put_contents($base.'/.env', $env);
        putenv("APP_KEY={$key}"); $_ENV['APP_KEY'] = $key; $_SERVER['APP_KEY'] = $key;
    }
}

return Application::configure(basePath: $base)
    ->withRouting(web: __DIR__.'/../routes/web.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->web(prepend: [\App\Http\Middleware\EnsureInstalled::class]);
        // The React client posts JSON with same-site cookies; CSRF form tokens are not used for /api/*.
        $middleware->validateCsrfTokens(except: ['api/*']);
        $middleware->trustProxies(at: '*');
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(fn ($request) => $request->is('api/*'));
    })->create();
