# Luxury Attractions — Hotel Contracts (Laravel 12 + MySQL)

A PHP/MySQL build of the original `luxury-attractions-hotel-system` (Next.js). It has the
same screens, visuals and features: Search & compare, Quotations, Trip Packages, Overview,
Bookings, Hotels, Room types, Rates & board, Blackout dates, Users & settings, PDF proposals
and SMTP email.

## How it maps to the original
| Original (Next.js) | This build |
|---|---|
| React screens (`dashboard-client.tsx`, `search-panel.tsx`, …) | Compiled unchanged into `public/build/app.js` |
| Tailwind styles | `public/build/app.css` |
| `src/app/api/*/route.ts` (21 routes) | `app/Http/Controllers/ApiController.php` (same URLs, JSON, messages) |
| `src/db/schema.ts` (PostgreSQL) | `database/migrations/…create_hotel_system_tables.php` (MySQL/MariaDB) |
| Pricing engine `search-engine.ts` | Same TypeScript code, runs in the browser on data from `/api/search-context` |
| Seeded catalogue | `database/demo.json` (imported optionally by the installer) |

Install steps: see `INSTALL.txt`.
